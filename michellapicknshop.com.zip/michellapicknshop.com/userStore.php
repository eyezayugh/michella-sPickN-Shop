<!-- Programmed by: Isaiah John Ching Fernando-->
<?php
session_start();
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];
$loyalpts = $_SESSION['loyalPts'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/mobile.css?v=<?php echo time(); ?>">
    <title>Store | Michella's Pick N' Shop |<?php echo ' '.$userUid; ?></title>
  </head>
  <body class="bg-light" style="overflow-x: hidden;">
  <?php
    if ($userType == "User" ) {
  ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="userHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    }
    if ($userType == 'Reseller') {
    ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="resellerHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
  }?>
    <div class="row">
      <!-- Categories Section-->
      <div class="col-lg-3">
        <div class="container">
          <h5 class="mt-2 ml-2">Filter Product</h5>
          <hr>
          <h6 class="text-info m-2">Select Brand <button class="btn btn-light" onclick="show_hide()"><i class="fas fa-chevron-down"></i></button></h6>
          <ul class="list-group" id="hide">
            <?php
              include 'includes/dbhStore.inc.php';
              $sql = "SELECT DISTINCT brand FROM prodcuct ORDER BY brand;";
              $result = $conn->query($sql);
              while($row = $result->fetch_assoc()){
            ?>
            <li class="list-group-item">
              <div class="form-check">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input product_check" value="<?= $row['brand'];?>" id="brand"><?= $row['brand']; ?>
                </label>
              </div>
            </li>
            <?php 
            } 
            ?>
          </ul>
          <h6 class="text-info m-2">Product Category<button class="btn btn-light" onclick="show_hide2()"><i class="fas fa-chevron-down"></i></button></h6>
          <ul class="list-group" id="hide2">
            <?php
              include 'includes/dbhStore.inc.php';
              $sql = "SELECT DISTINCT typeProd FROM prodcuct ORDER BY typeProd;";
              $result = $conn->query($sql);
              while($row = $result->fetch_assoc()){
            ?>
            <li class="list-group-item">
              <div class="form-check">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input product_check" value="<?= $row['typeProd']; ?>" id="typeProd"><?= $row['typeProd']; ?>
                </label>
              </div>
            </li>
            <?php 
            } 
            ?>
          </ul>
        </div>
      </div>
      <!-- Product Section-->
      <div class="col">
        <div class="container">
          <!-- Search Field -->
          <?php include 'includes/dbhStore.inc.php';?>
          <form action="" method="POST">
            <div class="form-inline input-group col-sm-8 col-lg-4 mt-2 mb-1">
              <input type="text" name="search" class="form-control" placeholder="Search">
              <button type="submit" name="submit-search" class="btn btn-outline-info"><i class="fas fa-search"></i></button>
            </div>
          </form>
          <a href="userProductPrint.php?printallprod" target="_blank" style="color: #fff; text-decoration: none;"><button type="button" class="btn btn-dark mt-1 ml-3" style="text-decoration: none;">Product List</button></a>
          <!-- Error Messages -->
          <div class="message" id="message">
            <?php
            if($loyalpts < 0){
                echo '<div class="alert alert-danger"alert-dismissible fade show mt-3">
                <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
                <strong>WARNING: If you are found abusing the functions of the system your account will be deleted.</strong>
              </div>';
            }
            if ($verify == 0) {
              echo'<div class="alert alert-danger alert-dismissible fade show mt-3">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong>Please verify your email to start buying products!</strong>
            </div>';
            }
            if (isset($_GET['error'])) {
              if ($_GET['error'] == 'signin') {
            ?>
            <div class="alert alert-danger alert-dismissible  mt-1">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong>Please Sign In to  Access your Cart!</strong>
            </div>
            <?php 
              }
              if ($_GET['error'] == 'notvalid') {
            ?>
            <div class="alert alert-danger alert-dismissible  mt-1">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong>Please Validate Your Email!</strong>
            </div>
            <?php 
              }
            }
           ?>
            
          </div>
          <!-- Product Output -->
          <div class="text-center">
            <img src="img/load.gif" id="loader" width="200" style="display: none;">
          </div>
          <div class="row mt-2 pb-3" id="result">
            <?php
            include 'includes/dbhStore.inc.php';
            if (isset($_POST['submit-search'])) {
              $space = '/\s/';
              $search = mysqli_real_escape_string($conn, $_POST['search']);
              $sql="SELECT * FROM prodcuct WHERE productName LIKE '%$search%' OR productDesc LIKE '%$search%' OR productName LIKE '%$space%' OR productDesc LIKE '%$space%';";
              $result = mysqli_query($conn, $sql);
              $queryResult = mysqli_num_rows($result);

              if ($queryResult > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
              ?>
              <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
                <div class="card-deck">
                  <div class="card p-2 border-bottom md-2" style="box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.3), 0px 0px 6px rgba(0, 0, 0, 0.3);">
                    <a href="userStoreInfo.php?product=<?= $row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="180"></a>
                    <div class="card-body p-1">
                      <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
                      <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                    </div>
                    <div class="card-footer p-1 pb-2">
                      <form action="" class="form-submit">
                        <input type="hidden" class="pid" value="<?=$row['id']; ?>">
                        <input type="hidden" class="pname" value="<?=$row['productName']; ?>">
                        <input type="hidden" class="pprice" value="<?=$row['productPrice']; ?>">
                        <input type="hidden" class="pimage" value="<?=$row['productImage']; ?>">
                        <input type="hidden" class="pcode" value="<?=$row['productCode']; ?>">
                        <input type="hidden" class="pdesc" value="<?=$row['productDesc']; ?>">
                        <input type="hidden" class="puser" value="<?= $userUid ?>">
                        <button class="btn btn-warning btn-block addItemBtn"><i class="fas fa-shopping-cart"></i> Add to cart</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            <?php
                }

              }else{
                echo'<div class="alert alert-danger alert-dismissible fade show mt-2">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>There are no results matching your search</strong>
              </div>';
              }
            }
            elseif (isset($_GET['brand'])) {
              $brand = $_GET['brand'];
              include 'includes/dbhStore.inc.php';
              $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE brand = '$brand'");
              $stmt->execute();
              $result = $stmt->get_result();
              while($row = $result->fetch_assoc()){
            ?>
            <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
              <div class="card-deck">
                <div class="card p-2 border-bottom md-2" style="box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.3), 0px 0px 6px rgba(0, 0, 0, 0.3);">
                  <a href="userStoreInfo.php?product=<?= $row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="180"></a>
                  <div class="card-body p-1">
                    <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
                    <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                  </div>
                  <div class="card-footer p-1 pb-2">
                    <form action="" class="form-submit">
                      <input type="hidden" class="pid" value="<?=$row['id']; ?>">
                      <input type="hidden" class="pname" value="<?=$row['productName']; ?>">
                      <input type="hidden" class="pprice" value="<?=$row['productPrice']; ?>">
                      <input type="hidden" class="pimage" value="<?=$row['productImage']; ?>">
                      <input type="hidden" class="pcode" value="<?=$row['productCode']; ?>">
                      <input type="hidden" class="pdesc" value="<?=$row['productDesc']; ?>">
                      <input type="hidden" class="puser" value="<?= $userUid ?>">
                      <button class="btn btn-warning btn-block addItemBtn"><i class="fas fa-shopping-cart"></i> Add to cart</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <?php
              }
            }else{ ?>
              <!-- Featured Products -->
              <div class="container">
                <div class="row justify-content-center">
                  <h5 class="text-center text-info m-3" style="text-transform: uppercase; letter-spacing: 2px;">Featured Products</h5>
                </div>
              </div>
              <div class="container">
                <div class="row">
              <?php
                include 'includes/dbhStore.inc.php';
                $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE feature = 1;");
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()){
              ?>
                <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
                  <div class="card-deck">
                    <div class="card p-2 border-bottom mb-2" style="box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.3), 0px 0px 6px rgba(0, 0, 0, 0.3);">
                      <?php
                      if ($verify == 0) {
                      ?>
                      <a href="userStore.php?error=notvalid"></a><img src="<?= $row['productImage']?>" class="card-img-top" width="100%" height="100%">
                      <?php 
                      }else{ ?>
                      <a href="userStoreInfo.php?product=<?= $row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="180"></a>
                      <?php }?>
                      <div class="card-body p-1">
                        <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
                        <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                      </div>
                      <div class="card-footer p-1 pb-2">
                        <?php
                        if ($verify == 0) {
                        ?>
                        <a href="userStore.php?error=notvalid" class="btn btn-warning btn-block"><i class="fas fa-shopping-cart"></i> Add to cart</a>
                        <?php
                        }else {
                        ?>
                        <form action="" class="form-submit">
                          <input type="hidden" class="pid" value="<?=$row['id']; ?>">
                          <input type="hidden" class="pname" value="<?=$row['productName']; ?>">
                          <input type="hidden" class="pprice" value="<?=$row['productPrice']; ?>">
                          <input type="hidden" class="pimage" value="<?=$row['productImage']; ?>">
                          <input type="hidden" class="pcode" value="<?=$row['productCode']; ?>">
                          <input type="hidden" class="pdesc" value="<?=$row['productDesc']; ?>">
                          <input type="hidden" class="puser" value="<?= $userUid ?>">
                          <button class="btn btn-warning btn-block addItemBtn"><i class="fas fa-shopping-cart"></i> Add to cart</button>
                        </form>
                        <?php }?>
                      </div>
                    </div>
                  </div>
                </div>
                <?php }?>
                  </div>
                </div>
                <!-- Rest of the Product Store -->
                <div class="container">
                  <div class="row justify-content-center">
                    <h5 class="text-center text-info m-3" style="text-transform: uppercase; letter-spacing: 2px;">Store</h5>
                  </div>
                </div>
              <?php
                include 'includes/dbhStore.inc.php';
                $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE feature = 0;");
                $stmt->execute();
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()){
              ?>
              <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
                <div class="card-deck">
                <div class="card p-2 border-bottom mb-2" style="box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.3), 0px 0px 6px rgba(0, 0, 0, 0.3);">
                    <?php
                    if ($verify == 0) {
                    ?>
                    <a href="userStore.php?error=notvalid"><img src="<?= $row['productImage']?>" class="card-img-top" width="140"></a>
                    <?php 
                    }else{ ?>
                    <a href="userStoreInfo.php?product=<?= $row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="140"></a>
                    <?php }?>
                    <div class="card-body p-1">
                      <h6 class="card-title text-center text-info"><?=$row['productName']; ?></h6>
                      <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                    </div>
                    <div class="card-footer p-1 pb-2">
                      <?php
                      if ($verify == 0) {
                      ?>
                      <button class="btn btn-outline-secondary" disabled><i class="fas fa-shopping-cart"></i> Add to cart</button>
                      <?php
                      }else {
                      ?>
                      <form action="" class="form-submit">
                        <input type="hidden" class="pid" value="<?=$row['id']; ?>">
                        <input type="hidden" class="pname" value="<?=$row['productName']; ?>">
                        <input type="hidden" class="pprice" value="<?=$row['productPrice']; ?>">
                        <input type="hidden" class="pimage" value="<?=$row['productImage']; ?>">
                        <input type="hidden" class="pcode" value="<?=$row['productCode']; ?>">
                        <input type="hidden" class="pdesc" value="<?=$row['productDesc']; ?>">
                        <input type="hidden" class="ppts" value="<?=$row['loyalpts']; ?>">
                        <input type="hidden" class="puser" value="<?= $userUid ?>">
                        <button class="btn btn-warning btn-block addItemBtn"><i class="fas fa-shopping-cart"></i> Add to cart</button>
                      </form>
                      <?php }?>
                    </div>
                  </div>
                </div>
              </div>
              <?php
                }
              }?>
          </div>
        </div>
      </div>
    </div>

    <?php
      include_once 'footer.php';
    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        $(".addItemBtn").click(function(e){
          e.preventDefault();
          var $form = $(this).closest(".form-submit");
          var pid = $form.find(".pid").val();
          var pname = $form.find(".pname").val();
          var pprice = $form.find(".pprice").val();
          var pimage = $form.find(".pimage").val();
          var pcode = $form.find(".pcode").val();
          var pdesc = $form.find(".pdesc").val();
          var ppts = $form.find(".ppts").val();
          var puser = $form.find(".puser").val();

          $.ajax({
            url: 'includes/actionCart.inc.php',
            method: 'post',
            data: {pid:pid,pname:pname,pprice:pprice,pimage:pimage,pcode:pcode,pdesc:pdesc,ppts:ppts,puser:puser},
            success:function(response){
              $("#message").html(response);
              window.scrollTo(0,0);
              load_cart_item_number();
            }
          });
        });

        load_cart_item_number();

        function load_cart_item_number(){
          $.ajax({
            url: 'includes/actionCart.inc.php',
            method: 'get',
            data: {cartItem:"cart_item"},
            success:function(response){
              $("#cart-item").html(response);
            }
          });
        }

      });
    </script>
    <script type="text/javascript">
      $(document).ready(function(){

        $(".product_check").click(function(){
          $('#loader').show();
          var action = 'data';
          var brand = get_filter_text('brand');
          var typeProd = get_filter_text('typeProd');

          $.ajax({
            url:'actionUser.php',
            method:'POST',
            data:{action:action,brand:brand,typeProd:typeProd,},
            success:function(response){
              $("#result").html(response);
              $("#loader").hide();
            }
          });
        });

        function get_filter_text(text_id){
          var filterData = [];
          $('#'+text_id+':checked').each(function(){
            filterData.push($(this).val());
          });
          return filterData;
        }

      });
    </script>
    <script src="js/showhide.js"></script>
  </body>
</html>
<!-- Programmed by: Isaiah John Ching Fernando-->
<?php
include 'header.php';
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];

if (isset($_POST["submit"])) {

    $name = $_POST["name"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $username = $_POST["uid"];
    $bill = $_POST['bill'];
    $deliver = $_POST['deliver'];

    include 'includes/dbh.inc.php';
    if (empty($name) || empty($phone) || empty($address) || empty($bill) || empty($deliver)) {
        header("location: userEditProfile.php?error=empty");
        exit();
    }
    function phoneExist2($conn, $phone, $username){
        $result;
        $sql = mysqli_query($conn, "SELECT userPhone FROM users WHERE userPhone = '$phone';") or exit(mysqli_error($sql));
        if(mysqli_num_rows($sql)){
            $sql = $conn->prepare("SELECT userPhone FROM users WHERE userUid ='$username';");
            if (mysqli_num_rows($sql)) {
                $result = true;
            }else {
                $result= false;
            }
        }else {
            $result = false;
        }
        return $result;
    }
    if (phoneExist2($conn, $phone, $username) !== false) {
        header("location: userEditProfile.php?error=phone");
        exit();
    }
    if (!preg_match("/^[a-zA-Z\s]*$/", $name)) {
        header("location: userEditProfile.php?error=name");
        exit();
    }
    if (!preg_match("/^[0-9]*$/", $phone)) {
        header("location: userEditProfile.php?error=phonenum");
        exit();
    }
    if (strlen($name) < 2 || strlen($name) > 40) {
        header("location: userEditProfile.php?error=namelen");
        exit();
    }
    if (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: userEditProfile.php?error=numln");
        exit();
    }
    if (strlen($address) > 60) {
        header("location: userEditProfile.php?error=addlen");
        exit();
    }
    if (strlen($bill) > 60) {
        header("location: userEditProfile.php?error=addlen");
        exit();
    }
    if (strlen($deliver) > 60) {
        header("location: userEditProfile.php?error=addlen");
        exit();
    }
    
    $sql = $conn->prepare("UPDATE users SET userName = ?, userPhone = ?, userAdd = ?, billAdd = ?, deliverAdd = ? WHERE userUid = ?;");
    $sql->bind_param("ssssss", $name, $phone, $address, $bill, $deliver, $username);
    $sql->execute();
    header("location: userEditProfile.php?success=edit");
    exit();

}

if (isset($_POST['submitDp'])) {
    include 'includes/dbh.inc.php';
    
    $sql = $conn->prepare("SELECT * FROM users WHERE userUid = '$userUid';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
        $image = $row['profilePic'];
        $file_to_delete = "userimg/$image";
        unlink($file_to_delete);
    }

    $file = $_FILES['file'];

    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png');

    if (in_array($fileActualExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 4000000) {
                $fileNameNew = $userUid."-DP.".$fileActualExt;
                $fileDestination = 'userimg/'.$fileNameNew;
                move_uploaded_file($fileTmpName, $fileDestination);
                $insert = $conn->query("UPDATE users SET profilePic = '$fileNameNew' WHERE userUid = '$userUid';");
                if ($insert) {
                    header("location: userEditProfile.php?success=uploadPro");
                    exit();
                }else {
                    echo $conn->error;
                }
            }else {
                header("location: userEditProfile.php?error=imgsize");
                exit();
            }
        }else {
            header("location: userEditProfile.php?error=upload");
            exit();
        }
    }else {
        header("location: userEditProfile.php?error=imgtype");
        exit();
    }
}
if (isset($_POST['submitBg'])) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    include 'includes/dbh.inc.php';
    
    $sql = $conn->prepare("SELECT * FROM users WHERE userUid = '$userUid';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
        $image = $row['bgPic'];
        $file_to_delete = "userimg/$image";
        unlink($file_to_delete);
    }

    $file = $_FILES['file'];

    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png');

    if (in_array($fileActualExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 10000000) {
                $fileNameNew = $userUid."-BG.".$fileActualExt;
                $fileDestination = 'userimg/'.$fileNameNew;
                move_uploaded_file($fileTmpName, $fileDestination);
                $insert = $conn->query("UPDATE users SET bgPic = '$fileNameNew' WHERE userUid = '$userUid';");
                if ($insert) {
                    header("location: userEditProfile.php?success=uploadBG");
                    exit();
                }else {
                    echo $conn->error;
                }
            }else {
                header("location: userEditProfile.php?error=imgsize");
                exit();
            }
        }else {
            header("location: userEditProfile.php?error=upload");
            exit();
        }
    }else {
        header("location: userEditProfile.php?error=imgtype");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleEditProfile.css?v=<?php echo time(); ?>">
    <title>Document</title>
</head>
<body>
    <div class="space"></div>
    <?php
    if (isset($_GET['success'])) {
      if ($_GET['success'] == 'edit') {
    ?>
    <div class="alert alert-success" id="close">
      <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
      <strong>You have successfully edited your account information</strong>
    </div>
    <?php
      }
      if ($_GET['success'] == 'uploadPro') {
    ?>
    <div class="alert alert-success" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>You have successfully uploaded a new Profile Pic</strong>
    </div>
    <?php
        }
        if ($_GET['success'] == 'uploadBG') {
    ?>
    <div class="alert alert-success" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>You have successfully uploaded a new Background Pic</strong>
    </div>
    <?php
        }
    }
    if (isset($_GET['error'])) {
      if ($_GET['error'] == 'addlen') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Invalid length of address</strong>
      </div>';
      }
      if ($_GET['error'] == 'numln') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Invalid length of phone number</strong>
      </div>';
      }
      if ($_GET['error'] == 'namelen') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Invalid length of name</strong>
      </div>';
      }
      if ($_GET['error'] == 'phonenum') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Invalid Phone Number</strong>
      </div>';
      }
      if ($_GET['error'] == 'name') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Invalid Name, No numbers or special characters allowed</strong>
      </div>';
      }
      if ($_GET['error'] == 'phone') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Phone Number Already Exist</strong>
      </div>';
      }
      if ($_GET['error'] == 'empty') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Fields are empty, please fill in all fields</strong>
      </div>';
      }
      if ($_GET['error'] == 'imgtype') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Invalid img (jpg, jpeg, png) only</strong>
      </div>';
      }
      if ($_GET['error'] == 'upload') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Upload error please try again</strong>
      </div>';
      }
      if ($_GET['error'] == 'imgsize') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>Image too large, please try again</strong>
      </div>';
      }
    }
    ?>
    <div class="container-edit">
        <div class="text-title">
            <h5>Edit Profile</h5>
        </div>
        <div class="container-pics">
          <form action="" method="POST" enctype="multipart/form-data">
            <h5>Profile Picture</h5>
            <input type="file" name="file">
            <button type="submit" name="submitDp" class="btn">Upload</button>
          </form>
          <form action="" method="POST" enctype="multipart/form-data">
            <h5>Background Picture</h5>
            <input type="file" name="file">
            <button type="submit" name="submitBg" class="btn">Upload</button>
          </form>
        </div>
        <form action="" method="POST" class="edit-acc">
            <h5>Username: <?= $userUid; ?></h5>
            <h5>Email: <?= $userEmail; ?></h5>
            <input type="hidden" name="uid" value="<?= $userUid; ?>">
            <div class="form-group">
                <div class="input-field">
                    <i class="fas fa-signature"></i>
                    <input type="text" name="name" placeholder="<?= $userName; ?>" value="<?= $userName; ?>" />
                </div>
                <div class="input-field">
                    <i class="fas fa-phone"></i>
                    <input type="tel" name="phone" placeholder="<?= $userPhone; ?>" value="<?= $userPhone; ?>" />
                </div>
                <div class="input-field">
                    <i class="fas fa-home"></i>
                    <?php
                    include 'includes/dbh.inc.php';
                    $stmt = $conn->prepare("SELECT * FROM users WHERE userUid = '$userUid';");
                    $stmt->execute();
                    $res = $stmt->get_result();
                    while ($row = $res->fetch_assoc()) {
                    ?>
                    <input type="text" name="address" placeholder="Home Address" value="<?= $row['userAdd']; ?>" />
                    
                    <?php
                    }
                    $stmt->close();
                    $conn->close();
                    ?>
                </div>
                <?php
                include 'includes/dbh.inc.php';
                $add = $conn->prepare("SELECT * FROM users WHERE userUid = '$userUid';");
                $add->execute();
                $resl = $add->get_result();
                while($r = $resl->fetch_assoc()){
                    $billAdd = $r['billAdd'];
                    $deliver = $r['deliverAdd'];
                }
                ?>
                <div class="input-field">
                    <i class="far fa-money-bill-alt"></i>
                    <input type="text" name="bill" placeholder="Billing Address" value="<?= $billAdd; ?>" />
                </div>
                <div class="input-field">
                    <i class="fas fa-truck-loading"></i>
                    <input type="text" name="deliver" placeholder="Delivery Address" value="<?= $deliver; ?>" />
                </div>
            </div>
            <div class="button">
                <input type="submit" name="submit" class="btn" value="Edit"/>
                <a href="userProfile.php" class="btn-back">Cancel</a>
            </div>
            <a href="termscondition.php" target="_blank">Terms and Conditions</a>
            <a href="privacypolicy.php" target="_blank">Privacy Policy</a>
        </form>
    </div>
    <?php
        include 'footer.php';
    ?>
    <script>
      function myFunction(){
        document.getElementById("close").style.display = "none";
      }
    </script>
</body>
</html>

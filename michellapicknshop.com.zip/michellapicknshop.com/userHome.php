<!-- Programmed by: Isaiah John Ching Fernando -->
<?php
include 'header.php';
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$userType = $_SESSION["usertype"];
if ($userType == 'Reseller') {
    header("location: resellerHome.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/swiper.min.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/lightslider.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/styleUhome.css?v=<?php echo time(); ?>">
    <script type="text/javascript" src="js/JQuery3.3.1.js"></script>
    <script type="text/javascript" src="js/lightslider.js"></script>
    <title>Document</title>
</head>
<body>
    <div class="slideshow">
        <div class="banner1">
            <img src="img/shampoo.jpg" alt="">
            <div class="text-box">
                <h1>Tired of tangled Hair?</h1>
                <span></span>
                <p>With our products in our shop, experience smooth and silky hair like haven't 
                    experienced before.Treat your hair with only the best, so go on, what are 
                    you waiting for? Pick your product N' Shop now.</p>
            </div>
        </div>
        <div class="banner2">
            <img src="img/lotion.jpg" alt="">
            <div class="text-box">
                <h1>Want smooth silky skin?</h1>
                <span></span>
                <p>Indulge your skin with our products right from our store. Smooth
                    luscious skin with just a click of a button. So, go on, what are you
                    waiting for? Pick your product N' Shop now.
                </p>
            </div>
        </div>
        <div class="banner3">
            <img src="img/soap.jpg" alt="">
            <div class="text-box">
                <h1>Cleanliness for you and your own</h1>
                <span></span>
                <p>Treat you and your loved ones with the best, only here at our store, they
                    say cleanliness is next to godliness. So, go on, what are you
                    waiting for? Pick your product N' Shop now.
                </p>
            </div>
        </div>
        <div class="banner4">
            <img src="img/toothpaste.jpg" alt="">
            <div class="text-box">
                <h1>Cherish even the small moments</h1>
                <span></span>
                <p>We crave moments with our loved ones, so why not start small. Start with
                    our store and order now to experience and cherish all the moments. So,
                    go on, what are you waiting for? Pick your product N' Shop now.
                </p>
            </div>
        </div>
        <div class="banner5">
            <img src="img/dishwashing.jpg" alt="">
            <div class="text-box">
                <h1>Work smart not hard</h1>
                <span></span>
                <p>After a long days work, you don't want to spend hours cleaning your dishes.
                    So come buy our products and spend less time at the sink and more with your
                    family.
                </p>
            </div>
        </div>
        <div class="banner6">
            <img src="img/clean.jpg" alt="">
            <div class="text-box">
                <h1>Protection geared for your family</h1>
                <span></span>
                <p>You don't need hazmat suites or an N95 mask, our products are the protection.
                    Clean and sanitize your home now, so go on, what are you waiting for? Pick
                    your product N' Shop now
                </p>
            </div>
        </div>
    </div>
    <!-- Featured Products -->
    <div class="feature-box">
        <div class="text">
            <h5>Featured Products</h5>
        </div>
    </div>
    <div class="contain">
        <!-- slider -->
        <ul id="autoWidth" class="cs-hidden">
            <!-- slider-box -->
            <?php
                include 'includes/dbhStore.inc.php';
                $sql = "SELECT * FROM prodcuct WHERE feature = '1';";
                $result = $conn->query($sql);
                while ($row = $result->fetch_assoc()){
            ?>
            <li class="item">
                <a href="userStoreInfo.php?product=<?= $row['id']; ?>"><div class="boxs">
                    <p class="brand"><?= $row['brand']?></p>
                    <img src="<?= $row['productImage']?>" alt="" class="model">
                    <div class="details">
                        <p><?=$row['productName']; ?></p>
                        <p class="price">PHP <?=number_format($row['productPrice'],2); ?></p>
                    </div>
                </div></a>
            </li>
            <?php }?>
        </ul>
    </div>
    <!-- Loyalty points/rewards -->
    <section>
        <div class="feature-box">
            <div class="text">
                <h5>Loyaly points</h5>
            </div>
        </div>
        <div class="loyal-text">
            <p>Earn Loyalty cards by accumulating your loyalty points. You can earn more points by shopping
                now and get up to 50% off at your checkout. Purchase Loyalty Points at your Profile
            </p>
            <h5>Earn Loyalty Points with every PHP 25.00 spent.</h5>
            <h5><a href="userProfile.php" style="text-decoration: none;"><i class="fas fa-chevron-right"></i> Click Here to Check your Loyalty Points</a></h5>
            <hr>
        </div>
        <div class="swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide"><img src="img/loyal1.PNG" alt=""></div>
                <div class="swiper-slide"><img src="img/loyal2.PNG" alt=""></div>
                <div class="swiper-slide"><img src="img/loyal3.PNG" alt=""></div>
                <div class="swiper-slide"><img src="img/loyal4.JPG" alt=""></div>
                <div class="swiper-slide"><img src="img/loyal5.PNG" alt=""></div>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
        </div>
    </section>

    <?php
      include_once 'footer.php';
    ?>
    <script src="js/featSlider.js"></script>
    <script src="js/swiper.min.js"></script>
    <script>
    var swiper = new Swiper('.swiper-container', {
      effect: 'coverflow',
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: 'auto',
      coverflowEffect: {
        rotate: 50,
        stretch: 0,
        depth: 100,
        modifier: 1,
        slideShadows: true,
      },
      pagination: {
        el: '.swiper-pagination',
      },
    });
  </script>
</body>
</html>
<!--Programmed By: Isaiah John Ching Fernando-->
<!--Admin Message/News/Announcement Start-->
<div class="container-msg">
  <div class="title-section">
    <h4>Send Email To Customer</h4>
  </div>
  <div class="table-msg">
    <div class="msg-table">
      <!--Customer Table-->
      <div class="title-table">
        <h3>Customer</h3>
      </div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Phone</th>
          </tr>
        </thead>
        <?php
        include 'includes/dbh.inc.php';
        $sql = $conn->prepare("SELECT * FROM users");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <tbody>
          <td><?= $row['userName']; ?></td>
          <td><?= $row['userUid']; ?></td>
          <td><?= $row['userEmail']; ?></td>
          <td><?= $row['userPhone']; ?></td>
        </tbody>
        <?php
        }
        ?>
      </table>
    </div>
    <div class="box-msg">
    <form action="adminActionMsg.php" method="POST" class="control-form">
      <input type="email" name="email" class="form-control" placeholder="Enter Email Address" />
      <input type="text" name="subj" class="form-control" placeholder="Enter Subject" />
      <textarea name="msg" style="resize: none" cols="10" rows="3" placeholder="Enter Message"></textarea>
      <button type="submit" name="submit-emailCustomer">Send Email</button>
    </form>
    </div>
  </div>
</div>
<div class="container-msg">
  <div class="title-section">
    <h4>Send Email To Porter or Admin</h4>
  </div>
  <div class="table-msg">
    <div class="msg-table">
      <!--Admin Table-->
      <div class="title-table">
        <h4>Admin</h4>
      </div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Phone</th>
          </tr>
        </thead>
        <tbody>
          <?php
          include 'includes/dbh.inc.php';
          $sql = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Admin';");
          $sql->execute();
          $result = $sql->get_result();
          while($row = $result->fetch_assoc()){
          ?>
          <tbody>
            <td><?= $row['userName']; ?></td>
            <td><?= $row['userUid']; ?></td>
            <td><?= $row['userEmail']; ?></td>
            <td><?= $row['userPhone']; ?></td>
          </tbody>
          <?php
          }
          ?>
        </tbody>
      </table>
    </div>
    <div class="msg-table">
      <!--Porter Table-->
      <div class="title-table">
        <h4>Porters</h4>
      </div>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Phone</th>
          </tr>
        </thead>
        <tbody>
          <?php
          include 'includes/dbh.inc.php';
          $sql = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Deliver';");
          $sql->execute();
          $result = $sql->get_result();
          while($row = $result->fetch_assoc()){
          ?>
          <tbody>
            <tr>
            <td><?= $row['userName']; ?></td>
            <td><?= $row['userUid']; ?></td>
            <td><?= $row['userEmail']; ?></td>
            <td><?= $row['userPhone']; ?></td>
            </tr>
          </tbody>
          <?php
          }
          ?>
        </tbody>
      </table>
    </div>
    <div class="box-msg">
    <form action="adminActionMsg.php" method="POST" class="control-form">
      <input type="email" name="email" class="form-control" placeholder="Enter Email Address" />
      <input type="text" name="subj" class="form-control" placeholder="Enter Subject" />
      <textarea name="msg" style="resize: none" cols="10" rows="3" placeholder="Enter Message"></textarea>
      <button type="submit" name="submit-emailAdmin">Send Email</button>
    </form>
    </div>
  </div>
</div>
<div class="container-news">
  <div class="title-section">
    <h4>News/Announcements</h4>
  </div>
  <div class="box-news">
    <div class="table-news">
      <table>
        <thead>
          <tr>
            <th>Subject</th>
            <th>Body</th>
            <th>Date</th>
            <td colspan="3">Action</td>
          </tr>
        </thead>
        <?php
        include 'includes/dbh.inc.php';
        $sql = $conn->prepare("SELECT * FROM `news` ORDER BY `news`.`id` DESC");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <tbody>
          <tr>
            <td><?= $row['subj']; ?></td>
            <td><?= $row['body']; ?></td>
            <td><?= $row['newsDate']; ?></td>
            <td><a href="adminHome.php?newshow=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
            <td><a href="adminHome.php?newedit=<?= $row['id']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
            <td><a onclick = "return confirm('Are you sure you want to delete this News/Announcement?')" href="adminHome.php?newdelete=<?= $row['id']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
          </tr>
        </tbody>
        <?php
        }
        ?>
      </table>
    </div>
    <form action="adminActionMsg.php" method="POST" class="control-form" enctype="multipart/form-data">
      <h4>Choose Image</h4>
      <input type = file name=file style="background: #fff;">
      <input type="text" name="subj" class="form-control" placeholder="Enter Subject">
      <textarea name="msg" style="resize: none;" cols="10" rows="6" placeholder="Enter News/Announcement"></textarea>
      <button type="submit" name="submit-news">Post</button>
    </form>
  </div>
</div>
<!--Admin Message/News/Announcement End-->
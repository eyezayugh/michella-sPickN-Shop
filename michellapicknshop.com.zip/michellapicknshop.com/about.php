<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About Us | Michella's Pick N' Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/about.css">
</head>
<body>
   
   <div class="wrapper">
       <div class="section">
           <div class="left-section">
               <div class="content">
                   <div class="title">
                        <h1>About Us</h1>
                            <p>Michella's Pick N' Shop was established last may 2020. The Shop is owned by Ms. Michella C. Caparas. The owner decided to put up the shop because she decided to go home to the Philippines for good after working overseas for about 25 years. The Shop sells imported products such as toiletries like Bath soap, Shampoo, Toothpaste, Cleaning and Beauty.The Shop is located at <span>KM44 Longos Malolos Bulacan</span> The Shop is currently accesible through the laundry business of the owner</p>
    
                       <p class="mentos">We Strive to sell high Quality Products for you and your family</p>
                       <p>Mission: To Sell High Quality Products In The Market Place</p>
                       <p>Vission: To Provide Excelent Customer Service, To Grasp A Foothold In The Market Place</p>
                       
                   </div>
               </div>
           </div>
           <div class="image-section">
           <img src="img/back.jpg" alt="">
           </div>
       </div>
   </div>
   
     <!--  <div class="container">
          <div class="ohbaby">
           <iframe src="https://www.google.com/maps/embed?pb=!3m2!1sen!2sph!4v1603071342984!5m2!1sen!2sph!6m8!1m7!1s9z9f0ROd3Hoo6SqwCkhnxw!2m2!1d14.87273342584342!2d120.7981768986784!3f173.51798443926984!4f7.345974838214559!5f0.7820865974627469" width="100%" height="450"></iframe>
           </div>
           <div class="col-md-3">
                    <h1>Follow Us On</h1>
                    <p><a href="#"><i class="fa fa-facebook-official"></i>  Facebook</a></p>
                    <p><a href="#"><i class="fa fa-twitter"></i>  Twitter</a></p>
                    <p><a href="#"><i class="fa fa-instagram"></i>  Instagram</a></p>
                </div>
       </div> -->
       
       <div class="contact-in">
       <div class="contact-map">
           <iframe src="https://www.google.com/maps/embed?pb=!3m2!1sen!2sph!4v1603071342984!5m2!1sen!2sph!6m8!1m7!1s9z9f0ROd3Hoo6SqwCkhnxw!2m2!1d14.87273342584342!2d120.7981768986784!3f173.51798443926984!4f7.345974838214559!5f0.7820865974627469" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
       </div>
            <div class="contact-form">
                <div class="social-media">
                    <h1>Follow Us On</h1>
                    
            <div class="poop-social">
 
		<div>
		<i class="fa fa-map-marker"></i>
		<p><span>KM44 Longos</span> Malolos Bulacan, Philippines</p>
		</div>
 
		<div>
		<i class="fa fa-phone"></i>
		<p>0953-451-6267</p>
		</div>
 
		<div>
		<i class="fa fa-envelope"></i>
		<p>michella122770@gmail.com</p>
		</div>
 
		</div>
            <div class="footer-icons">
 
		<a href="https://www.facebook.com/WashDateWithUS" target="_blank"><i class="fa fa-facebook"></i></a><b>https://www.facebook.com/WashDateWithUS</b>
                </div>
            </div>
    </div>
    </div>  
       
</body>
</html>
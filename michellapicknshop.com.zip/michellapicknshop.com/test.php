<?php
include 'includes/dbhStore.inc.php';

$stat = $conn->prepare("SELECT prodCode FROM orders WHERE userUid = 'eyezayugh';");
$stat->execute();
$rs = $stat->get_result();
while ($ro = $rs->fetch_assoc()) {
    $prod = $ro['prodCode'];
    $prodAr = explode(',', $prod);
    $length = count($prodAr);
    $i = 0;
    while ($length > $i) {
        $prodAr[$i];
        $prodName = explode('-', $prodAr[$i]);
        $trimName = trim($prodName[0]);
        $trimNum = trim($prodName[1]);
        $statem = $conn->prepare("SELECT * FROM prodcuct WHERE productCode = '$trimName';");
        $statem->execute();
        $rt = $statem->get_result();
        while ($rws = $rt->fetch_assoc()) {
            $stock = $rws['productStock'];
            $stockTots = $stock + $trimNum;
            $sqli = $conn->prepare("UPDATE prodcuct SET productStock = '$stockTots' WHERE productCode = '$trimName';");
            $sqli->execute();
        }
        $i++;
    }
}
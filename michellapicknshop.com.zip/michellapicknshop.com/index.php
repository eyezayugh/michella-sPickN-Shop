<!-- Programmed by: Isaiah John Ching Fernando -->
<?php
include_once 'header.php';
if (isset($_SESSION["usertype"]) ) {
  header("location: index.php");
  session_unset();
  session_destroy();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>" />
    <title>Welcome to Pick N Shop</title>
  </head>
  <body>
    <!-- Showcase $ Nav -->
    <div id="showcase">
      <section class="v-section container">
        <div class="fullscreen-video-wrap">
          <video
            src="img/video.mp4"
            autoplay="true"
            muted="ture"
            loop="true"
          ></video>
        </div>
        <div class="header-overlay"></div>
        <div class="header-content"><img src="img/logo2.png"/></div>
      </section>
    </div>
    <!-- Order & Reseller Section -->
    <section id="overview">
      <div class="box">
        <div class="col">
          <h2>ORDER</h2>
          <div class="caption">
            <p>
              With a few clicks you can easily access our store from the comfort
              of your own home.
            </p>
            <a href="store.php" class="btn">Click Here</a>
          </div>
          <img src="img/img2.png" alt="" />
        </div>
        <div class="col">
          <h2>BECOME A PORTER</h2>
          <div class="caption">
            <p>
              We strive to give our customers the best service, and you can be
              apart of that. So come and signup to become one of our porters.
            </p>
            <a href="signinReseller.php" class="btn">Click Here</a>
          </div>
          <img src="img/img0.png" alt="" />
        </div>
        <div class="col">
          <h2>SIGN UP</h2>
          <div class="caption">
            <p>
              Unlock your inner shopaholic and sign up to enjoy the full
              experience.
            </p>
            <a href="signin.php" class="btn">Click here</a>
          </div>
          <img src="img/img1.png" alt="" />
        </div>
      </div>
    </section>
    <!-- store section-->
    <section id="wrapper" class="skewed">
      <div class="layer bottom">
        <div class="content-wrap">
          <div class="content-body">
            <h1>Visit Our Store</h1>
            <p>
              Are you in the Malolos area? Or just want to adventure to our
              store? Come to our store at km 44 McArthur hi-way Longos Malolos, Bulacan. 
              We are open 9am through 5pm, Monday to Saturday. So come see us and enjoy
              our products first hand.
            </p>
          </div>
          <img src="img/physical.png" alt="" />
        </div>
      </div>
      <div class="layer top">
        <div class="content-wrap">
          <div class="content-body">
            <h1>Check out our store online</h1>
            <p>
              Convenience and the best experience only for our customers. With Loyalty
              points you can get up to 50% off with your next order. So check out
              our website at the comfort of your own home.
            </p>
          </div>
          <img src="img/store-mockup.png" class="imglaptop" />
        </div>
      </div>
      <div class="handle"></div>
    </section>
    <section class="food-btn">
      <div class="box-btn">
        <a href="store.php" class="btn"><i class="fas fa-book-reader"></i> Store</a>
        <a
          href="https://www.facebook.com/washdaywithus"
          target="_blank"
          class="btn2"
          ><i class="fab fa-facebook"></i> Facebook</a
        >
      </div>
    </section>
    <!-- Cart & Payment Section -->
    <section id="cart" class="card section">
      <div class="container">
        <div class="cart">
          <div><img src="img/loyal5.PNG" alt="" /></div>
          <div>
            <h2>Cart & Payments</h2>
            <p>
              Earn Loyalty Points with every PHP 25.00 spent at the shop, and get Loyalty cards that have
              discounts up to 50% OFF of your next order. Sign In now and fill up your cart, we have payment
              methods of Cash on Delivery, Payment on Pickup, and Credit Card.
            </p>
            <p>Access your cart here</p>
            <hr />
            <a href="signin.php"><i class="fas fa-chevron-right"> Click Here</i></a>
          </div>
        </div>
      </div>
    </section>
    
    <?php
      include_once 'footer.php';
    ?>

    <script
      src="https://code.jquery.com/jquery-3.5.1.min.js"
      integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
      crossorigin="anonymous"
    ></script>
    <script src="js/main-food.js"></script>
  </body>
</html>

<?php
session_start();
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];

    require 'includes/dbhStore.inc.php';

    $Total = 0;
    $allItems = '';
    $items = array();

    $sql = "SELECT CONCAT(productName, '(',qty,')') AS ItemQty, totalPrice FROM cart WHERE userName = '$userUid';";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $Total += $row['totalPrice'];
        $items[] = $row['ItemQty'];
    }
    $grandTotal = $Total + 50.00;
    $allItems = implode(", ", $items);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?php echo time(); ?>">
    <title>Store | Michella's Pick N' Shop |<?php echo ' '.$userUid; ?></title>
</head>
<body>
<?php
    if ($userType == 'User' ) {
  ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="userHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    }
    if ($userType == 'Reseller') {
    ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="resellerHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php 
  }?>
  <?php
  if (isset($_GET['error'])) {
    if ($_GET['error'] == 'empty') {
  ?>
  <div class="alert alert-danger alert-dismissible text-center mt-1">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>The Address Field is Empty! Please fill out all fields.</strong>
  </div>
  <?php
    }
    elseif ($_GET['error'] == 'order') {
    ?>
  <div class="alert alert-danger alert-dismissible text-center mt-1">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>You are only allowed 1 order from Cash On Delivery and/or Payment on Pickup Payment Type</strong>
  </div>
    <?php
    }
  }
  ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6 px-4 pb-4" id="order">
                <h4 class="text-center text-info p-2">Complete your order!</h4>
                <div class="jumbotron p-3 mb-2 text-center">
                    <h6 class="lead"><b>Product(s) : </b><?= $allItems; ?></h6>
                    <h6 class="lead"><b>Handling Fee: PHP 50.00</b></h6>
                    <?php
                    include 'includes/dbh.inc.php';
                    $state = $conn->prepare("SELECT * FROM loyalcard WHERE userUid = '$userUid';");
                    $state->execute();
                    $resu = $state->get_result();
                    while($rw = $resu->fetch_assoc()){
                      if ($rw['userUid'] == $userUid) {
                        $d = $rw['loyalDis'];
                        $disc = $d * 100;
                        $discount = $grandTotal * $d;
                        $grandTotal = $grandTotal - $discount;
                    ?>
                    <h5><b>Loyalty Card : <?= $disc;?>%</h5>
                    <?php
                      }
                    }
                    ?>
                    <h5><b>Amount Payable : PHP </b><?= number_format($grandTotal, 2); ?></h5>
                </div>
                <form action="userPay.php" method="POST">
                    <input type="hidden" name="products" value="<?= $allItems ?>">
                    <input type="hidden" name="grandTotal" value="<?= $grandTotal ?>">
                    <h6>Name: <?= $userName ?></h6>
                    <h6>Email: <?= $userEmail ?></h6>
                    <h6>Phone Number: <?= $userPhone ?></h6>
                    <input type="hidden" name="name" class="form-control" value="<?= $userName; ?>" readonly>                  
                    <input type="hidden" name="userUid" class="form-control" value="<?= $userUid; ?>" readonly>
                    <input type="hidden" name="phone" class="form-control" value="<?= $userPhone; ?>" readonly>
                    <input type="hidden" name="email" class="form-control" value="<?= $userEmail; ?>" readonly>
                    <input type="hidden" name="phone" class="form-control" value="<?= $userPhone; ?>" readonly>
                    <?php
                    include 'includes/dbh.inc.php';
                    $sql = "SELECT userAdd FROM users WHERE userUid = '$userUid';";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    while ($row = $result->fetch_assoc()) {
                      $userAddress = $row['userAdd'];
                    if (empty($userAddress)) {
                      ?>
                      <a href="userEditProfile.php">Edit All Info Here</a>
                    <div class="form-group">
                        <textarea name="address" class="form-control" cols="10" rows="3" placeholder="Enter Delivery Address Here"></textarea>
                    </div>
                    <?php 
                    }else {
                    ?>
                    <a href="userEditProfile.php">Edit All Info Here</a>
                    <?php
                    include 'includes/dbh.inc.php';
                    $add = $conn->prepare("SELECT * FROM users WHERE userUid = '$userUid';");
                    $add->execute();
                    $re = $add->get_result();
                    while($rw = $re->fetch_assoc()){
                        $billAdd = $rw['billAdd'];
                        $deliverAdd = $rw['deliverAdd'];
                    }
                    ?>
                    <h6 style="margin-top: 1rem;">Choose Address</h5>
                    <div class="form-group">
                        <input type="radio" id="home" name="address" value="<?= $userAddress ?>">
                        <label for="home">Home Address: <?= $userAddress; ?></label><br>
                        <input type="radio" id="bill" name="address" value="<?= $billAdd; ?>">
                        <label for="bill">Billing Address: <?= $billAdd;?></label><br>
                        <input type="radio" id="deliver" name="address" value="<?= $deliverAdd; ?>" checked>
                        <label for="deliver">Delivery Address: <?= $deliverAdd; ?></label><br>
                    </div>
                    <?php
                    } 
                    }?>
                    <?php
                    include 'includes/dbh.inc.php';
                    $sql = "SELECT * FROM loyalcard WHERE userUid = '$userUid';";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    while ($row = $result->fetch_assoc()) {
                    ?>
                    <h6></h6>
                    <?php 
                    }?>
                    <h6 class="text-center lead">Select Payment Mode</h6>
                    <div class="form-group">
                      <select name="pmode" class="form-control">
                        <option value="" selected disabled>Select Payment Mode</option>
                        <option value="cod">Cash On Delivery</option>                        
                        <option value="pop">Payment On Pickup</option>                        
                        <option value="credit">Credit Card</option>                        
                      </select>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit" value="Place Order" class="btn btn-warning btn-block"></input>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php
      include_once 'footer.php';
    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){

        load_cart_item_number();

        function load_cart_item_number(){
          $.ajax({
            url: 'includes/actionCart.inc.php',
            method: 'get',
            data: {cartItem:"cart_item"},
            success:function(response){
              $("#cart-item").html(response);
            }
          });
        }

      });
    </script>
</body>
</html>
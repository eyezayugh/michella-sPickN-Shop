<?php
if (isset($_GET['printallprod'])) {
    error_reporting(-1);
    ini_set('display_errors', true);
    $title = "Product Catalogue | Michella's Pick N' Shop";
    include 'fpdf/fpdf.php';
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetTitle($title);
    $pdf->SetFont('Arial','', 11);
    $pdf->Image('img/logo2.png', 80, 5, 50);
    $pdf->Cell(0,20,'Product Catalogue',0,1,'C');
    include 'includes/dbhStore.inc.php';
    $sql = "SELECT * FROM prodcuct;";
    $result = $conn->query($sql);
    if($result->num_rows > 0){
      while ($row = $result->fetch_assoc()) {
        $pname = $row['productName'];
        $pdesc = $row['productDesc'];
        $brand = $row['brand'];
        $type = $row['typeProd'];
        $stock = $row['productStock'];
        $pprice = $row['productPrice'];
        $formatpprice = 'php '.number_format($pprice, 2);
        $pdf->Cell(50,5,'Product Name', 1, 1, 'C');
        $pdf->MultiCell(50,5,$pname, 1, 'L');
        $pdf->Cell(99,5,'Product Description', 1, 1, 'C');
        $pdf->MultiCell(99,5,$pdesc, 1, 'L');
        $pdf->Cell(30,5,'Brand', 1, 0, 'C');
        $pdf->Cell(30,5,'Type', 1, 0, 'C');
        $pdf->Cell(14,5,'Stock', 1, 0, 'C');
        $pdf->Cell(25,5,'Product Price', 1, 1, 'C');
        $pdf->Cell(30,10,$brand, 1, 0);
        $pdf->Cell(30,10,$type, 1, 0);
        $pdf->Cell(14,10,$stock, 1, 0, 'C');
        $pdf->Cell(25,10,$formatpprice, 1, 0);
        $pdf->Cell(0,16,'',0,1);
      }
        
    }else{
      $pdf->Cell(100,6,'No Record Found', 0, 0);
    }
    $pdf->Output();
}else{
    die('invalid access');
}
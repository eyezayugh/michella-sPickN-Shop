<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleFAQ.css">
    <title>Michella's Pick N' Shop | FAQ</title>
  </head>
  <body>
    <div class="container-fluid">
      <h2>Frequently Asked Questions (FAQS)</h2>

      <div class="accordian">
        <div class="icon"></div>
        <h5>What payment methods do you accept?</h5>
      </div>
      <div class="panel">
        <p>
          We currently accept payment methods at checkout with payment on pickup, cash on deliver and credit card
        </p>
      </div>

      <div class="accordian">
        <div class="icon"></div>
        <h5>How can I earn Loyalty Points?</h5>
      </div>
      <div class="panel">
        <p>
          You earn Loyalty points with every successful purchase, you can view
          your points on your user account page and you can convert them into
          discount codes for our store.
        </p>
      </div>

      <div class="accordian">
        <div class="icon"></div>
        <h5>What are Loyalty Cards?</h5>
      </div>
      <div class="panel">
        <p>
            Loyalty cards are discount codes given by us to you for a single
            order at our store.
        </p>
      </div>

      <div class="accordian">
        <div class="icon"></div>
        <h5>How do I get Loyalty Cards?</h5>
      </div>
      <div class="panel">
        <p>
            You can get Loyalty Cards by spending your Loyalty points at
            your user account page.
        </p>
      </div>

      <div class="accordian">
        <div class="icon"></div>
        <h5>What are the Terms and Conditions?</h5>
      </div>
      <div class="panel">
        <p>
            <a href="files/Terms&Conditions.pdf" target="_blank"
                >Click here to view our Terms and Conditions</a
            >
        </p>
      </div>

      <div class="accordian">
        <div class="icon"></div>
        <h5>What is your Privacy Policy?</h5>
      </div>
      <div class="panel">
        <p>
            <a href="files/PrivacyPolicy.pdf" target="_blank"
                >Click here to view our Privacy Policy</a
            >
        </p>
      </div>
      
      <div class="accordian">
        <div class="icon"></div>
        <h5>How do I contact you for more information?</h5>
      </div>
      <div class="panel">
        <p>
            You can contact us via Email: michella122770@gmail.com, phone:
                09610913468, or go to our
                <a
                  href="https://www.facebook.com/washdaywithus"
                  target="_blank"
                  >Facebook Page</a
                >
                and ,message us there.
        </p>
        </div>
  </div>
        <script src="js/faq.js"></script>
  </body>
</html>

<!--Programmed by: Isaiah John Ching Fernando-->
<!--Order product start-->
<div class="container-user">
<a href="deliveryHome.php" class="btn-deliver" target="_blank">Delivery Home</a>
<!--top order product start-->
<div class="top-customer">
  <h4 class="title">Customer Orders</h4>
  <form action="" method="POST" class="search-form">
    <input type="text" name="search" class="search-customer" placeholder="Search">
    <button type="submit" name="submit-searchOrder" class="btn-search"><i class="fas fa-search"></i></button>
  </form>
</div>
<!--top order product end-->
<!--bottom product item start-->
<div class="bottom-order">
  <!--search order start-->
  <div class="record-right">
    <?php
    include 'includes/dbhStore.inc.php';
    if (isset($_POST['submit-searchOrder'])) {
      $space = '/\s/';
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $sql="SELECT * FROM orders WHERE userName LIKE '%$search%' OR userUid LIKE '%$search%' OR userEmail LIKE '%$search%' OR userPhone LIKE '%$search%' OR userAdd LIKE '%$search%' OR products LIKE '%$search%' OR orderStatus LIKE '%$search%' OR orderDate LIKE '%$search%' OR userName LIKE '%$space%' OR userUid LIKE '%$space%' OR userEmail LIKE '%$space%' OR userPhone LIKE '%$space%' OR userAdd LIKE '%$space%' OR products LIKE '%$space%' OR orderStatus LIKE '%$space%' OR orderDate LIKE '%$space%';";
      $result = mysqli_query($conn, $sql);
      $queryResult = mysqli_num_rows($result);

      if ($queryResult > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if($row['orderStatus'] == 'Pending' && $row['porter'] == ''){
            include 'includes/dbhStore.inc.php';
            $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Pending' AND porter = '' ORDER BY `id` DESC;");
            $sql->execute();
            $result = $sql->get_result();
            while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPay.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Ordered: <?= $row['orderDate'];?></p>
                <a href="adminHome.php?cancelOrder=<?=$row['id'];?>" class="btn-cancel" onclick="return confirm('Are you sure you want to cancel the order?');">Cacel Order</a>
            </div>
            <div class="right-order">
                <div>
                    <img src="qr/<?= $row['orderCode'] ?>.png" alt="" />
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download">Download QR Code</a>
                </div>
                <div>
                    <form action="actionAdminHome.php" method="POST" class="assign-form">
                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                        <select name="porter" class="form-control">
                          <option value="" selected disabled>Select Porter to Assign order to</option>
                          <?php
                          include 'includes/dbh.inc.php';
                          $stmt = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Deliver';");
                          $stmt->execute();
                          $res = $stmt->get_result();
                          while($rw = $res->fetch_assoc()){
                          ?>
                          <option value="<?= $rw['userUid']; ?>"><?= $rw['userName'].' - '.$rw['userUid'];?></option>
                          <?php
                          }
                          ?>
                        </select>
                        <button type="submit" name="submit-assignOrder" class="btn-assign">Assign</button><br>
                    </form>
                </div>
            </div>
          </div>
        </div>
        <?php
            }
          }
          elseif($row['porter'] != ''){
            include 'includes/dbh.inc.php';
        $stmt = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Deliver';");
        $stmt->execute();
        $res = $stmt->get_result();
        while($rw = $res->fetch_assoc()){
        $porter = $rw['userUid'];
        $porterName = $rw['userName'];
        include 'includes/dbhStore.inc.php';
        $sql = $conn->prepare("SELECT * FROM orders WHERE porter = '$porter' ORDER BY `id` DESC;");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPay.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Ordered: <?= $row['orderDate'];?></p>
                <a href="adminHome.php?cancelOrder=<?=$row['id'];?>" class="btn-cancel" onclick="return confirm('Are you sure you want to cancel the order?');">Cacel Order</a>
            </div>
            <div class="right-order">
                <div style="display: grid; grid-template-columns: 1fr;">
                    <p>Porter: <?=$porterName.' - '.$porter?></p>
                    <p>Order Status: <?= $row['orderStatus']; ?></p>
                    <img src="qr/<?= $row['orderCode'] ?>.png"/>
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download" style="width: 180px;" >Download QR Code</a>
                </div>
            </div>
          </div>
        </div>
        <?php
              }
            }
          }
        }
    ?>
    </table>
    <?php
      }
      else{
    ?>
    <h4 style="color: red; text-align: center;">No Results Found</h4>
    <!--search order end-->
    <?php
      }
    }else{
    ?>
    <div class="view-order">
        <!--Pending order start-->
        <div class="order-title">
            <h5>Pending Orders</h5>
        </div>
        <?php
        include 'includes/dbhStore.inc.php';
        $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Pending' AND porter = '' ORDER BY `id` DESC;");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPay.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Ordered: <?= $row['orderDate'];?></p>
                <?php
                if($row['pmode'] == 'pop'){
                ?>
                <a href="adminHome.php?pickupOrder=<?=$row['id'];?>" class="btn-cancel" style="background: green;" onclick="return confirm('Are you sure you want to approve order?');">Order Ready for Pickup</a>
                <?php
                }
                ?>
                <a href="adminHome.php?cancelOrder=<?=$row['id'];?>" class="btn-cancel" onclick="return confirm('Are you sure you want to cancel the order?');">Cancel Order</a>
            </div>
            <div class="right-order">
                <div>
                    <img src="qr/<?= $row['orderCode'] ?>.png" alt="" />
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download">Download QR Code</a>
                </div>
                <div>
                    <form action="actionAdminHome.php" method="POST" class="assign-form">
                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                        <select name="porter" class="form-control">
                          <option value="" selected disabled>Select Porter to Assign order to</option>
                          <?php
                          include 'includes/dbh.inc.php';
                          $stmt = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Deliver';");
                          $stmt->execute();
                          $res = $stmt->get_result();
                          while($rw = $res->fetch_assoc()){
                          ?>
                          <option value="<?= $rw['userUid']; ?>"><?= $rw['userName'].' - '.$rw['userUid'];?></option>
                          <?php
                          }
                          ?>
                        </select>
                        <button type="submit" name="submit-assignOrder" class="btn-assign">Assign</button><br>
                    </form>
                </div>
            </div>
          </div>
        </div>
        <?php
        }
        ?>
        <?php
        include 'includes/dbhStore.inc.php';
        $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Ready for Pickup' AND porter = '' ORDER BY `id` DESC;");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPay.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Ordered: <?= $row['orderDate'];?></p>
                <?php
                if($row['pmode'] == 'pop'){
                ?>
                <a href="adminHome.php?pickupSuccess=<?=$row['id'];?>" class="btn-cancel" style="background: green;">Pickup Completed</a>
                <?php
                }
                ?>
                <a href="adminHome.php?cancelOrder=<?=$row['id'];?>" class="btn-cancel" onclick="return confirm('Are you sure you want to cancel the order?');">Cancel Order</a>
            </div>
            <div class="right-order">
                <div>
                    <img src="qr/<?= $row['orderCode'] ?>.png" alt="" />
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download">Download QR Code</a>
                </div>
                <div>
                    <form action="actionAdminHome.php" method="POST" class="assign-form">
                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                        <select name="porter" class="form-control">
                          <option value="" selected disabled>Select Porter to Assign order to</option>
                          <?php
                          include 'includes/dbh.inc.php';
                          $stmt = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Deliver';");
                          $stmt->execute();
                          $res = $stmt->get_result();
                          while($rw = $res->fetch_assoc()){
                          ?>
                          <option value="<?= $rw['userUid']; ?>"><?= $rw['userName'].' - '.$rw['userUid'];?></option>
                          <?php
                          }
                          ?>
                        </select>
                        <button type="submit" name="submit-assignOrder" class="btn-assign">Assign</button><br>
                    </form>
                </div>
            </div>
          </div>
        </div>
        <?php
        }
        ?>
        <!--Pending Order end-->
        <!--Assigned order start-->
        <div class="order-title" style="color: #ded335; margin-top: 1rem;">
            <h5>Assigned Orders</h5>
        </div>
        <?php
        include 'includes/dbh.inc.php';
        $stmt = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Deliver';");
        $stmt->execute();
        $res = $stmt->get_result();
        while($rw = $res->fetch_assoc()){
        $porter = $rw['userUid'];
        $porterName = $rw['userName'];
        include 'includes/dbhStore.inc.php';
        $sql = $conn->prepare("SELECT * FROM orders WHERE porter = '$porter' AND orderStatus != 'Canceled by the Store' ORDER BY `id` DESC;");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPay.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Ordered: <?= $row['orderDate'];?></p>
                <a href="adminHome.php?cancelOrder=<?=$row['id'];?>" class="btn-cancel" onclick="return confirm('Are you sure you want to cancel the order?');">Cacel Order</a>
            </div>
            <div class="right-order">
                <div style="display: grid; grid-template-columns: 1fr;">
                    <p>Porter: <?=$porterName.' - '.$porter?></p>
                    <p>Order Status: <?= $row['orderStatus']; ?></p>
                    <img src="qr/<?= $row['orderCode'] ?>.png"/>
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download" style="width: 180px;" >Download QR Code</a>
                </div>
            </div>
          </div>
        </div>
        <?php
          }
        }
        ?>
        <!--Delivered order start-->
        <div class="order-title" style="color: #3CAB1F; margin-top: 1rem;">
            <h5>Delivered Orders</h5>
        </div>
        <?php
        include 'includes/dbhStore.inc.php';
        $sql = $conn->prepare("SELECT * FROM archorder WHERE orderStatus = 'Delivered' ORDER BY `id` DESC;");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPayArch.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Delivered: <?= $row['cancelDate'];?></p>
            </div>
            <div class="right-order">
                <div style="display: grid; grid-template-columns: 1fr;">
                    <p>Order Status: <?= $row['orderStatus']; ?></p>
                    <img src="qr/<?= $row['orderCode'] ?>.png"/>
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download" style="width: 180px;" >Download QR Code</a>
                </div>
            </div>
          </div>
        </div>
        <?php
        }
        ?>
        <!--Delivered order end-->
        <!--Canceled orders start-->
        <div class="order-title" style="color: #DA0202; margin-top: 1rem;">
            <h5>Canceled/Refunded Orders</h5>
        </div>
        <?php
        include 'includes/dbhStore.inc.php';
        $sql = $conn->prepare("SELECT * FROM archorder WHERE orderStatus != 'Delivered' ORDER BY `id` DESC;");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPayArch.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Delivered: <?= $row['cancelDate'];?></p>
            </div>
            <div class="right-order">
                <div style="display: grid; grid-template-columns: 1fr;">
                    <p>Order Status: <?= $row['orderStatus']; ?></p>
                    <img src="qr/<?= $row['orderCode'] ?>.png"/>
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download" style="width: 180px;" >Download QR Code</a>
                </div>
            </div>
          </div>
        </div>
        <?php
        }
        ?>
        <?php
        include 'includes/dbhStore.inc.php';
        $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Canceled by the Store' ORDER BY `id` DESC;");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
        ?>
        <div class="display-box">
          <div class="box-order">
            <div class="left-order">
                <a href="userPrintPay.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-print">Print Receipt</a>
                <p>Order Code: <?= $row['orderCode'];?></p>
                <p>Delivery Address: <?= $row['userAdd'];?></p>
                <p>Email: <?= $row['userEmail'];?></p>
                <p>Phone Number: <?= $row['userPhone'];?></p>
                <p>Products: <?= $row['products'];?></p>
                <?php
                if($row['pmode'] == 'cod'){
                ?>
                <p>Payment Type: Cash On Delivery</p>
                <?php 
                }
                if($row['pmode'] == 'pop'){
                ?>
                <p>Payment Type: Payment On Pickup</p>
                <?php 
                }
                if($row['pmode'] == 'credit'){
                ?>
                <p>Payment Type: Credit Card</p>
                <?php }?>
                <p>Total: php <?= number_format($row['amountPaid'], 2);?></p>
                <p>Date Delivered: <?= $row['orderDate'];?></p>
            </div>
            <div class="right-order">
                <div style="display: grid; grid-template-columns: 1fr;">
                    <p>Order Status: <?= $row['orderStatus']; ?></p>
                    <img src="qr/<?= $row['orderCode'] ?>.png"/>
                    <a href="qrDownload.php?file=<?= $row['orderCode']; ?>.png" class="btn-download" style="width: 180px;" >Download QR Code</a>
                </div>
            </div>
          </div>
        </div>
        <?php
        }
        ?>
        <!--Canceled orders end-->
    </div>
    <?php
    }
    mysqli_close($conn);
    ?>
  </div>
  <!--assigned order end-->
</div>
<!--Order product end-->
</div>
<!--Order product end-->
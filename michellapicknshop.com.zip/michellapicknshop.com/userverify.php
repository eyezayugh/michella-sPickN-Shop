<?php
  //Process Verification
  if(isset($_GET['vkey'])){
    $vkey = $_GET['vkey'];

    include 'includes/dbh.inc.php';

    $resultSet = $conn->query("SELECT verified,vKey FROM users WHERE verified = 0 AND vKey = '$vkey' LIMIT 1");

    if($resultSet->num_rows == 1){
      //validate email
      $update = $conn->query("UPDATE users SET verified = 1 WHERE vKey = '$vkey' LIMIT 1");
      if ($update) {
        echo '';
      }else{
        echo $conn->error;
      }
    }else{
      die("Account is Invalid or Already Verified");
    }

  }else{
    die("Invalid Access.");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleVerify.css" />
    <title>User Verification | Michelle's Pick N' Shop</title>
  </head>
  <body>
    <section>
      <div class="container">
        <div class="box">
          <div class="strokeme">
            <h2>Welcome To</h2>
          </div>
          <img style="width: 600px;" src="img/logo2.png" alt="image logo" />
          <p>
            <i class="fas fa-user-lock"></i> Your Account Has Now Been Verified
          </p>
          <a href="signin.php" class="btn">Sign In</a>
        </div>
      </div>
    </section>
  </body>
</html>

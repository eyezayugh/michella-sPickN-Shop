<!-- Programmed by: Isaiah John Ching Fernando -->
<?php
if (isset($_POST['order'])) {
    $id = $_POST['orderId'];
    include_once 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("UPDATE orders SET orderStatus = 'Scan' WHERE id = '$id';");
    $sql->execute();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleDelAction.css?v=<?php echo time(); ?>">
    <title>Deliver | Michella's Pick N' Shop</title>
</head>
<body>
    <div class="container">
        <div class="box">
            <div class="title">
                <h5>Please Scan QR Code from Customer</h5>
            </div>
            <div class="icon">
                <i class="fas fa-qrcode"></i>
            </div>
        </div>
    </div>
</body>
</html>
<?php
}
elseif (isset($_GET['code'])) {
    error_reporting(-1);
    ini_set('display_errors', true);
    $orderCode = $_GET['code'];
    include_once 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM orders WHERE orderCode = '$orderCode';");
    $sql->execute();
    $result = $sql->get_result();
    while ($row = $result->fetch_assoc()) {
        $userName = $row['userName'];
        $userUid = $row['userUid'];
        $userEmail = $row['userEmail'];
        $userPhone = $row['userPhone'];
        $userAddress = $row['userAdd'];
        $pmode = $row['pmode'];
        $products = $row['products'];
        $grandTotal = $row['amountPaid'];
        $code = $row['orderCode'];
        $pCode = $row['prodCode'];
        $status = $row['orderStatus'];
        if($status !== 'Scan'){
            header("location: index.php");
            exit();
        }
        elseif ($code != $orderCode) {
            header("location: index.php");
            exit();
        }else {
            $query = $conn->prepare("INSERT INTO archorder (userName, userUid , userEmail, userPhone, userAdd, pmode, products, amountPaid, orderCode, prodCode, orderStatus) VALUES ( '$userName', '$userUid', '$userEmail', '$userPhone', '$userAddress', '$pmode', '$products', '$grandTotal', '$code', '$pCode', 'Delivered');");
            $query->execute();
            
            $stmt = $conn->prepare("DELETE FROM orders WHERE orderCode = '$code';");
            $stmt->execute();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/824d2c43ce.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/styleDelAction.css?v=<?php echo time(); ?>">
    <title>Deliver | Michella's Pick N' Shop</title>
</head>
<body>
    <div class="container">
        <div class="box">
            <div class="title">
                <h5>Order Delivered</h5>
            </div>
            <div class="icon">
                <i class="far fa-check-circle" style="color: #1e681e; font-size: 15rem;"></i>
            </div>
        </div>
    </div>
</body>
</html>

<?php
        }
    }
}else {
    echo 'Invalid Access';
}
?>
<?php
session_start();
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$userType = $_SESSION["usertype"];
if ($userType == 'User') {
    header("location: userHome.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1.0">
    <title>MICHELLA'S PICK N' SHOP</title>
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleReseller.css?v=<?php echo time(); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
<body>
   <div class="header">
   <div class="container">
       <div class="navbar">
            <div class="logo">
                <a href="index.html"><img src="img/logo2.png" width="200px"></a>
            </div>
        <nav>
            <ul id="MenuItems">
                <li><a href="resellerHome.php">Home</a></li>
                <li><a href="userStore.php">Store</a></li>
                <li><a href="userProfile.php"><i class="fas fa-user-circle"></i></a></li>
            </ul>
        </nav>
        <a href="userCart.php"><img src="img/cart.png" width="30px" height="30px"></a>
        <img src="img/menu.png" class="menu-icons" onclick="menutoggle()">
    </div>
    <div class="row">
        <div class="col-2">
            <h1>Michella's<br>Pick N' Shop</h1>
            <p>Where here you can shop online with affordable price</p>
        </div>
            <div class="col-2">
            <img src="img/slider3.jpg">
            </div>
        </div>
    </div>
</div>

<!-----------------FEATURED CATEGORIES------------------>
<div class="categories">
   <div class="small-container">
       <div class="row-cat">
        <div class="col3">
            <img src="img/loyal1.png">
        </div>
        <div class="col3">
            <img src="img/loyal2.png">
        </div>
        <div class="col3">
            <img src="img/loyal3.png">
        </div>
        <div class="col3">
            <img src="img/loyal4.jpg">
        </div>
        <div class="col3">
            <img src="img/loyal5.png">
        </div>
    </div>
   </div>
</div>

<!-----------------FEATURED PRODUCTS------------------>
    <div class="small-container">
        <h2 class="title">Featured Products</h2>
        <div class="row">
<?php
include 'includes/dbhStore.inc.php';
$sql = $conn->prepare("SELECT * FROM prodcuct WHERE feature =1;");
$sql->execute();
$result = $sql->get_result();
while ($row = $result->fetch_assoc()){
?>
            <div class="col-4">
                <a href="userStoreInfo.php?product=<?= $row['id']; ?>"><img src="<?= $row['productImage'];  ?>"></a>
                <h4><?= $row['productName']; ?></h4>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <p><?= $row['productPrice']; ?></p>
            </div>
<?php }?>
        </div>
    </div>
    
    
    <!------Offer------>
    
    <div class="offer">
        <div class="small-container">
            <div class="row">
                <div class="col-2">
                    <img src="products/lotionDove2.PNG" class="offer-img">
                </div>
                <div class="col-2">
                    <p>Available on Michella's Pick 'N Shop</p>
                    <h1>Dove Lotion</h1>
                    <small>Velvety body lotions transform your skin care routine into a moment of ‘me-time’ while giving your body the dermatological care it needs</small>
                    <a href="userStoreInfo.php?product=55" class="btn">Buy Now &#8594;</a>
                </div>

            </div>
        </div>
    </div>
    
    <!------------------TESTIMONIAL-------------------->
    
    <div class="testimonial">
        <div class="small-container">
            <div class="row">
                <div class="col-3">
                   <i class="fa fa-quote-left"></i>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus saepe sed laborum quae ducimus impedit non. Ad impedit libero eum quo nam, quia debitis totam facilis, eaque sit asperiores sapiente!</p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <img src="img/user-1.png">
                <h3>Sherry Note</h3>
                </div>
                
                <div class="col-3">
                   <i class="fa fa-quote-left"></i>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus saepe sed laborum quae ducimus impedit non. Ad impedit libero eum quo nam, quia debitis totam facilis, eaque sit asperiores sapiente!</p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <img src="img/user-2.png">
                <h3>Sing Song</h3>
                </div>
                
                <div class="col-3">
                   <i class="fa fa-quote-left"></i>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minus saepe sed laborum quae ducimus impedit non. Ad impedit libero eum quo nam, quia debitis totam facilis, eaque sit asperiores sapiente!</p>
                <div class="rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
                <img src="img/user-3.png">
                <h3>Yeah Baby</h3>
                </div>
            </div>
        </div>
    </div>
    
     <!------------------Brands-------------------->
     <div class="brands">
         <div class="small-container">
             <div class="row">
                 <div class="col-5">
                     <a href="userStore.php?brand=Dove"><img src="img/dove.png"></a>
                 </div>
                 
                 <div class="col-5">
                     <a href="userStore.php?brand=Jif"><img src="img/jif.jpg"></a>
                 </div>
                 
                 <div class="col-5">
                     <a href="userStore.php?brand=Nivea"><img src="img/nivea.png"></a>
                 </div>
                 
                 <div class="col-5">
                     <a href="userStore.php?brand=Johnson"><img src="img/johnsons.jpg"></a>
                 </div>
                 
                 <div class="col-5">
                     <a href="userStore.php?brand=Clear"></a><img src="img/clear.jpg">
                 </div>
             </div>
         </div>
     </div>
    
    
    <!------------------FOOTER-------------------->
    <div class="footer">
        <div class="container">
            <div class="row">
               <div class="footer-col-2">
                    <img src="img/ex.png" alt="">
                    <p>To make our Customers enjoy and look for their favorite items here</p>
                </div>
               
                <div class="footer-col-3">
                    <h3>Useful Links</h3>
                    <ul>
                        <li>Terms and Conditions</li>
                        <li>Return Policy</li>
                        <li>Coupons</li>
                    </ul>
                </div>
                
                <div class="footer-col-4">
                    <h3>Follow Us</h3>
                    <ul>
                        <li>Facebook</li>
                        <li>Twitter</li>
                        <li>Instagram</li>
                    </ul>
                </div>
            </div>
            <hr>
            <p class="copyright">Copyright 2020 - Michella's Pick 'N Shop</p>
        </div>
    </div>
    
   <script>
        var MenuItems = document.getElementById("MenuItems");
       
        MenuItems.style.maxHeight = "0px";
        
        function menutoggle(){
            if(MenuItems.style.maxHeight == "0px"){
                
                MenuItems.style.maxHeight = "200px";
            }
            else{
                MenuItems.style.maxHeight = "0px";
            }
        }
    </script>
</body>
</html>
<!--Programmed by: Isaiah John Ching Fernando-->
<?php
session_start();
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];
$loyalpts = $_SESSION['loyalPts'];

if(isset($_POST['submitReview'])){
  $msg = $_POST['msg'];
  $code = $_POST['code'];
  include 'includes/dbhStore.inc.php';
  
  if(empty($msg) || empty($code)){
    header("location: userReview.php?error=empty");
    exit();
  }
  $stmt = mysqli_query($conn, "SELECT orderCode FROM userReview WHERE orderCode = '$code';") or exit(mysqli_error($sql));
  if(mysqli_num_rows($stmt)){
    header("location: userReview.php?error=exist");
    exit();
  }
  $type = 'order';
  $sql = $conn->prepare("INSERT INTO userReview (userUid, orderCode, review, revType) VALUES (?, ?, ?, ?);");
  $sql->bind_param("ssss", $userUid, $code, $msg, $type);
  $sql->execute();
  header("location: userReview.php?success=sent");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/824d2c43ce.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?= time(); ?>">
    <title>Michella's Pick N' Shop | Send a Review</title>
</head>
<body>
    <?php
    if ($userType == "User" ) {
  ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="userHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    }?>
    <!-- Error Messages -->
    <div class="message" id="message">
    <?php
    if (isset($_GET['success'])) {
      if ($_GET['success'] == 'sent') {
    ?>
    <div class="alert alert-success alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Your Review has been sent and posted, Thank you</strong>
    </div>
    <?php 
      }
    }
    if (isset($_GET['error'])) {
      if ($_GET['error'] == 'empty') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Please fill in all fields</strong>
    </div>
    <?php
      }
      elseif ($_GET['error'] == 'exist') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>You already have a review of this product</strong>
    </div>
    <?php
      }
    }
     ?>
    <div class="container mb-5">
      <div class="m-2 p-1">
        <?php
        if(isset($_GET['order'])){
            $orderCode = $_GET['order'];
        }
        ?>
        <h5 class="text-primary">Review Your Order</h5>
        <?php
        if(empty($orderCode)){
        ?>
        <h6 class="text-secondary" style="font-size: 15px;">Order Code: <p style="color: red;">Go back to your orders and click the "Send a Review" button to send us a review again</p></h6>
        <?php
        }else{
        ?>
        <h6 class="text-secondary" style="font-size: 15px;">Order Code: <?= $orderCode; ?></h6>
        <?php
        }
        ?>
        <h6 class="text-secondary" style="font-size: 12px;">This is used to send us reviews of your order, if found abusing this funtion your account will be deleted. For more information <i class="fas fa-chevron-right"></i> <a href="files/Terms&Conditions.pdf" target="_blank" style="text-decoration: none;" class="m-1">Terms & Conditions</a></h6>
      </div>
      <form action="" method="POST" enctype="multipart/form-data" class="m-1">
        <input type="hidden" name="code" value="<?= $orderCode; ?>">
        <textarea name="msg" class="form-control m-1" style="resize: none;" cols="10" rows="3" maxlength="474" placeholder="Enter Your Review of your Order"></textarea>
        <button type="submit" name="submitReview" class="btn btn-warning m-1"> Post Review</button>
        <a href="userProfile.php" class="btn btn-danger m-1">Cancel</a>
      </form>
      <a href="termscondition.php" target="_blank" style="text-decoration: none;" class="m-1">Terms & Conditions</a>
      <br>
      <a href="privacypolicy.php" target="_blank" style="text-decoration: none;" class="m-1">Privacy Policy</a>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
include 'footer.php';
?>
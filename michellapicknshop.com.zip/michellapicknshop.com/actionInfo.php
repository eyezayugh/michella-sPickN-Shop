<!-- Programmed by: Isaiah John Ching Fernando-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/magnify.css?v=<?php echo time(); ?>" />
    <link rel="stylesheet" href="css/mobileother.css?v=<?php echo time(); ?>">
    <title>Product Info | Michella's Pick N' Shop</title>
  </head>
  <body class="bg-light">
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="index.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="store.php">Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="store.php?error=signin"><i class="fab fa-opencart" style="color: #49b7ca;"></i></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="signin.php">Sign In</a>
          </li>
        </ul>
      </div>
    </nav>
    <div class="container">
      <div class="row m-5">
        <?php
          if (isset($_GET['id'])) {
            $id = $_GET['id'];
            include 'includes/dbhStore.inc.php';
            $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE id ='$id';");
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()){
        ?>
        <div class="card p-2 border-left justify-content-center m-2 ml-5 pl-5" style="display: grid; grid-template-columns: repeat(3, 1fr);">
          <div>
            <img src="<?=$row['productImage'];?>" width="250" id="image" class="zoom" data-magnify-src="<?=$row['productImage'];?>">
          </div>
          <div>
            <h3 class="text-center"><?=$row['productName'];?></h3>
            <p class="text-xl-left"><?=$row['productDesc']; ?></p>
            <p style="font-size: 1.5rem; color: #49b7ca;">PHP <?=$row['productPrice']; ?></p>
          </div>
          <div class="col ml-4">
            <div class="row">
              <a href="store.php?error=signin" class="btn btn-info m-2">Add to Cart</a>
            </div>
            <div class="row">
              <a href="store.php" class="btn btn-info m-2">Back to Store</a>
            </div>
          </div>
        </div>
        <?php 
          }
        }else{
          echo 'NO ITEM SELECTED!';
        }
        ?>
      </div>
    </div>
    <div class="container">
      <div class="row justify-content-center">
        <h5 class="text-center text-info" style="text-transform: uppercase; letter-spacing: 2px;">Similar Products</h5>
      </div>
    </div>
    <div class="container">
      <div class="row mt-2 pb-3">
        <?php
        include 'includes/dbhStore.inc.php';
        $id = $_GET['id'];
        $sql = $conn->prepare("SELECT * FROM prodcuct WHERE id = '$id';");
        $sql->execute();
        $res = $sql->get_result();
        while($rw = $res->fetch_assoc()){
          $brand = $rw['brand'];
          $type = $rw['typeProd'];
          $space = '/\s/';
          $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE brand LIKE '%$brand%' OR typeProd LIKE '%$type%';");
          $stmt->execute();
          $result = $stmt->get_result();
          while ($row = $result->fetch_assoc()){
          ?>
          <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
            <div class="card-deck">
              <div class="card p-2 border-bottom md-2">
                <a href="actionInfo.php?id=<?=$row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="180"></a>
                <div class="card-body p-1">
                  <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
                  <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                </div>
                <div class="card-footer p-1 pb-2">
                  <a href="store.php?error=signin" class="btn btn-warning btn-block"><i class="fas fa-shopping-cart"></i> Add to cart</a>
                </div>
              </div>
            </div>
          </div>
        <?php 
        } 
      }?>
      </div>
    </div>

    <?php
      include_once 'footer.php';
    ?>
    <script src="js/jquery.magnify.js" charset="UTF-8"></script>
    <script>
    $(document).ready(function() {
      $('.zoom').magnify();
    });
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
<!-- Programmed by: Isaiah John Ching Fernando -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign in & Sign Up</title>
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleLogin.css" />
  </head>
  <body>
    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
          <form action="includes/reset-request.inc.php" method="POST" class="sign-in-form">
            <h2 class="title">Reset Password</h2>
            <p>An e-mail will be sent to you with instructions on how to reset your password</p>
            <?php
              if (isset($_GET["error"])) {
                if ($_GET["error"] == "invalidemail") {
                  echo "<p class='error'>Invalid Email Address</p>";
                }
                if ($_GET["error"] == "notexists") {
                  echo "<p class='error'>Email Address Does Not Exists</p>";
                }
                if ($_GET["error"] == "empty") {
                  echo "<p class='error'>Please enter your email address</p>";
                }
              }
              if (isset($_GET["reset"])) {
                if ($_GET["reset"] == "success") {
                  echo "<p class='success'>Please Check Your Email</p>";
                }
              }
            ?>
            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name="email" placeholder="Enter yor Email Address" />
            </div>
            <input type="submit" name="reset-request-submit" value="Submit Request" class="btn solid" />
            <a href="index.php" class="btn2 solid">Cancel</a>
          </form>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h3>Remember your password ?</h3>
            <p>
              We miss you, come back and login. And start shopping now.
            </p>
            <a href="signin.php" class="btn" style="text-decoration: none;">Sign in</a>
          </div>
          <img src="img/repass.svg" class="image" alt="" />
        </div>
      </div>
    </div>
  </body>
</html>
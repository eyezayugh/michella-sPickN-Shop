<!--Programmed by: Isaiah John Ching Fernando-->
<?php
session_start();
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];
$loyalpts = $_SESSION['loyalPts'];

if(isset($_POST['submit'])){
  $id = $_POST['id'];
  error_reporting(-1);
  ini_set('display_errors', true);
  include 'includes/dbhStore.inc.php';
  $sql = $conn->prepare("SELECT * FROM archorder WHERE id = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
      $orderCode = $row['orderCode'];
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Refund Order | Michella's Pick N' Shop</title>
    <script src="https://kit.fontawesome.com/824d2c43ce.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?= time(); ?>">
  </head>
  <body>
      <?php
    if ($userType == "User" ) {
  ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="userHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    }?>
    <!-- Error Messages -->
    <div class="message" id="message">
    <?php
    if (isset($_GET['success'])) {
      if ($_GET['success'] == 'request') {
    ?>
    <div class="alert alert-success alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Your request has been successfuly submmited, please wait for an email to be sent to you</strong>
    </div>
    <?php 
      }
    }
    if (isset($_GET['error'])) {
      if ($_GET['error'] == 'empty') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Please fill in all fields</strong>
    </div>
    <?php 
      }
      elseif ($_GET['error'] == 'refundexist') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>You already have a request submited</strong>
    </div>
    <?php 
      }
      elseif ($_GET['error'] == 'expire') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Your refund date has passed, please refer to ><a href="termscondition.php" target="_blank" style="text-decoration: none;">Terms & Conditions</a></strong>
    </div>
    <?php 
      }
      elseif ($_GET['error'] == 'imgsize') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Your refund date has passed, please refer to ><a href="termscondition.php" target="_blank" style="text-decoration: none;">Image size is too big, please try again</a></strong>
    </div>
    <?php 
      }
      elseif ($_GET['error'] == 'upload') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Your refund date has passed, please refer to ><a href="termscondition.php" target="_blank" style="text-decoration: none;">There was an error uploading, please try again</a></strong>
    </div>
    <?php 
      }
      elseif ($_GET['error'] == 'imgtype') {
    ?>
    <div class="alert alert-danger alert-dismissible  m-2">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Your refund date has passed, please refer to ><a href="termscondition.php" target="_blank" style="text-decoration: none;">File type is not allowed. jpg, jpeg and png only</a></strong>
    </div>
    <?php 
      }
    }
     ?>
    </div>
    <div class="container mb-5">
      <div class="m-2 p-1">
        <h5 class="text-primary">Refund Request</h5>
        <?php
        if(empty($orderCode)){
          echo '<h6 style="color:darkred;">Go back to user account to request refund again';
        }else{
          echo "<h6>Of order: $orderCode</h6>";
        }
        ?>
      </div>
      <form action="actionRefund.php" method="POST" enctype="multipart/form-data" class="m-1">
        <h6>Upload Piture of Product</h6>
        <input type="hidden" name="code" value="<?=$orderCode;?>">
        <input type="file" name="file">
        <textarea name="desc" class="form-control m-1" style="resize: none;" cols="10" rows="3" placeholder="Enter why you want to refund the product and give a description of the product"></textarea>
        <button type="submit" name="submit" class="btn btn-warning m-1" <?php if(empty($orderCode)){echo 'style="background: #777;" disabled';}?>> Request Refund</button>
        <a href="userProfile.php" class="btn btn-danger m-1">Cancel</a>
      </form>
      <a href="termscondition.php" target="_blank" style="text-decoration: none;" class="m-1">Terms & Conditions</a>
      <br>
      <a href="privacypolicy.php" target="_blank" style="text-decoration: none;" class="m-1">Privacy Policy</a>
    </div>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
include'footer.php';
?>
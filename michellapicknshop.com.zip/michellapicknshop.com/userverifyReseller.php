<?php
include 'includes/dbh.inc.php';
$num=1;
if (isset($_POST['submit'])) {
  $vkey = $_GET["vkey"];

  $file = $_FILES['file'];

  $fileName = $_FILES['file']['name'];
  $fileTmpName = $_FILES['file']['tmp_name'];
  $fileSize = $_FILES['file']['size'];
  $fileError = $_FILES['file']['error'];
  $fileType = $_FILES['file']['type'];

  $fileExt = explode('.', $fileName);
  $fileActualExt = strtolower(end($fileExt));

  $allowed = array('jpg', 'jpeg', 'png');

  if (in_array($fileActualExt, $allowed)) {
    if($fileError === 0){
      if($fileSize < 5000000){
        $sql = "SELECT * FROM useradmin WHERE userUid = '$vkey';";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
            $fileNameNew = $id.".".$fileActualExt;
            $fileDestination = 'resellerID/'.$fileNameNew;
            move_uploaded_file($fileTmpName, $fileDestination);
            $insert = $conn->query("INSERT INTO idvalid(userId, nameFile) VALUES('$id', '$fileNameNew');");
            //Process Verification
            if(isset($_GET['vkey'])){
              header("location: userverifyReseller.php?upload=success");
              $num = 2;
              return $num;
  
            }else{
              die("Invalid Access.");
            }
          }
        }else{
          echo 'There is an error';
        }
      }else{
        echo "You are only allowed to upload image that is less than 50mb";
      }
    }else{
      echo "There was an error uploading your image, please try again.";
    }
  }else{
    echo"You cannot upload files of this type! Please upload an image(jpg, jpeg, png).";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleVerify.css?v=<?php echo time();?>" />
    <title>Porter Verification | Michelle's Pick N' Shop</title>
  </head>
  <body>
    <section>
      <div class="container">
        <div class="box">
          <img style="width: 400px;" src="img/logo2.png" alt="image logo" class="image2"/>
          <p>Only 2 more steps to go!</p>
          <div class="strokeme">
            <h3>Step 1</h3>
          </div>
          <p>Upload your Valid ID </p>
          <?php
            if (isset($_GET["upload"])) {
              if ($_GET["upload"] == "success") {
                echo "<p style='color: green;'>ID uploaded successfuly</p>";
                $num = 2;
              }
            }
          ?>
          <form action="" method="POST" enctype="multipart/form-data">
            <input type="file" name="file"<?php if($num == 2){?>disabled style="border: 3px solid #888; color: #888;"<?php } ?>>
            <button type="submit" name="submit" class="btn" <?php if($num == 2){?>disabled style="border: 3px solid #666; color: #eee; background-color:#888;"<?php } ?>>Upload</button>
          </form>
          <a href="files/Terms&conditions.pdf" target="_blank" style="text-decoration: none; color:darkturquoise; font-size: 0.8rem;"> Terms and Conditions </a>
          <a href="files/PrivacyPolicy.pdf" target="_blank" style="text-decoration: none; color:darkturquoise; font-size: 0.8rem;"> Privacy Policy </a>
          <button onclick="show_hide()" class="btn2" <?php if($num == 1){?>disabled style="border: 3px solid #888; color: #888;"<?php } ?>>Continue</button>
          <div id="show">
            <div class="strokeme">
              <h3>Step 2</h3>
            </div>
            <p>Wait for your ID to be validated and we will call you on your phone for an interview. After the interview an email will be sent for a link to sign in to your account. This might take some time
            </p><br>
            <a href="index.php" class="btn">Michella's Pick N' Shop</a>
            <p>Once you have access to your account you will have pending orders that will be assigned to you. Deliver your assigned order and follow the instructions on your account</p>
          </div>
        </div>
      </div>
    </section>
    <script src="js/showreseller.js"></script>
  </body>
</html>
<!--Programmed by: Isaiah John Ching Fernando-->
<?php
if(isset($_POST['submit'])){
    $orderCode = $_POST['code'];
    $description = $_POST['desc'];
    $file = $_FILES['file'];
    
    include 'includes/dbhStore.inc.php';
    
    if(empty($description) || empty($file) || empty($orderCode)){
        header("location: userRefund.php?error=empty");
        exit();
    }
    $sql = mysqli_query($conn, "SELECT orderCode FROM refundorder WHERE orderCode = '$orderCode';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        header("location: userRefund.php?error=refundexist");
        exit();
    }
    $stmt = $conn->prepare("SELECT cancelDate FROM archorder WHERE orderCode = '$orderCode';");
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()){
        $startdate = $row['cancelDate'];
        $expire = strtotime($startdate. ' + 5 days');
        $today = strtotime("today midnight");
    }
    if($expire <= $today){
        header("location: userRefund.php?error=expire");
        exit();
    }
    
    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png');

    if (in_array($fileActualExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 1000000) {
                $fileNameNew = $orderCode.'.'.$fileActualExt;
                $fileDestination = 'refund/'.$fileNameNew;
                move_uploaded_file($fileTmpName, $fileDestination);
                $insert = $conn->query("INSERT INTO refundorder (orderCode, prodimg, prodDesc) VALUES ('$orderCode', '$fileDestination', '$description');");
                if ($insert) {
                    $update = $conn->prepare("UPDATE archorder SET orderStatus = 'Refund Request' WHERE orderCode = '$orderCode';");
                    $update->execute();
                    header("location: userRefund.php?success=request");
                    exit();
                }else {
                    echo $conn->error;
                }
            }else {
                header("location: userRefund.php?error=imgsize");
                exit();
            }
        }else {
            header("location: userRefund.php?error=upload");
            exit();
        }
    }else {
        header("location: userRefund.php?error=imgtype");
        exit();
    }
}
else{
    header("location: ../userProfile.php");
    exit();
}
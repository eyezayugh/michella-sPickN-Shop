<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Developers | Michella's Pick N' Shop</title>
    <link rel="stylesheet" href="css/styleDev.css" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
  </head>
  <body>
    <div class="portfolio">
      <header>
        <nav>
          <a href="https://michellapicknshop.com/"
            ><h3 class="logo">Michella's Pick N' Shop</h3></a
          >
        </nav>
        <main>
          <section class="page Developer">
            <div class="details">
              <h1>Isaiah John C. Fernando</h1>
              <h2>Full Stack Web Developer</h2>
              <div class="socials">
                <a
                  href="https://www.facebook.com/isaiahjohn.fernando/"
                  target="_blank"
                  ><h2><i class="fab fa-facebook"></i></h2
                ></a>
                <a
                  href="https://www.instagram.com/isaiahfernando/?hl=en"
                  target="_blank"
                  ><h2><i class="fab fa-instagram"></i></h2
                ></a>
                <h2>isaiahjohn28@gmail.com</h2>
              </div>
            </div>
            <div class="hero">
              <img class="model-left" src="img/isaiah-left.png" alt="" />
              <img class="model-right" src="img/isaiah-right.png" alt="" />
            </div>
          </section>

          <section class="page Web">
            <div class="details">
              <h1>John Maverick C. Nazario</h1>
              <h2>Web Designer</h2>
              <div class="socials">
                <a href="https://www.facebook.com/jm.nazario.5/" target="_blank"
                  ><h2><i class="fab fa-facebook"></i></h2
                ></a>
                <a
                  href="https://www.instagram.com/jm_nazario/?hl=en"
                  target="_blank"
                  ><h2><i class="fab fa-instagram"></i></h2
                ></a>
                <h2>jmnazario123@gmail.com</h2>
              </div>
            </div>
            <div class="hero">
              <img class="model-left" src="./img/jm-left.png" alt="" />
              <img class="model-right" src="./img/jm-right.png" alt="" />
            </div>
          </section>

          <section class="page documentation">
            <div class="details">
              <h1>Zarina Aryss C. Santos</h1>
              <h2>Lead Documentation</h2>
              <div class="socials">
                <a href="https://www.facebook.com/malditha.08/" target="_blank"
                  ><h2><i class="fab fa-facebook"></i></h2
                ></a>
                <a
                  href="https://www.instagram.com/malditha.08/?hl=en"
                  target="_blank"
                  ><h2><i class="fab fa-instagram"></i></h2
                ></a>
                <h2>ynah.0709@gmail.com</h2>
              </div>
            </div>
            <div class="hero">
              <img class="model-left" src="./img/left-image.png" alt="" />
              <img class="model-right" src="./img/right-image.png" alt="" />
            </div>
          </section>

          <section class="page documentation-two">
            <div class="details">
              <h1>Michaela Marie B. Valentino</h1>
              <h2>Member / Documentation</h2>
            </div>
            <div class="hero">
              <img class="model-left" src="img/mic-left.png" alt="" />
              <img class="model-right" src="img/mic-right.png" alt="" />
            </div>
          </section>

          <div class="pages">
            <div class="page-1">
              <h3>01</h3>
              <svg
                class="slide active"
                width="12"
                height="12"
                viewBox="0 0 12 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6" cy="6" r="6" fill="white" />
              </svg>
            </div>

            <div class="page-2">
              <h3>02</h3>
              <svg
                class="slide"
                width="12"
                height="12"
                viewBox="0 0 12 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6" cy="6" r="6" fill="white" />
              </svg>
            </div>

            <div class="page-3">
              <h3>03</h3>
              <svg
                class="slide"
                width="12"
                height="12"
                viewBox="0 0 12 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6" cy="6" r="6" fill="white" />
              </svg>
            </div>

            <div class="page-4">
              <h3>04</h3>
              <svg
                class="slide"
                width="12"
                height="12"
                viewBox="0 0 12 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <circle cx="6" cy="6" r="6" fill="white" />
              </svg>
            </div>
          </div>
        </main>
      </header>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TimelineMax.min.js"></script>
    <script src="js/appDev.js"></script>
  </body>
</html>

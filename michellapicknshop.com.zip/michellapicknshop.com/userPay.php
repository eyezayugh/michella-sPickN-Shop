<!-- Programmed by: Isaiah John Ching Fernando -->
<?php
include 'header.php';
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$loyalpts = $_SESSION['loyalPts'];

include 'includes/dbhStore.inc.php';
$statement = "SELECT userName FROM orders WHERE pmode = 'cod' AND userUid = '$userUid'";
$res = mysqli_query($conn, $statement);
$numRow = mysqli_num_rows($res);
if ($numRow >= 1) {
    header("location: userCheckout.php?error=order");
    exit();
}
mysqli_free_result($res);
$statement = "SELECT userName FROM orders WHERE pmode = 'pop' AND userUid = '$userUid'";
$res = mysqli_query($conn, $statement);
$numRow = mysqli_num_rows($res);
if ($numRow >= 1) {
    header("location: userCheckout.php?error=order");
    exit();
}
include 'includes/dbhStore.inc.php';
if (isset($_POST['submit'])) {
    $products = $_POST['products'];
    $address = $_POST['address'];
    $grandTotal = $_POST['grandTotal'];
    $pmode = $_POST['pmode'];
    
    if (empty($address) || empty($pmode)) {
        header("location: userCheckout.php?error=empty");
        exit();
    }
    elseif (empty($products)) {
        header("location: userCheckout.php?error=prod");
        exit();
    }
    elseif($pmode == "credit"){
        include 'creditcard.php';
    }
    else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/stylePay.css?v=<?php echo time(); ?>">
    <title>Payments | Michella's Pick N' Shop</title>
</head>
<body>
<?php
        function generateRandomString($length = 12){
            return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
        }

        $orderCode = $userUid."_".generateRandomString(12);

        $a = "SELECT CONCAT(productCode, '-',qty) AS code FROM cart WHERE userName = '$userUid';";
        $state = $conn->prepare($a);
        $state->execute();
        $resu = $state->get_result();
        while ($rows = $resu->fetch_assoc()) {
            $code[] = $rows['code'];
        }
        $allcode = implode(",", $code);
        $status = 'Pending';

        $query = $conn->prepare("INSERT INTO orders (userName, userUid ,userEmail, userPhone, userAdd, pmode, products, amountPaid, orderCode, prodCode, orderStatus) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $query->bind_param("sssssssssss", $userName, $userUid, $userEmail, $userPhone, $address, $pmode, $products, $grandTotal, $orderCode, $allcode, $status);
        $query->execute();

        $s = $conn->prepare("SELECT * FROM cart WHERE userName = '$userUid';");
        $s->execute();
        $r = $s->get_result();
        while ($ro = $r->fetch_assoc()) {
            $pname = $ro['productName'];
            $pqty = $ro['qty'];
            $pcode = $ro['productCode'];
            $b = $conn->prepare("SELECT productStock FROM prodcuct WHERE productCode = '$pcode';");
            $b->execute();
            $v = $b->get_result();
            while ($x = $v->fetch_assoc()) {
                $stock = $x['productStock'];
                $total = $stock - $pqty;
                $a = $conn->prepare("UPDATE prodcuct SET productStock = '$total' WHERE productName = '$pname';");
                $a->execute();
            }
        }

        $stmt = $conn->prepare("DELETE FROM cart WHERE userName = '$userUid';");
        $stmt->execute();

        $pts = $grandTotal / 25;
        $numLoyal = $loyalpts + $pts;
        $_SESSION['loyalPts'] = $numLoyal;

        mysqli_close($conn);

        include 'includes/dbh.inc.php';

        $sql = $conn->prepare("INSERT INTO qrcode (userUid, orderCode) VALUES('$userUid', '$orderCode')");
        $sql->execute();

        $st = $conn->prepare("UPDATE users SET loyalpts = '$numLoyal' WHERE userUid = '$userUid';");
        $st->execute();

        $s = $conn->prepare("DELETE FROM loyalcard WHERE userUid = '$userUid';");
        $s->execute();

        // info to send email
    $to = $userEmail;
    $subject = "Product Order | Michelle's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title> Product Order | Michella\'s Pick N\' Shop</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michelle\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Thank you for Ordering</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you, because you ordered at our store. Do not reply to this message.</center></i>

            <p><center>Hey '.$userName.', thank you for your order.</center></p>
            <p><center>You have Earned '.$pts.' Loyalty Points with your order</center></p>
            <p><center>For More Information Login To Your Account and view in your Profile (Orders section)</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/signin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Sign In</a>
            </center></p>
            <p style="padding: 1rem; margin: 0.2rem 1rem;">If you didn\'t purchase this order, cancel your order at your account in your profile <a href="https://michellapicknshop.com/signin.php">Click Here</a></p>
            
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michelle's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);

        include('libs/phpqrcode/qrlib.php'); 
        if ($pmode == "cod") {
            $qrDir = 'qr/';
            $filename = $orderCode;
            $codeContents = "https://michellapicknshop.com/deliveryAction.php?code=$orderCode";
            QRcode::png($codeContents, $qrDir.''.@$filename.'.png', QR_ECLEVEL_L, 5);
    ?>
    <div class="space">
    </div>
    <div class="title">
        <h4>Thank You For Your Purchase</h4>
    </div>
    <div class="container-qr">
        <div class="box-content">
            <div class="qr-text">
                <h6>Name: <?= $userName; ?></h6>
                <h6>Email: <?= $userEmail; ?></h6>
                <h6>Phone Number: <?= $userPhone; ?></h6>
                <h6>Delivery Address: <?= $address; ?></h6>
                <h6>Payment Type: Cash on Delivery</h6>
                <h6>Order Code: <?= $orderCode; ?></h6>
                <h6>Products: <?= $products ?></h6>
                <h6>Grand Total: PHP <?= number_format($grandTotal,2); ?></h6>
                <a href="userPrintPay.php?print=<?= $orderCode; ?>" class="btn-qr" target="_blank" style="background-color: #777; color:#eee;">Print Receipt</a>
            </div>
            <div class="qr-code">
                <h6>Your order will arrive around 3-4 business days</h6>
                <h6>Download or screenshot your qr code and show it to us when we show up at your door to confirm the delivery. This will also be located at your user account.</h6>
                <img src="qr/<?= $filename?>.png" alt="">
                <a href="qrDownload.php?file=<?= $filename; ?>.png" class="btn-qr">Download QR Code</a>
            </div>
        </div>
    </div>
    <?php
        }
        elseif ($pmode == "pop") {
            $qrDir = 'qr/';
            $filename = $orderCode;
            $codeContents = "https://michellapicknshop.com/deliveryAction.php?code=$orderCode";
            QRcode::png($codeContents, $qrDir.''.@$filename.'.png', QR_ECLEVEL_L, 5);
    ?>
    <div class="space">
    </div>
    <div class="title">
        <h4>Thank You For Your Purchase</h4>
    </div>
    <div class="container-qr">
        <div class="box-content">
            <div class="qr-text">
                <h6>Name: <?= $userName; ?></h6>
                <h6>Email: <?= $userEmail; ?></h6>
                <h6>Phone Number: <?= $userPhone; ?></h6>
                <h6>Delivery Address: <?= $address; ?></h6>
                <h6>Payment Type: Cash on Delivery</h6>
                <h6>Order Code: <?= $orderCode; ?></h6>
                <h6>Products: <?= $products ?></h6>
                <h6>Grand Total: <?= number_format($grandTotal,2); ?></h6>
                <a href="userPrintPay.php?print=<?= $orderCode; ?>" class="btn-qr" target="_blank" style="background-color: #777; color:#eee;">Print Receipt</a>
            </div>
            <div class="qr-code">
                <h6 style="color: gold;">You have 3 days to Pickup your order, after the 3 days, your order will be null and void.</h6>
                <h6 style="color: turquoise;">Location: km 44 McArthur hi-way Longos Malolos, Bulacan</h6>
                <h6>Download or screenshot your qr code and show it to us when you arrive at our shop. This will also be located at your user account.</h6>
                <img src="qr/<?= $filename?>.png" alt="">
                <a href="qrDownload.php?file=<?= $filename; ?>.png" class="btn-qr">Download QR Code</a>
            </div>
        </div>
    </div>
    <?php
        }
      }
    }else{
        header("location: userCheckout.php");
        exit();
    }
    ?>
    <?php
    include 'footer.php';
    ?>
</body>
</html>
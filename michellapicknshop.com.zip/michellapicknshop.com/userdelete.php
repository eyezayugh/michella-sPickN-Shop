<?php
  //Process Verification
  if(isset($_GET['user'])){
    $user = $_GET['user'];

    $conn = new mysqli('localhost', 'root', '', 'useracc');

    $sql = "DELETE FROM users WHERE userUid = '$user'";

    if ($conn->query($sql) === true) {
        echo"<h2 style='font-size: 1rem; color: green; padding: 1rem; margin: 1rem;'><center>The account has been deleted, thank you for your cooperation</center></h2>";
    }else{
        echo "<h2 style='font-size: 1rem; color: red; padding: 1rem; margin: 1rem;'><center>Error Deleting Record</center></h2>";
    }

    $conn->close();
  }else{
      die("Something went wrong");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleVerify.css" />
    <title>User Deletion | Michelle's Pick N' Shop</title>
  </head>
  <body>
  </body>
</html>
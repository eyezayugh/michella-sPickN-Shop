<!-- Programmed by: Isaiah John Ching Fernando -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign in & Sign Up</title>
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleLoginReseller.css?v=<?php echo time(); ?>" />
  </head>
  <body>
    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
          <form class="sign-in-form">
            <p style="color: #388694;">Porter</p>
            <h2 class="title">Sign in</h2>
            <?php
              if (isset($_GET["error"])) {
                if ($_GET["error"] == "emptyinput") {
                  echo "<p class='error'>Fill in all fields</p>";
                }
                else if ($_GET["error"] == "invalidname") {
                  echo "<p class='error'>Invalid Name</p>";
                }
                else if ($_GET["error"] == "invaliduid") {
                  echo "<p class='error'>Invalid Username</p>";
                }
                else if ($_GET["error"] == "invalidemail") {
                  echo "<p class='error'>Invalid Email</p>";
                }
                else if ($_GET["error"] == "invalidphone") {
                  echo "<p class='error'>Invalid Phone Number</p>";
                }
                else if ($_GET["error"] == "pwdnotmatch") {
                  echo "<p class='error'>Passwords Do Not Match</p>";
                }
                else if ($_GET["error"] == "usertaken") {
                  echo "<p class='error'>Username and/or Email is already taken</p>";
                }
                else if ($_GET["error"] == "emailexist") {
                    echo "<p class='error'>Email Address is already taken</p>";
                }
                else if ($_GET["error"] == "phoneexist") {
                    echo "<p class='error'>Phone number is already taken</p>";
                }
                else if ($_GET["error"] == "usernotexists") {
                  echo "<p class='error'>Username/Email does not exists</p>";
                }
                else if ($_GET["error"] == "srtunam") {
                    echo "<p class='error'>Username must be at least 4 - 18 characters long</p>";
                  }
                  else if ($_GET["error"] == "numln") {
                    echo "<p class='error'>Please Enter a valid Phone number</p>";
                  }
                  else if ($_GET["error"] == "pwdln") {
                    echo "<p class='error'>Please Enter a valid password</p>";
                  }
                else if ($_GET["error"] == "wronglogin") {
                  echo "<p class='error'>Your password is incorrect</p>";
                }
                else if ($_GET["error"] == "numln") {
                  echo "<p class='error'>Please Enter a valid Phone number</p>";
                }
                else if ($_GET["error"] == "pwdln") {
                  echo "<p class='error'>Please Enter a valid password</p>";
                }
                else if ($_GET["error"] == "none") {
                  echo "<p class='success'>Sign Up Successful. An email will be sent to you fo further instructions</p>";
                }
              }
              if (isset($_GET["newpwd"])){
                if ($_GET["newpwd"] == "passwordupdated") {
                  echo "<p class='success'>Password Updated</p>";
                }
              }
            ?>
            <p>Use the link in your Email to sign in to your account</p>
            <a href="index.php" class="btn2 solid">Cancel</a>
            <p class="social-text">Or Are you a normal Customer?</p>
            <a href="signin.php"><i class="fas fa-chevron-right"> Clcik Here</i></a>
          </form>
          <form action="includes/signupreseller.inc.php" method="POST" enctype="multipart/form-data" class="sign-up-form">
            <h2 class="title">Sign up</h2>
            <?php
              if (isset($_GET["error"])) {
                if ($_GET["error"] == "emptyinput") {
                  echo "<p class='error'>Fill in all fields</p>";
                }
                else if ($_GET["error"] == "invalidname") {
                  echo "<p class='error'>Invalid Name</p>";
                }
                else if ($_GET["error"] == "invaliduid") {
                  echo "<p class='error'>Invalid Username</p>";
                }
                else if ($_GET["error"] == "invalidemail") {
                  echo "<p class='error'>Invalid Email</p>";
                }
                else if ($_GET["error"] == "invalidphone") {
                  echo "<p class='error'>Invalid Phone Number</p>";
                }
                else if ($_GET["error"] == "pwdnotmatch") {
                  echo "<p class='error'>Passwords Do Not Match</p>";
                }
                else if ($_GET["error"] == "usertaken") {
                    echo "<p class='error'>Username is already taken</p>";
                }
                else if ($_GET["error"] == "emailexist") {
                    echo "<p class='error'>Email Address is already taken</p>";
                }
                else if ($_GET["error"] == "phoneexist") {
                    echo "<p class='error'>Phone number is already taken</p>";
                }
                else if ($_GET["error"] == "srtunam") {
                  echo "<p class='error'>Username must be at least 4 - 18 characters long</p>";
                }
                else if ($_GET["error"] == "numln") {
                  echo "<p class='error'>Please Enter a valid Phone number</p>";
                }
                else if ($_GET["error"] == "pwdln") {
                  echo "<p class='error'>Please Enter a valid password</p>";
                }
                else if ($_GET["error"] == "none") {
                  echo "<p class='success'>Sign Up Successful. An email verification has been sent</p>";
                }
              }
            ?>
            <input type="hidden" name="type" value="Pending">
            <div class="field-input">
              <div class="left">
                <div class="input-field">
                  <i class="fas fa-signature"></i>
                  <input type="text" name="name" placeholder="Full Name" />
                </div>
                <div class="input-field">
                  <i class="fas fa-user"></i>
                  <input type="text" name="uid" placeholder="Username" />
                </div>
                <div class="input-field">
                  <i class="fas fa-envelope"></i>
                  <input type="email" name="email" placeholder="Email" />
                </div>
              </div>
              <div class="right">
                <div class="input-field">
                  <i class="fas fa-phone"></i>
                  <input type="tel" name="phone" placeholder="Phone Number" />
                </div>
                <div class="input-field">
                  <i class="fas fa-lock"></i>
                  <input type="password" name="pwd" placeholder="Password" />
                </div>
                <div class="input-field">
                  <i class="fas fa-lock"></i>
                  <input type="password" name="pwdrepeat" placeholder="Confirm Password" />
                </div>
              </div>
            </div>
            <div class="terms">
              <input type="checkbox" class="checkbox" value="read" id="read" onclick="EnableDisable()"> 
              <p>I have Read and Agree to the <a href="files/Terms&Conditions.pdf" target="_blank">Terms and Conditions</a>
              and <a href="files/PrivacyPolicy.pdf" target="_blank">Privacy Policy</a></p>
            </div>
            <input type="submit" name="submit" class="btn" value="Sign up" id="btn" disabled="disabled" style="background-color: #888;"/>
            <a href="index.php" class="btn2 solid">Cancel</a>
            <p class="social-text">
              Or are you a normal Customer?
              <a href="signin.php"><i class="fas fa-chevron-right"> Clcik Here</i></a>
            </p>
          </form>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h3>New here ?</h3>
            <p>
              Come signup and be part of our Pick N' Shop family. Start now and be one of us.
            </p>
            <button class="btn transparent" id="sign-up-btn">Sign up</button>
          </div>
          <img src="img/resellerlogin.svg" class="image" alt="" />
        </div>
        <div class="panel right-panel">
          <div class="content">
            <h3>One of us ?</h3>
            <p>
              Start your delivery Now.
            </p>
            <button class="btn transparent" id="sign-in-btn">Sign in</button>
          </div>
          <img src="img/resellersignup.svg" class="image" alt="" />
        </div>
      </div>
    </div>

    <script type="text/javascript">

      function EnableDisable()
      {
        var read = document.getElementById("read");

        if (read.checked) {
          document.getElementById("btn").style.backgroundColor = "#388694";
          const btn = document.getElementById("btn");
          btn.disabled = false;
        }
        else{
          document.getElementById("btn").style.backgroundColor = "#888";
          const btn = document.getElementById("btn");
          btn.disabled = true;
        }
      }

    </script>

    <script src="js/signin.js"></script>
  </body>
</html>
<!--Programmed by: Isaiah John Ching Fernando-->
<?php
//Customer Account Start
//Add Customer Account Start
if (isset($_POST['submit-acc'])) {

    $name = $_POST['name'];
    $username = $_POST['uid'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $pwd = $_POST['pwd'];
    $verify = 0;
    $type = "User";
    $vkey = md5(time().$username);

    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';

    if (emailExist($conn, $email) !== false) {
        header("location: adminHome.php?error=emailexist");
        exit();
    }
    if (userExist($conn, $username) !== false) {
        header("location: adminHome.php?error=usertaken");
        exit();
    }
    if (phoneExist($conn, $phone) !== false) {
        header("location: adminHome.php?error=phoneexist");
        exit();
    }
    if (empty($address) || empty($name) || empty($username) || empty($email) || empty($phone) || empty($pwd)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    if (invalidName($name) !== false) {
        header("location: adminHome.php?error=invalidname");
        exit();
    }
    if (invalidUid($username) !== false) {
        header("location: adminHome.php?error=invaliduid");
        exit();
    }
    if (invalidEmail($email) !== false) {
        header("location: adminHome.php?error=invalidemail");
        exit();
    }
    if (invalidPhone($phone) !== false) {
        header("location: adminHome.php?error=invalidphone");
        exit();
    }
    if (uidExists($conn, $username, $email) !== false) {
        header("location: adminHome.php?error=usertaken");
        exit();
    }
    if (strlen($username) < 4 || strlen($username) > 19) {
        header("location: adminHome.php?error=srtunam");
        exit();
    }
    if (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: adminHome.php?error=numln");
        exit();
    }
    if (strlen($pwd) < 4 || strlen($pwd) > 20) {
        header("location: adminHome.php?error=pwdln");
        exit();
    }

    AddUserfrAdmin($conn, $name, $username, $email, $phone, $address, $pwd, $verify, $type, $vkey);
}
//Add Customer Account End
//Edit Customer Account Start
elseif(isset($_POST['submit-editacc'])){
  
    $id = $_POST['id'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $verify = $_POST['verified'];
  
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
  
    if (empty($address) || empty($name)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    elseif (invalidName($name) !== false) {
        header("location: adminHome.php?error=invalidname");
        exit();
    }
    else{
        
        $sql = $conn->prepare("UPDATE users SET userName = '$name', userAdd = '$address', verified = '$verify' WHERE userId = '$id';");
        $sql->execute();
        header("location: adminHome.php?usershow=$id");
        exit();
    }
  
}
elseif(isset($_POST['submit-editaccUid'])){
    
    $id = $_POST['id'];
    $username = $_POST['uid'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if(empty($username)){
        header("location: adminHome.php?error=empty");
        exit();
    }
    elseif (invalidUid($username) !== false) {
        header("location: adminHome.php?error=invaliduid");
        exit();
    }
    elseif (strlen($username) < 4 || strlen($username) > 19) {
        header("location: adminHome.php?error=srtunam");
        exit();
    }
    elseif (userExist($conn, $username) !== false) {
        header("location: adminHome.php?error=usertaken");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE users SET userUid = ? WHERE userId = '$id';");
        $sql->bind_param("s", $username);
        $sql->execute();
        header("location: adminHome.php?usershow=$id");
        exit();
    }
}
elseif(isset($_POST['submit-editaccEmail'])){
    
    $id = $_POST['id'];
    $email = $_POST['email'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if (emailExist($conn, $email) !== false) {
        header("location: adminHome.php?error=emailexist");
        exit();
    }
    elseif (invalidEmail($email) !== false) {
        header("location: adminHome.php?error=invalidemail");
        exit();
    }
    elseif (empty($email)){
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE users SET userEmail = ? WHERE userId = '$id';");
        $sql->bind_param("s", $email);
        $sql->execute();
        header("location: adminHome.php?usershow=$id");
        exit();
    }
}
elseif(isset($_POST['submit-editaccPhone'])){
    
    $id = $_POST['id'];
    $phone = $_POST['phone'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if (phoneExist($conn, $phone) !== false) {
        header("location: adminHome.php?error=phoneexist");
        exit();
    }
    elseif (invalidPhone($phone) !== false) {
        header("location: adminHome.php?error=invalidphone");
        exit();
    }
    elseif (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: adminHome.php?error=numln");
        exit();
    }
    elseif (empty($phone)){
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE users SET userPhone = '$phone' WHERE userId = '$id';");
        $sql->execute();
        header("location: adminHome.php?usershow=$id");
        exit();
    }
}
elseif(isset($_POST['submit-editaccPwd'])){
    
    $id = $_POST['id'];
    $pwd= $_POST['pwd'];
    
    require 'includes/dbh.inc.php';
    
    if (empty($pwd)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        
        $newPwdHash = password_hash($pwd, PASSWORD_DEFAULT);
        
        $sql = $conn->prepare("UPDATE users SET userPwd = '$newPwdHash' WHERE userId = '$id';");
        $sql->execute();
        header("location: adminHome.php?usershow=$id");
        exit();
    }
}
//Edit Customer Account End
//Customer Account End
//Admin Account Start
//add admin account start
elseif(isset($_POST['submit-Adminacc'])){
    
    $name = $_POST['name'];
    $username = $_POST['uid'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $pwd = $_POST['pwd'];
    $type = $_POST['type'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';

    if (adminEmailExist($conn, $email) !== false) {
        header("location: adminHome.php?error=emailexist");
        exit();
    }
    elseif (adminUserExist($conn, $username) !== false) {
        header("location: adminHome.php?error=usertaken");
        exit();
    }
    elseif (adminPhoneExist($conn, $phone) !== false) {
        header("location: adminHome.php?error=phoneexist");
        exit();
    }
    elseif (empty($name) || empty($username) || empty($email) || empty($phone) || empty($type) || empty($pwd)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    elseif (invalidName($name) !== false) {
        header("location: adminHome.php?error=invalidname");
        exit();
    }
    elseif (invalidUid($username) !== false) {
        header("location: adminHome.php?error=invaliduid");
        exit();
    }
    elseif (invalidEmail($email) !== false) {
        header("location: adminHome.php?error=invalidemail");
        exit();
    }
    elseif (invalidPhone($phone) !== false) {
        header("location: adminHome.php?error=invalidphone");
        exit();
    }
    elseif (strlen($username) < 4 || strlen($username) > 19) {
        header("location: adminHome.php?error=srtunam");
        exit();
    }
    elseif (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: adminHome.php?error=numln");
        exit();
    }
    elseif (strlen($pwd) < 4 || strlen($pwd) > 20) {
        header("location: adminHome.php?error=pwdln");
        exit();
    }
    else{
        createAdminUser($conn, $name, $username, $email, $phone, $type, $pwd);
    }
}
//add admin account end
//edit admin account start
elseif(isset($_POST['adminSubmit-editaccUid'])){
    $id = $_POST['id'];
    $username = $_POST['uid'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if(empty($username)){
        header("location: adminHome.php?error=empty");
        exit();
    }
    elseif (invalidUid($username) !== false) {
        header("location: adminHome.php?error=invaliduid");
        exit();
    }
    elseif (strlen($username) < 4 || strlen($username) > 19) {
        header("location: adminHome.php?error=srtunam");
        exit();
    }
    elseif (adminUserExist($conn, $username) !== false) {
        header("location: adminHome.php?error=usertaken");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE useradmin SET userUid = ? WHERE id = '$id';");
        $sql->bind_param("s", $username);
        $sql->execute();
        header("location: adminHome.php?adminshow=$id");
        exit();
    }
}
elseif(isset($_POST['adminSubmit-editaccEmail'])){
    
    $id = $_POST['id'];
    $email = $_POST['email'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if (adminEmailExist($conn, $email) !== false) {
        header("location: adminHome.php?error=emailexist");
        exit();
    }
    elseif (invalidEmail($email) !== false) {
        header("location: adminHome.php?error=invalidemail");
        exit();
    }
    elseif (empty($email)){
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE useradmin SET userEmail = '$email' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?adminshow=$id");
        exit();
    }
}
elseif(isset($_POST['adminSubmit-editaccPhone'])){
    
    $id = $_POST['id'];
    $phone = $_POST['phone'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if (adminPhoneExist($conn, $phone) !== false) {
        header("location: adminHome.php?error=phoneexist");
        exit();
    }
    elseif (invalidPhone($phone) !== false) {
        header("location: adminHome.php?error=invalidphone");
        exit();
    }
    elseif (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: adminHome.php?error=numln");
        exit();
    }
    elseif (empty($phone)){
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE useradmin SET userPhone = '$phone' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?adminshow=$id");
        exit();
    }
}
elseif(isset($_POST['adminSubmit-editacc'])){
  
    $id = $_POST['id'];
    $name = $_POST['name'];
    $type = $_POST['type'];
  
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
  
    if (empty($type) || empty($name)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    elseif (invalidName($name) !== false) {
        header("location: adminHome.php?error=invalidname");
        exit();
    }
    else{
        
        $sql = $conn->prepare("UPDATE useradmin SET userName = '$name', userType = '$type' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?adminshow=$id");
        exit();
    }
}
elseif(isset($_POST['adminSubmit-editaccPwd'])){
    
    $id = $_POST['id'];
    $pwd= $_POST['pwd'];
    
    require 'includes/dbh.inc.php';
    
    if (empty($pwd)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        
        $newPwdHash = password_hash($pwd, PASSWORD_DEFAULT);
        
        $sql = $conn->prepare("UPDATE useradmin SET userPwd = '$newPwdHash' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?adminshow=$id");
        exit();
    }
}
//edit admin account end
//Admin Account End
//Porter Account Start
//add porter start
elseif(isset($_POST['submit-Deliveracc'])){
    
    $name = $_POST['name'];
    $username = $_POST['uid'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $pwd = $_POST['pwd'];
    $type = $_POST['type'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if(empty($name) || empty($username) || empty($email) || empty($phone) || empty($pwd) || empty($type)){
        header("location: adminHome.php?adminHome.php?users=porters");
        exit();
    }
    elseif (adminEmailExist($conn, $email) !== false) {
        header("location: adminHome.php?error=emailexist");
        exit();
    }
    elseif (adminUserExist($conn, $username) !== false) {
        header("location: adminHome.php?error=usertaken");
        exit();
    }
    elseif (adminPhoneExist($conn, $phone) !== false) {
        header("location: adminHome.php?error=phoneexist");
        exit();
    }
    elseif (invalidName($name) !== false) {
        header("location: adminHome.php?error=invalidname");
        exit();
    }
    elseif (invalidUid($username) !== false) {
        header("location: adminHome.php?error=invaliduid");
        exit();
    }
    elseif (invalidEmail($email) !== false) {
        header("location: adminHome.php?error=invalidemail");
        exit();
    }
    elseif (invalidPhone($phone) !== false) {
        header("location: adminHome.php?error=invalidphone");
        exit();
    }
    elseif (strlen($username) < 4 || strlen($username) > 19) {
        header("location: adminHome.php?error=srtunam");
        exit();
    }
    elseif (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: adminHome.php?error=numln");
        exit();
    }
    elseif (strlen($pwd) < 4 || strlen($pwd) > 20) {
        header("location: adminHome.php?error=pwdln");
        exit();
    }
    else{
        createAdminUser($conn, $name, $username, $email, $phone, $type, $pwd);
    }
}
//add porter end
//edit porter start
elseif(isset($_POST['porterSubmit-editaccUid'])){
    $id = $_POST['id'];
    $username = $_POST['uid'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if(empty($username)){
        header("location: adminHome.php?error=empty");
        exit();
    }
    elseif (invalidUid($username) !== false) {
        header("location: adminHome.php?error=invaliduid");
        exit();
    }
    elseif (strlen($username) < 4 || strlen($username) > 19) {
        header("location: adminHome.php?error=srtunam");
        exit();
    }
    elseif (adminUserExist($conn, $username) !== false) {
        header("location: adminHome.php?error=usertaken");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE useradmin SET userUid = ? WHERE id = '$id';");
        $sql->bind_param("s", $username);
        $sql->execute();
        header("location: adminHome.php?portershow=$id");
        exit();
    }
}
elseif(isset($_POST['porterSubmit-editaccEmail'])){
    
    $id = $_POST['id'];
    $email = $_POST['email'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if (adminEmailExist($conn, $email) !== false) {
        header("location: adminHome.php?error=emailexist");
        exit();
    }
    elseif (invalidEmail($email) !== false) {
        header("location: adminHome.php?error=invalidemail");
        exit();
    }
    elseif (empty($email)){
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE useradmin SET userEmail = '$email' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?portershow=$id");
        exit();
    }
}
elseif(isset($_POST['porterSubmit-editaccPhone'])){
    
    $id = $_POST['id'];
    $phone = $_POST['phone'];
    
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
    
    if (adminPhoneExist($conn, $phone) !== false) {
        header("location: adminHome.php?error=phoneexist");
        exit();
    }
    elseif (invalidPhone($phone) !== false) {
        header("location: adminHome.php?error=invalidphone");
        exit();
    }
    elseif (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: adminHome.php?error=numln");
        exit();
    }
    elseif (empty($phone)){
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE useradmin SET userPhone = '$phone' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?portershow=$id");
        exit();
    }
}
elseif(isset($_POST['porterSubmit-editacc'])){
  
    $id = $_POST['id'];
    $name = $_POST['name'];
    $type = $_POST['type'];
  
    require 'includes/dbh.inc.php';
    require_once 'includes/functions.inc.php';
  
    if (empty($type) || empty($name)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    elseif (invalidName($name) !== false) {
        header("location: adminHome.php?error=invalidname");
        exit();
    }
    else{
        
        $sql = $conn->prepare("UPDATE useradmin SET userName = '$name', userType = '$type' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?portershow=$id");
        exit();
    }
}
elseif(isset($_POST['porterSubmit-editaccPwd'])){
    
    $id = $_POST['id'];
    $pwd= $_POST['pwd'];
    
    require 'includes/dbh.inc.php';
    
    if (empty($pwd)) {
        header("location: adminHome.php?error=emptyinput");
        exit();
    }
    else{
        
        $newPwdHash = password_hash($pwd, PASSWORD_DEFAULT);
        
        $sql = $conn->prepare("UPDATE useradmin SET userPwd = '$newPwdHash' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?portershow=$id");
        exit();
    }
}
//edit porter end
//PorterAccount End
//Product item start
//add product start
elseif(isset($_POST['submit-product'])){
    $pname = $_POST['name'];
    $pcode = $_POST['pcode'];
    $desc = $_POST['desc'];
    $brand = $_POST['brand'];
    $type = $_POST['type'];
    $stock = $_POST['stock'];
    $pprice = $_POST['pprice'];
    $origprice = $_POST['origprice'];
    $featured = $_POST['featured'];

    include 'includes/dbhStore.inc.php';
    include_once 'includes/functionStore.inc.php';
    
    if(empty($pname) || empty($pcode) || empty($desc) || empty($brand) || empty($type) || empty($stock) || empty($pprice) || empty($origprice) || empty($featured)){
        header("location: adminHome.php?error=empty");
        exit();
    }
    elseif (pnameExist($conn, $name) !== false) {
        header("locaiton: adminHome.php?error=pnameexist");
        exit();
    }
    elseif(pcodeExist($conn, $pcode)){
        header("location: adminHome.php?error=pcodeexist");
        exit();
    }
    else{
        createProduct($conn, $pname, $pcode, $desc, $brand, $type, $stock, $pprice, $origprice, $featured);
    }
}
//add product end
//edit product start
elseif(isset($_POST['submitImage'])){
    include "includes/dbhStore.inc.php";
    
    $id = $_POST['id'];
    $file = $_FILES['file'];

    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png');

    if (in_array($fileActualExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 4000000) {
                $sql = $conn->prepare("SELECT * FROM prodcuct WHERE id = '$id';");
                $sql->execute();
                $result = $sql->get_result();
                while($row = $result->fetch_assoc()){
                    $pcode = $row['productCode'];
                    $image = $row['productImage'];
                    $file_to_delete = "userimg/$image";
                    unlink($file_to_delete);
                    $fileNameNew = $pcode + $fileActualExt;
                    $fileDestination = 'products/'.$fileNameNew;
                    move_uploaded_file($fileTmpName, $fileDestination);
                    $insert = $conn->query("UPDATE prodcuct SET productImage = '$fileDestination' WHERE id = '$id';");
                    if ($insert) {
                        header("location: adminHome.php?prodshow=$id");
                        exit();
                    }else {
                        echo $conn->error;
                    }
                }
            }else {
                header("location: adminHome.php?error=imgsize");
                exit();
            }
        }else {
            header("location: adminHome.php?error=upload");
            exit();
        }
    }else {
        header("location: adminHome.php?error=imgtype");
        exit();
    }
}
elseif(isset($_POST['productSubmit-editName'])){
    $id = $_POST['id'];
    $pname = $_POST['pname'];
    
    include 'includes/dbhStore.inc.php';
    include_once 'includes/functionStore.inc.php';
    
    if(empty($pname)){
        header("location: adminHome.php?error=empty");
        exit();
    }
    elseif(pnameExist($conn, $name) !== false){
        header("location: adminHome.php?error=nameexist");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE prodcuct SET productName = ? WHERE id ='$id';");
        $sql->bind_param("s", $pname);
        $sql->execute();
        header("location: adminHome.php?prodshow=$id");
        exit();
    }
}
elseif(isset($_POST['productSubmit-editCode'])){
    $id = $_POST['id'];
    $pcode = $_POST['pcode'];
    
    include 'includes/dbhStore.inc.php';
    include_once 'includes/functionStore.inc.php';
    
    if(empty($pcode)){
        header("location: adminHome.php?error=empty");
        exit();
    }
    elseif(pcodeExist($conn, $pcode) !== false){
        header("location: adminHome.php?error=codeexist");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE prodcuct SET productCode = ? WHERE id ='$id';");
        $sql->bind_param("s", $pcode);
        $sql->execute();
        header("location: adminHome.php?prodshow=$id");
        exit();
    }
}
elseif(isset($_POST['productSubmit-editProd'])){
    $id = $_POST['id'];
    $pdesc = $_POST['pdesc'];
    $brand = $_POST['brand'];
    $type = $_POST['type'];
    $stock = $_POST['stock'];
    $pprice = $_POST['pprice'];
    $oprice = $_POST['oprice'];
    $feature = $_POST['feature'];
    
    error_reporting(-1);
    ini_set('display_errors', true);
    include 'includes/dbhStore.inc.php';
    
    if(empty($pdesc) || empty($brand) || empty($type) || empty($stock) || empty($pprice) || empty($oprice) || empty($feature)){
        header("location: adminHome.php?error=empty");
        ecit();
    }
    else{
        if($feature == 'True'){
            $bool = 1;
        }else{
            $bool = 0;
        }
        $sql = $conn->prepare("UPDATE prodcuct SET productPrice = '$pprice', productDesc = '$pdesc', brand = '$brand', typeProd = '$type', productStock = '$stock', origPrice = '$oprice', feature = '$bool' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?prodshow=$id");
        exit();
    }
}
//edit product end
//Product item end
//Order Start
//assign order start
elseif(isset($_POST['submit-assignOrder'])){
    $id = $_POST['id'];
    $porter = $_POST['porter'];
    
    include 'includes/dbhStore.inc.php';
    
    if(empty($porter)){
        header("location: adminHome.php");
        exit();
    }
    else{
        $sql = $conn->prepare("UPDATE orders SET porter = '$porter' WHERE id = '$id';");
        $sql->execute();
        header("location: adminHome.php?store=order");
        exit();
    }
}
//assign order end
//Order End
else{
    header("location: adminHome.php");
    exit();
}
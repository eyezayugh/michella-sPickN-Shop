<!-- Programmed by: Isaiah John Ching Fernando-->
<?php
include 'header.php';
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];
$loyalpts = $_SESSION['loyalPts'];

include 'includes/dbh.inc.php';
if (isset($_GET['purchase'])) {
  if ($loyalpts < 100) {
    header("location: userProfile.php?error=pts");
    exit();
  }else {
    if ($_GET['purchase'] == 'loyalone') {
      $sql = "SELECT * FROM loyalcard WHERE userUid = '$userUid';";
      if ($res = mysqli_query($conn, $sql)) {
        $rowcount = mysqli_num_rows($res);
        if ($rowcount > 0) {
          header("location: userProfile.php?error=cardExist");
          exit();
        }else {
          $pts = 100;
          $discount = 0.1;
          $query = $conn->prepare("INSERT INTO loyalcard (userUid, loyalCardPts, loyalDis) VALUES ('$userUid', '$pts', '$discount');");
          $query->execute();
          $total = $loyalpts - $pts;
          $_SESSION['loyalPts'] -= $pts;
          $stmt = $conn->prepare("UPDATE users SET loyalpts = $total WHERE userUid = '$userUid';");
          $stmt->execute();
          mysqli_free_result($res);
          header("location: userProfile.php?success=card");
          exit();
        }
      }else {
        header("location: userProfile.php?error2");
        exit();
      }
    }
    elseif ($_GET['purchase'] == 'loyaltwo') {
      if ($loyalpts < 200) {
        header("location: userProfile.php?error=pts");
        exit();
      }
      $sql = "SELECT * FROM loyalcard WHERE userUid = '$userUid';";
      if ($res = mysqli_query($conn, $sql)) {
        $rowcount = mysqli_num_rows($res);
        if ($rowcount > 0) {
          header("location: userProfile.php?error=cardExist");
          exit();
        }else {
          $pts = 200;
          $discount = 0.2;
          $query = $conn->prepare("INSERT INTO loyalcard (userUid, loyalCardPts, loyalDis) VALUES ('$userUid', '$pts', '$discount');");
          $query->execute();
          $total = $loyalpts - $pts;
          $_SESSION['loyalPts'] -= $pts;
          $stmt = $conn->prepare("UPDATE users SET loyalpts = $total WHERE userUid = '$userUid';");
          $stmt->execute();
          mysqli_free_result($res);
          header("location: userProfile.php?success=card");
          exit();
        }
      }else {
        header("location: userProfile.php?error2");
        exit();
      }
    }
    elseif ($_GET['purchase'] == 'loyalthree') {
      if ($loyalpts < 400) {
        header("location: userProfile.php?error=pts");
        exit();
      }
      $sql = "SELECT * FROM loyalcard WHERE userUid = '$userUid';";
      if ($res = mysqli_query($conn, $sql)) {
        $rowcount = mysqli_num_rows($res);
        if ($rowcount > 0) {
          header("location: userProfile.php?error=cardExist");
          exit();
        }else {
          $pts = 400;
          $discount = 0.3;
          $query = $conn->prepare("INSERT INTO loyalcard (userUid, loyalCardPts, loyalDis) VALUES ('$userUid', '$pts', '$discount');");
          $query->execute();
          $total = $loyalpts - $pts;
          $_SESSION['loyalPts'] -= $pts;
          $stmt = $conn->prepare("UPDATE users SET loyalpts = $total WHERE userUid = '$userUid';");
          $stmt->execute();
          mysqli_free_result($res);
          header("location: userProfile.php?success=card");
          exit();
        }
      }else {
        header("location: userProfile.php?error2");
        exit();
      }
    }
    elseif ($_GET['purchase'] == 'loyalfour') {
      if ($loyalpts < 1000) {
        header("location: userProfile.php?error=pts");
        exit();
      }
      $sql = "SELECT * FROM loyalcard WHERE userUid = '$userUid';";
      if ($res = mysqli_query($conn, $sql)) {
        $rowcount = mysqli_num_rows($res);
        if ($rowcount > 0) {
          header("location: userProfile.php?error=cardExist");
          exit();
        }else {
          $pts = 1000;
          $discount = 0.4;
          $query = $conn->prepare("INSERT INTO loyalcard (userUid, loyalCardPts, loyalDis) VALUES ('$userUid', '$pts', '$discount');");
          $query->execute();
          $total = $loyalpts - $pts;
          $_SESSION['loyalPts'] -= $pts;
          $stmt = $conn->prepare("UPDATE users SET loyalpts = $total WHERE userUid = '$userUid';");
          $stmt->execute();
          mysqli_free_result($res);
          header("location: userProfile.php?success=card");
          exit();
        }
      }else {
        header("location: userProfile.php?error2");
        exit();
      }
    }
    elseif ($_GET['purchase'] == 'loyalfive') {
      if ($loyalpts < 2000) {
        header("location: userProfile.php?error=pts");
        exit();
      }
      $sql = "SELECT * FROM loyalcard WHERE userUid = '$userUid';";
      if ($res = mysqli_query($conn, $sql)) {
        $rowcount = mysqli_num_rows($res);
        if ($rowcount > 0) {
          header("location: userProfile.php?error=cardExist");
          exit();
        }else {
          $pts = 2000;
          $discount = 0.5;
          $query = $conn->prepare("INSERT INTO loyalcard (userUid, loyalCardPts, loyalDis) VALUES ('$userUid', '$pts', '$discount');");
          $query->execute();
          $total = $loyalpts - $pts;
          $_SESSION['loyalPts'] -= $pts;
          $stmt = $conn->prepare("UPDATE users SET loyalpts = $total WHERE userUid = '$userUid';");
          $stmt->execute();
          mysqli_free_result($res);
          header("location: userProfile.php?success=card");
          exit();
        }
      }else {
        header("location: userProfile.php?error2");
        exit();
      }
    }
    else {
      header("location: userProfile.php?error");
      exit();
    }
  }
  mysqli_close($conn);
}

if (isset($_GET['delete'])) {
  include 'includes/dbhStore.inc.php';
  $id = $_GET['delete'];

  $st = $conn->prepare("SELECT * FROM orders WHERE id = '$id';");
  $st->execute();
  $re = $st->get_result();
  while ($rw = $re->fetch_assoc()) {
    $pmode = $rw['pmode'];
    $products = $rw['products'];
    $grandTotal = $rw['amountPaid'];
    $orderCode = $rw['orderCode'];
    $userAddress = $rw['userAdd'];
    $pCode = $rw['prodCode'];
    $status = "Canceled by Customer";

    $stat = $conn->prepare("SELECT prodCode FROM orders WHERE id = '$id';");
    $stat->execute();
    $rs = $stat->get_result();
    while ($ro = $rs->fetch_assoc()) {
      $prod = $ro['prodCode'];
      $prodAr = explode(',', $prod);
      $length = count($prodAr);
      $i = 0;
      while ($length > $i) {
          $prodAr[$i];
          $prodName = explode('-', $prodAr[$i]);
          $trimName = trim($prodName[0]);
          $trimNum = trim($prodName[1]);
          $statem = $conn->prepare("SELECT * FROM prodcuct WHERE productCode = '$trimName';");
          $statem->execute();
          $rt = $statem->get_result();
          while ($rws = $rt->fetch_assoc()) {
              $stock = $rws['productStock'];
              $stockTots = $stock + $trimNum;
              $sqli = $conn->prepare("UPDATE prodcuct SET productStock = '$stockTots' WHERE productCode = '$trimName';");
              $sqli->execute();
          }
          $i++;
        }
      }

    $query = $conn->prepare("INSERT INTO archorder (userName, userUid , userEmail, userPhone, userAdd, pmode, products, amountPaid, orderCode, prodCode, orderStatus) VALUES ( '$userName', '$userUid', '$userEmail', '$userPhone', '$userAddress', '$pmode', '$products', '$grandTotal', '$orderCode', '$pCode', '$status');");
    $query->execute();
  }

  $statement = $conn->prepare("DELETE FROM orders WHERE id = '$id';");
  $statement->execute();
  
  $loyal = $grandTotal/25;
  
  include 'includes/dbh.inc.php';
  $e = $conn->prepare("DELETE FROM qrcode WHERE orderCode = '$orderCode';");
  $e->execute();

  $select = $conn->prepare("SELECT loyalpts FROM users WHERE userUid = '$userUid';");
  $select->execute();
  $result = $select->get_result();
  while($row_select = $result->fetch_assoc()){
    $pts = $row_select['loyalpts'];
    $loyalpts = $pts - $loyal;
    $_SESSION['loyalPts'] = $pts - $loyal;
    $update = $conn->prepare("UPDATE users SET loyalpts = '$loyalpts' WHERE userUid = '$userUid';");
    $update->execute();
  }

  mysqli_close($conn);
  header("location: userProfile.php?success=cancel");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleEditProfile.css">
    <link
      rel="stylesheet"
      href="css/styleProfile.css?v=<?php echo time(); ?>"
    />
    <link
      rel="stylesheet"
      href="css/magnify.css?v=<?php echo time(); ?>"
    />
    <title>Document</title>
  </head>
  <body>
    <div class="space"></div>
    <?php
    if($loyalpts < 0){
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>WARNING: If you are found abusing the functions of the system your account will be deleted.</strong>
      </div>';
    }
    if (isset($_GET['success'])) {
      if ($_GET['success'] == 'card') {
    ?>
    <div class="alert alert-success" id="close">
      <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
      <strong>You now have a Loyalty Card, you have a discount with your next order</strong>
    </div>
    <?php
      }
      if ($_GET['success'] == 'cancel') {
    ?>
    <div class="alert alert-success" id="close">
      <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
      <strong>You have successfully canceled your order, you can view it at your Order History bellow</strong>
    </div>
    <?php
      }
    }
    if (isset($_GET['error'])) {
      if ($_GET['error'] == 'pts') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>You don\'t have enough Loyalty Points, get more by ordering from our store</strong>
      </div>';
      }
      if ($_GET['error'] == 'cardExist') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>You already have a Loyalty Card purchased please spend it to purchase another one</strong>
      </div>';
      }
      if ($_GET['error'] == 'refund') {
        echo '<div class="alert alert-danger" id="close">
        <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
        <strong>This order is either not qualified for a refund or you already sent a refund request, for more information <i class="fas fa-angle-right"></i> <a href="files/Terms&Conditions.pdf" target="_blank" class="btn-info">Terms & Conditions</a></strong>
      </div>';
      }
    }
    ?>
    
    <div class="container-user">
      <div class="box-display">
        <div class="profile-pic">
          <?php
          include 'includes/dbh.inc.php';
          $img = $conn->prepare("SELECT profilePic FROM users WHERE userUid = '$userUid';");
          $img->execute();
          $resu = $img->get_result();
          while ($row = $resu->fetch_assoc()) {
            $profilepic = $row['profilePic'];
            if (empty($profilepic)) {
              echo '<img src="img/profile.jpg">';
            }else {
            ?>
            <img src="userimg/<?=$profilepic?>" alt="">
          <?php
            }
          }
          ?>
        </div>
        <h5 class="username"><?= $useruid; ?></h5>
        <h5>
          <i class="fas fa-phone-alt"></i>
          <?= $userPhone; ?>
        </h5>
        <h5>
          <i class="fas fa-envelope"></i>
          <?= $userEmail; ?>
        </h5>
        <?php
          include 'includes/dbh.inc.php';
          $stmt = $conn->prepare("SELECT * FROM users WHERE userUid = '$useruid';"); 
          $stmt->execute(); 
          $result = $stmt->get_result(); 
          while($row = $result->fetch_assoc()){ 
            if (empty($row['userAdd'])) { ?>
        <h5><i class="fas fa-home"></i> N/A</h5>
        <?php
        }else{
        ?>
        <h5>
          <i class="fas fa-home"></i>
          <?= $row['userAdd'];?>
        </h5>
        <?php }?>
        <h5 class="loyalty-pts">
          <i class="fas fa-crown"></i> Loyalty Points:
          <?= $row['loyalpts'];?>
        </h5>
        <?php }?>
        <h5>
            <i class="fas fa-paper-plane"></i>
            <a href="userMsg.php">Send Us A Message</a>
        </h5>
        <div class="button-group">
          <a href="includes/logout.inc.php" class="btn-info">Logout</a>
          <a href="userEditProfile.php" class="btn-info">Edit Account</a>
        </div>
      </div>
      <div class="box-info">
        <div class="top">
          <?php
          include 'includes/dbh.inc.php';
          $img = $conn->prepare("SELECT bgPic FROM users WHERE userUid = '$userUid';");
          $img->execute();
          $resu = $img->get_result();
          while ($row = $resu->fetch_assoc()) {
            $bgpic = $row['bgPic'];
            if (empty($bgpic)) {
              echo '<img src="img/bg.jpg">';
            }else {
            ?>
            <img src="userimg/<?=$bgpic?>" alt="">
          <?php
            }
          }
          ?>
          <div class="name">
            <h4><?= $userName; ?></h4>
          </div>
        </div>
        <section class="tabs">
          <div class="container-tabs">
            <div id="tab-1" class="tab-item tab-border">
              <i class="fas fa-newspaper"></i>
              <p class="hide-sm">News</p>
            </div>
            <div id="tab-2" class="tab-item">
              <i class="fas fa-shopping-bag"></i>
              <p class="hide-sm">Orders</p>
            </div>
            <div id="tab-3" class="tab-item">
              <i class="fas fa-crown"></i>
              <p class="hide-sm">Loyalty Points</p>
            </div>
          </div>
        </section>
        <section class="tab-content">
          <div class="container-content">
            <!-- Tab Content 1 -->
            <div id="tab-1-content" class="tab-content-item show">
              <div class="tab-1-content-inner">
                <div class="container-text">
                  <h5>Featured Products</h5>
                </div>
                <div class="container-products">
                  <?php
                    include 'includes/dbhStore.inc.php';
                    $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE feature = 1;"); 
                    $stmt->execute(); 
                    $result = $stmt->get_result(); 
                    while ($row = $result->fetch_assoc()){ ?>
                  <div class="card">
                    <div class="card-img">
                      <?php if ($verify == 0) {
                            ?>
                      <a href="userProfile.php?error=notvalid"
                        ><img src="<?= $row['productImage'] ?>" alt=""
                      /></a>
                      <?php 
                          }else {
                          ?>
                      <a href="userStoreInfo.php?product=<?= $row['id'] ?>"
                        ><img src="<?= $row['productImage'] ?>" alt=""
                      /></a>
                      <?php
                          }
                          ?>
                    </div>
                    <div class="card-body">
                      <h5><?= $row['productName']; ?></h5>
                      <h5 class="price">
                        PHP
                        <?= number_format($row['productPrice'],2); ?>
                      </h5>
                    </div>
                  </div>
                  <?php }?>
                </div>
                <div class="container-text">
                  <h5>Announcements</h5>
                  <?php
                  include 'includes/dbh.inc.php';
                  $sql = $conn->prepare("SELECT * FROM `news` ORDER BY `news`.`id` DESC;");
                  $sql->execute();
                  $result = $sql->get_result();
                  while($row = $result->fetch_assoc()){
                  ?>
                  <div class="box-news">
                    <img src="<?= $row['newsImg']; ?>" id="image" class="zoom" data-magnify-src="<?= $row['newsImg']; ?>">
                    <h5><?= $row['newsDate']; ?></h5>
                    <h4><?= $row['subj']; ?></h4>
                    <p><?= $row['body']; ?></p>
                  </div>
                  <?php
                  }
                  ?>
                </div>
              </div>
            </div>
            <!-- Tab 2 Content -->
            <div id="tab-2-content" class="tab-content-item">
              <div class="tab-2-content-bottom">
                <div class="container-text">
                  <h5>Pending Orders</h5>
                </div>
                <?php
                  include 'includes/dbhStore.inc.php';
                  $stmt = $conn->prepare("SELECT * FROM orders WHERE userUid = '$userUid' AND orderStatus != 'Canceled by the Store';"); 
                  $stmt->execute(); 
                  $result = $stmt->get_result();
                  while ($row = $result->fetch_assoc()){ ?>
                <div class="tab-2-pending">
                  <div class="tab-2-left">
                    <?php
                    $orderStatus = $row['orderStatus'];
                    if ($orderStatus == "In Transit") {
                      echo '<h5 class="transit">Order Status: In Transit</h5>';
                    }
                    elseif ($orderStatus == "Pending") {
                      echo '<h5 class="pending">Order Status: Pending</h5>';
                    }
                    ?>
                    <a href="userPrintPay.php?print=<?= $row['orderCode']; ?>" target="_blank" class="btn-tab-2" style="background-color: #777; color: #eee;">Print Receipt</a>
                    <h5>
                      Order Code:
                      <?= $row['orderCode']; ?>
                    </h5>
                    <h5>
                      Delivery Address:
                      <?= $row['userAdd']; ?>
                    </h5>
                    <h5>
                      Products:
                      <?= $row['products']; ?>
                    </h5>
                    <?php
                        if($row['pmode'] == 'cod'){
                        ?>
                    <h5>Payment Type: Cash On Delivery</h5>
                    <?php 
                        }
                        if($row['pmode'] == 'pop'){
                        ?>
                    <h5>Payment Type: Payment On Pickup</h5>
                    <?php 
                        }
                        if($row['pmode'] == 'credit'){
                        ?>
                    <h5>Payment Type: Credit Card</h5>
                    <?php }?>
                    <h5>
                      Total: PHP 
                      <?= number_format($row['amountPaid'],2); ?>
                    </h5>
                    <h5>
                      Date Ordered:
                      <?= $row['orderDate']; ?>
                    </h5>
                    <?php
                    if($orderStatus == "In Transit" || $orderStatus == "Scan"){
                        ?>
                        <a href="userProfile.php" 
                    onclick="return confirm('AT THIS STAGE YOU ARE NOT ALLOWED TO CANCEL ORDER');" class="btn-tab-2" style="background-color: #777;">Cancel Order</a>
                    <?php
                    }else{
                        ?>
                        <a href="userProfile.php?delete=<?= $row['id']; ?>" 
                    onclick="return confirm('Are you sure you want to cancel your order?');" class="btn-tab-2" style="background-color: darkred;">Cancel Order</a>
                    <?php
                    }
                    ?>
                  </div>
                  <div class="tab-2-right">
                    <h5>
                      Download, screenshot or just show us the qr code form your
                      account
                    </h5>
                    <img src="qr/<?= $row['orderCode'] ?>.png" alt="" />
                    <a
                      href="qrDownload.php?file=<?= $row['orderCode']; ?>.png"
                      class="btn-tab-2"
                      >Download QR Code</a
                    >
                  </div>
                </div>
                <?php 
                }?>
                <div class="tab-2-history">
                  <div class="container-text">
                    <h5>Order History</h5>
                  </div>
                <?php
                include 'includes/dbhStore.inc.php';
                $stmt = $conn->prepare("SELECT * FROM archorder WHERE userUid = '$userUid' ORDER BY `archorder`.`id` DESC;"); 
                $stmt->execute(); 
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()){ ?>
                  <div class="tab-2-history-content">
                    <?php
                    $status = $row['orderStatus'];
                    $refund = $row['refund'];
                    if ($status == "Canceled by Customer") {
                      echo '<h5 class="cancel">Status: Canceled by Customer</h5>';
                    }
                    elseif($status == "Delivered"){
                      $date  = $row['cancelDate'];
                      $refundDate = date('Y-m-d', strtotime($date. ' + 5 days'));
                      if($refundDate > date("Y-m-d")){
                        echo '<h5 class="cancel" style="background-color: green;">Status: Delivered</h5>
                        <h5>Date Delivered:'.$date.'</h5>
                        <h5>Refund Date: '.$refundDate.'</h5>';
                      }else{
                        echo '<h5 class="cancel" style="background-color: green;">Status: Delivered</h5>
                        <h5>Date Delivered:'.$date.'</h5>
                        <h5 style="color: darkred;">Refund Date: Expired</h5>';
                      }
                    }
                    elseif($status == "Refund Request"){
                      echo '<h5 class="cancel" style="background-color: #fcc107;">Status: Refund Request</h5>';
                    }
                    elseif($status == "Refund Request Accepted"){
                      echo '<h5 class="cancel" style="background-color: green;">Status: Refund Request Accepted</h5>';
                    }
                    ?>
                    <h5>Order Code: <?= $row['orderCode']; ?></h5>
                    <h5>Products: <?= $row['products']; ?></h5>
                    <h5>Delivery Address: <?= $row['userAdd']; ?></h5>
                    <h5>Price: PHP <?= number_format($row['amountPaid'],2); ?></h5>
                    <a href="userReview.php?order=<?= $row['orderCode']; ?>" class="btn-tab-2" style="background: #ffc300; color: #000; font-weight: bold;">Send a Review</a>
                    <div class="button">
                      <?php
                      if ($refund == 1 || $status == 'Canceled by Customer' || $status == 'Refund Request' || $refundDate <= date("Y-m-d") || $status == "Canceled by the Store") {
                        echo '<a href="userProfile.php?error=refund" class="btn-tab-2" style="background:#777;"> Apply For Refund</a>';
                      }
                      elseif($status == 'Refund Request Accepted'){
                          echo '';
                      }
                      else {
                      ?>
                      <form action="userRefund.php" method="POST">
                          <input type="hidden" name="id" value="<?= $row['id']; ?>">
                          <button name="submit" class="btn-tab-2" style="border: none;">Apply For Refund</button>
                      </form>
                      <?php
                      }
                      ?>
                    </div>
                      <?php
                      $code = $row['orderCode'];
                      include 'includes/dbhStore.inc.php';
                      $sql = $conn->prepare("SELECT * FROM userReview WHERE orderCode = '$code';");
                      $sql->execute();
                      $res = $sql->get_result();
                      while($rw = $res->fetch_assoc()){
                        $reply = $rw['reply'];
                      ?>
                      <div style="background: #eee; margin: 1rem 0.5rem; padding: 0.5rem;">
                        <i class="fas fa-user-circle"> Customer Review</i>
                        <h5><?= $rw['review']; ?></h5>
                        <?php
                        if(!empty($reply)){
                          echo '
                          <i class="far fa-gem" style="font-weight: bold;"> Store Reply</i>
                          <h5>'.$reply.'</h5>';
                        }else{
                          echo '';
                        }
                        ?>
                      </div>
                      <?php
                      }
                      ?>
                  </div>
                <?php 
                }?>
                <?php
                include 'includes/dbhStore.inc.php';
                $stmt = $conn->prepare("SELECT * FROM orders WHERE userUid = '$userUid' AND orderStatus = 'Canceled by the Store';"); 
                $stmt->execute(); 
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()){ ?>
                  <div class="tab-2-history-content">
                    <?php
                    $status = $row['orderStatus'];
                    $refund = $row['refund'];
                    if ($status == "Canceled by the Store") {
                      echo "<h5 class='cancel'>Status: Canceled by Michella's Pick N' Shop</h5>";
                    }
                    ?>
                    <h5>Order Code: <?= $row['orderCode']; ?></h5>
                    <h5>Products: <?= $row['products']; ?></h5>
                    <h5>Delivery Address: <?= $row['userAdd']; ?></h5>
                    <h5>Price: PHP <?= number_format($row['amountPaid'],2); ?></h5>
                    <div class="button">
                      <?php
                      if ($refund == 1 || $status == 'Canceled by Customer' || $status == 'Refund Request' || $status == "Canceled by the Store") {
                        echo '<a href="userProfile.php?error=refund" class="btn-tab-2" style="background:#777;"> Apply For Refund</a>';
                      }
                      elseif($status == 'Refund Request Accepted'){
                          echo '';
                      }
                      else {
                      ?>
                      <form action="userRefund.php" method="POST">
                          <input type="hidden" name="id" value="<?= $row['id']; ?>">
                          <button name="submit" class="btn-tab-2" style="border: none;">Apply For Refund</button>
                      </form>
                      <?php
                      }
                      ?>
                    </div>
                  </div>
                <?php 
                }?>
                </div>
              </div>
            </div>
            <!-- Tab 3 Content -->
            <div id="tab-3-content" class="tab-content-item">
              <?php
                include 'includes/dbh.inc.php';
                $stmt = $conn->prepare("SELECT * FROM users WHERE userUid ='$useruid';"); 
                $stmt->execute(); 
                $result = $stmt->get_result();
                while ($row = $result->fetch_assoc()){ ?>
              <div class="container-text">
                <h4>
                  Current Points:
                  <i class="fas fa-crown" style="color: gold"></i
                  ><?= $row['loyalpts'];?>
                </h4>
              </div>
              <!-- Loyal Card 1 -->
              <div class="container-loyal-card">
                <div class="loyal-card btn-text-group">
                  <div class="card-text">
                    <h3>100 pts</h3>
                  </div>
                  <a href="userProfile.php?purchase=loyalone" class="btn-loyal"
                    ><i class="fas fa-crown"> Purchase</i></a>
                </div>
                <div class="loyal-card">
                  <img src="img/loyal1.PNG" alt="" />
                </div>
              </div>
              <!-- Loyal Card 2 -->
              <div class="container-loyal-card">
                <div class="loyal-card btn-text-group">
                  <div class="card-text">
                    <h3>200 pts</h3>
                  </div>
                  <a href="userProfile.php?purchase=loyaltwo" class="btn-loyal"
                    ><i class="fas fa-crown"> Purchase</i></a>
                </div>
                <div class="loyal-card">
                  <img src="img/loyal2.PNG" alt="" />
                </div>
              </div>
              <!-- Loyal Card 3 -->
              <div class="container-loyal-card">
                <div class="loyal-card btn-text-group">
                  <div class="card-text">
                    <h3>400 pts</h3>
                  </div>
                  <a href="userProfile.php?purchase=loyalthree" class="btn-loyal"
                    ><i class="fas fa-crown"> Purchase</i></a>
                </div>
                <div class="loyal-card">
                  <img src="img/loyal3.PNG" alt="" />
                </div>
              </div>
              <!-- Loyal Card 4 -->
              <div class="container-loyal-card">
                <div class="loyal-card btn-text-group">
                  <div class="card-text">
                    <h3>1000 pts</h3>
                  </div>
                  <a href="userProfile.php?purchase=loyalfour" class="btn-loyal"
                    ><i class="fas fa-crown"> Purchase</i></a>
                </div>
                <div class="loyal-card">
                  <img src="img/loyal4.JPG" alt="" />
                </div>
              </div>
              <!-- Loyal Card 5 -->
              <div class="container-loyal-card">
                <div class="loyal-card btn-text-group">
                  <div class="card-text">
                    <h3>2000 pts</h3>
                  </div>
                  <a href="userProfile.php?purchase=loyalfive" class="btn-loyal"
                    ><i class="fas fa-crown"> Purchase</i></a>
                </div>
                <div class="loyal-card">
                  <img src="img/loyal5.PNG" alt="" />
                </div>
              </div>
              <?php
                }?>
            </div>
          </div>
        </section>
      </div>
    </div>

    <?php
    include 'footer.php';
    ?>
    <script src="js/jquery.magnify.js" charset="UTF-8"></script>
    <script>
    $(document).ready(function() {
      $('.zoom').magnify();
    });
    </script>
    <script>
      function myFunction(){
        document.getElementById("close").style.display = "none";
      }
    </script>
    <script src="js/profile.js"></script>
  </body>
</html>
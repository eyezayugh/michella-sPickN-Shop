<!-- Programmed By: Isaiah John Ching Fernando -->
<?php
function adminPhoneExist($conn, $phone){
    $result;
    $sql = mysqli_query($conn, "SELECT userPhone FROM useradmin WHERE userPhone = '$phone';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function adminUserExist($conn, $username){
    $result;
    $sql = mysqli_query($conn, "SELECT userUid FROM useradmin WHERE userUid = '$username';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function adminEmailExist($conn, $email){
    $result;
    $sql = mysqli_query($conn, "SELECT userEmail FROM useradmin WHERE userEmail = '$email';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function phoneExist($conn, $phone){
    $result;
    $sql = mysqli_query($conn, "SELECT userPhone FROM users WHERE userPhone = '$phone';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function userExist($conn, $username){
    $result;
    $sql = mysqli_query($conn, "SELECT userUid FROM users WHERE userUid = '$username';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function emailExist($conn, $email){
    $result;
    $sql = mysqli_query($conn, "SELECT userEmail FROM users WHERE userEmail = '$email';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function emptyInputSignup($name, $username, $email, $phone, $pwd, $pwdRepeat){
    $result;
    if (empty($name) || empty($username) || empty($email) || empty($phone) || empty($pwd) || empty($pwdRepeat)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function invalidName($name){
    $result;
    if (!preg_match("/^[a-zA-Z\s]*$/", $name)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function invalidUid($username){
    $result;
    if (!preg_match("/^[a-zA-Z0-9_-]*$/", $username)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function invalidEmail($email){
    $result;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function invalidPhone($phone){
    $result;
    if (!preg_match("/^[0-9]*$/", $phone)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function pwdMatch($pwd, $pwdRepeat){
    $result;
    if ($pwd !== $pwdRepeat) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function uidExists($conn, $username, $email){
    $sql = "SELECT * FROM users WHERE userEmail = ? OR userUid = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../signin.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ss", $username, $email);
    mysqli_stmt_execute($stmt);

    $resultsData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultsData)) {
        return $row;
    }
    else{
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function uidExistsAdmin($conn, $username){
    $sql = "SELECT * FROM useradmin WHERE userUid = '$username';";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../adminUserLogin.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_execute($stmt);

    $resultsData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultsData)) {
        return $row;
    }
    else{
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}

function createUser($conn, $name, $username, $email, $phone, $pwd, $verify, $type, $vkey){
    $sql = "INSERT INTO users (userName, userEmail, userUid, userPhone, userPwd, verified, userType, vKey) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../signin.php?error=stmterror");
        exit();
    }

    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

    mysqli_stmt_bind_param($stmt, "sssssiss", $name, $email, $username, $phone, $hashedPwd, $verify, $type, $vkey);
    
    // info to send email
    $to = $email;
    $subject = "Email Verification | Michelle's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Thank you for signing up</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you, to verify your email address. Do not reply to this message.</center></i>

            <p><center>Hey '.$name.', you are almost ready to start enjoying our store.</center></p>
            <p><center>Simply click the big blue button to verify your email address.</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/userverify.php?vkey='.$vkey.'" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Verify Your Account</a>
            </center></p>
            <p style="padding: 1rem; margin: 0.2rem 1rem;">If you didn\'t use your email to sign up to our site <a href="https://michellapicknshop.com/userdelete.php?user='.$username.'">Click Here</a></p>
            
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../signin.php?error=none");
    exit();
}

function createAdminUserPorter($conn, $name, $username, $email, $phone, $pwd, $type, $vkey){
    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
    $sql = "INSERT INTO useradmin (userName, userUid, userEmail, userPhone, userType, userPwd) VALUES ('$name', '$username', '$email', '$phone', '$type', '$hashedPwd');";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../adminHome.php?error=stmterror");
        exit();
    }
    
    // info to send email
    $to = $email;
    $subject = "Email Porter Verification | Michelle's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #5acc7c;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #eee;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #5acc7c; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Thank you for signing up Porter</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you, to verify your email address. Do not reply to this message.</center></i>

            <p><center>Hey '.$name.', just a few more steps until you\'re one of our Porters.</center></p>
            <p><center>The First Step, is to simply click the big blue button to verify your email address.</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/userverifyReseller.php?vkey='.$username.'" style="border: 1px solid #056183; background-color: #5acc7c;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Verify Your Account</a>
            </center></p>
            
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../signinReseller.php?error=none");
    exit();
}

function createAdminUser($conn, $name, $username, $email, $phone, $type, $pwd){
    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
    $sql = "INSERT INTO useradmin (userName, userUid, userEmail, userPhone, userType, userPwd) VALUES ('$name', '$username', '$email', '$phone', '$type', '$hashedPwd');";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../adminHome.php?error=stmterror");
        exit();
    }
    
    if($type == "Admin"){
        // info to send email
        $to = $email;
        $subject = "Email Verification Admin | Michelle's Pick N' Shop";
    
        //html message
        $message = '
        <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script
          src="https://kit.fontawesome.com/824d2c43ce.js"
          crossorigin="anonymous"
        ></script>
        <title>Document</title>
    </head>
    <body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
        <div style="max-width: 600px; margin: auto; padding: 20px;">
            <div>
                <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
                <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/adminUserLogin.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
            </div>
    
            <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
                moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
                border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">
    
                <h1 style="font-size: 22px;"><center>We have created a your Admin account for our website</center></h1>
    
                <i style="font-size: 12px;"><center>This is an email sent to you, to notify you. Do not reply to this message.</center></i>
    
                <p><center>Hey '.$name.', you\'re account is ready for you to use.</center></p>
                <p><center>Simply click the big blue button to be redirected to our site.</center></p>
                <p><center>Use the link to access your account.</center></p>
                <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                    <a href="https://michellapicknshop.com/adminUserLogin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                    color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Login Now</a>
                </center></p>
                <p><center>Or use the link bellow</center></p>
                <p><center><a href="https://michellapicknshop.com/adminUserLogin.php">https://michellapicknshop.com/adminUserLogin.php</a></center></p>
                <p><center>Click the link or copy and paste it in the url</center></p>
                
            </div>
            </div>
    </body>
    </html>
        ';
    
        // email headers
        $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
        
        mail($to, $subject, $message, $headers);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: ../adminHome.php?users=admin");
        exit();
    }
    if($type == "Deliver"){
        // info to send email
        $to = $email;
        $subject = "Email Verification Porter | Michelle's Pick N' Shop";
    
        //html message
        $message = '
        <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script
          src="https://kit.fontawesome.com/824d2c43ce.js"
          crossorigin="anonymous"
        ></script>
        <title>Document</title>
    </head>
    <body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
        <div style="max-width: 600px; margin: auto; padding: 20px;">
            <div>
                <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
                <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/adminUserLogin.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
            </div>
    
            <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
                moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
                border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">
    
                <h1 style="font-size: 22px;"><center>We have created a your Porter account for our website</center></h1>
    
                <i style="font-size: 12px;"><center>This is an email sent to you, to notify you. Do not reply to this message.</center></i>
    
                <p><center>Hey '.$name.', you\'re account is ready for you to use.</center></p>
                <p><center>Simply click the big blue button to be redirected to our site.</center></p>
                <p><center>Use the link to access your account.</center></p>
                <p><center>More instructions will be available in your account</center></p>
                <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                    <a href="https://michellapicknshop.com/adminUserLogin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                    color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Login Now</a>
                </center></p>
                <p><center>Or use the link bellow</center></p>
                <p><center><a href="https://michellapicknshop.com/adminUserLogin.php">https://michellapicknshop.com/adminUserLogin.php</a></center></p>
                <p><center>Click the link or copy and paste it in the url</center></p>
                
            </div>
            </div>
    </body>
    </html>
        ';
    
        // email headers
        $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
        
        mail($to, $subject, $message, $headers);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: ../adminHome.php?users=porters");
        exit();
    }
    if($type == "Pending"){
        // info to send email
        $to = $email;
        $subject = "Email Verification Porter | Michelle's Pick N' Shop";
    
        //html message
        $message = '
        <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script
          src="https://kit.fontawesome.com/824d2c43ce.js"
          crossorigin="anonymous"
        ></script>
        <title>Document</title>
    </head>
    <body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
        <div style="max-width: 600px; margin: auto; padding: 20px;">
            <div>
                <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
                <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/adminUserLogin.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
            </div>
    
            <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
                moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
                border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">
    
                <h1 style="font-size: 22px;"><center>You are now qualified to be one of our Porters</center></h1>
    
                <i style="font-size: 12px;"><center>This is an email sent to you, to notify you of your wualification. Do not reply to this message.</center></i>
    
                <p><center>Hey '.$name.', you\'re account is ready for you to use.</center></p>
                <p><center>Simply click the big blue button to be redirected to our site.</center></p>
                <p><center>Use the link to access your account.</center></p>
                <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                    <a href="https://michellapicknshop.com/adminUserLogin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                    color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Login Now</a>
                </center></p>
                
            </div>
            </div>
    </body>
    </html>
        ';
    
        // email headers
        $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
        $headers .= "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
        
        mail($to, $subject, $message, $headers);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: ../adminHome.php?users=admin");
        exit();
    }
}

function AddUserfrAdmin($conn, $name, $username, $email, $phone, $address, $pwd, $verify, $type, $vkey){
    $sql = "INSERT INTO users (userName, userEmail, userUid, userPhone, userAdd, userPwd, verified, userType, vKey) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: adminHome.php?error=stmterror");
        exit();
    }

    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

    mysqli_stmt_bind_param($stmt, "ssssssiss", $name, $email, $username, $phone, $address, $hashedPwd, $verify, $type, $vkey);
    
    // info to send email
    $to = $email;
    $subject = "Email Verification | Michella's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michelle\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Thank you for signing up</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you, to verify your email address. Do not reply to this message.</center></i>

            <p><center>Hey '.$name.', you are almost ready to start enjoying our store.</center></p>
            <p><center>Simply click the big blue button to verify your email address.</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/userverify.php?vkey='.$vkey.'" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Verify Your Account</a>
            </center></p>
            <p style="padding: 1rem; margin: 0.2rem 1rem;">If you didn\'t use your email to sign up to our site <a href="https://michellapicknshop.com/userdelete.php?user='.$username.'">Click Here</a></p>
            
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: adminHome.php?users=customers");
    exit();
}

function emptyInputLogin($username, $pwd){
    $result;
    if (empty($username) || empty($pwd)) {
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function loginUser($conn, $username, $pwd){
    $uidExists = uidExists($conn, $username, $username);

    if ($uidExists === false) {
        header("location: ../signin.php?error=usernotexists");
        exit();
    }

    $pwdHashed = $uidExists["userPwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);

    if ($checkPwd === false) {
        header("location: ../signin.php?error=wronglogin");
        exit();
    }
    elseif ($checkPwd === true) {
        session_start();
        $_SESSION["userid"] = $uidExists["userId"];
        $_SESSION["useruid"] = $uidExists["userUid"];
        $_SESSION["verify"] = $uidExists["verified"];
        $_SESSION["usertype"] = $uidExists["userType"];
        $_SESSION["useremail"] = $uidExists["userEmail"];
        $_SESSION["username"] = $uidExists["userName"];
        $_SESSION["userphone"] = $uidExists["userPhone"];
        $_SESSION["useraddress"] = $uidExists["userAdd"];
        $_SESSION['loyalPts'] = $uidExists["loyalpts"];
        header("location: ../userHome.php");
        exit();
    }
}

function loginUserAdminDeliver($conn, $username, $pwd){
    $uidExists = uidExistsAdmin($conn, $username);

    if ($uidExists === false) {
        header("location: ../adminUserLogin.php?error=usernotexists");
        exit();
    }

    $pwdHashed = $uidExists["userPwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);

    if ($pwd !== $pwdHashed) {
        header("location: ../adminUserLogin.php?error=wronglogin");
        exit();
    }
    elseif ($pwd == $pwdHashed) {
        session_start();
        $_SESSION["userid"] = $uidExists["id"];
        $_SESSION["userUid"] = $uidExists["userUid"];
        $_SESSION["userEmail"] = $uidExists["userEmail"];
        $_SESSION["userPhone"] = $uidExists["userPhone"];
        $_SESSION["userType"] = $uidExists["userType"];
        
        header("location: ../deliveryHome.php");
        exit();
    }
}

function loginUserAdmin($conn, $username, $pwd){
    $uidExists = uidExistsAdmin($conn, $username);
    $pwdHashed = $uidExists["userPwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);

    if ($uidExists === false) {
        header("location: ../adminUserLogin.php?error=usernotexists");
        exit();
    }
    elseif ($uidExists["userType"] == "Deliver"){
        header("location: ../adminUserLogin.php?error=notallowed");
        exit();
    }

    elseif ($pwd !== $pwdHashed) {
        header("location: ../adminUserLogin.php?error=wronglogin");
        exit();
    }
    else {
        session_start();
        $_SESSION["userId"] = $uidExists["id"];
        $_SESSION["userUid"] = $uidExists["userUid"];
        $_SESSION["userEmail"] = $uidExists["userEmail"];
        $_SESSION["userPhone"] = $uidExists["userPhone"];
        $_SESSION["userType"] = $uidExists["userType"];
        
        header("location: ../adminHome.php");
        exit();
    }
}
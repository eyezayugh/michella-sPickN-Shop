<!-- Programmed By: Isaiah John Ching Fernando -->
<?php
error_reporting(-1);
ini_set('display_errors', true);
require 'dbh.inc.php';
require_once 'functions.inc.php';

if (isset($_POST["submit"])) {

    $name = $_POST["name"];
    $username = $_POST["uid"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $pwd = $_POST["pwd"];
    $pwdRepeat = $_POST["pwdrepeat"];
    $type = $_POST["type"];
    $vkey = md5(time().$username);
    
    if (adminEmailExist($conn, $email) !== false) {
        header("location:../signinReseller.php?error=emailexist");
        exit();
    }
    elseif (adminUserExist($conn, $username) !== false) {
        header("location:../signinReseller.php?error=usertaken");
        exit();
    }
    elseif (adminPhoneExist($conn, $phone) !== false) {
        header("location:../signinReseller.php?error=phoneexist");
        exit();
    }
    elseif (empty($name) || empty($username) || empty($email) || empty($phone) || empty($pwd) || empty($pwdRepeat)) {
        header("location: ../signinReseller.php?error=emptyinput");
        exit();
    }
    elseif (invalidName($name) !== false) {
        header("location: ../signinReseller.php?error=invalidname");
        exit();
    }
    elseif (invalidUid($username) !== false) {
        header("location: ../signinReseller.php?error=invaliduid");
        exit();
    }
    elseif (invalidEmail($email) !== false) {
        header("location: ../signinReseller.php?error=invalidemail");
        exit();
    }
    elseif (invalidPhone($phone) !== false) {
        header("location: ../signinReseller.php?error=invalidphone");
        exit();
    }
    elseif (pwdMatch($pwd, $pwdRepeat) !== false) {
        header("location: ../signinReseller.php?error=pwdnotmatch");
        exit();
    }
    elseif (uidExistsAdmin($conn, $username, $email) !== false) {
        header("location: ../signinReseller.php?error=usertaken");
        exit();
    }
    elseif (strlen($username) < 4 || strlen($username) > 19) {
        header("location: ../signinReseller.php?error=srtunam");
        exit();
    }
    elseif (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: ../signinReseller.php?error=numln");
        exit();
    }
    elseif (strlen($pwd) < 4 || strlen($pwd) > 20) {
        header("location: ../signinReseller.php?error=pwdln");
        exit();
    }
    else{
        createAdminUserPorter($conn, $name, $username, $email, $phone, $pwd, $type, $vkey);
    }
    
}
else{
    header("location: ../signin.php");
    exit();
}
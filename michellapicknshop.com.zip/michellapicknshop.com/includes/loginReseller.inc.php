<!-- Programmed By: Isaiah John Ching Fernando -->
<?php

if (isset($_POST["submit"])) {
    

    $username = $_POST["uid"];
    $pwd = $_POST["pwd"];

    require_once 'dbh.inc.php';
    require_once 'functionsresellers.inc.php';

    if (emptyInputLogin($username, $pwd) !== false) {
        header("location: ../signinReseller.php?error=emptyinput");
        exit();
    }

    loginUser($conn, $username, $pwd);
}
else{
    header("location: ../signinReseller.php");
    exit();
}
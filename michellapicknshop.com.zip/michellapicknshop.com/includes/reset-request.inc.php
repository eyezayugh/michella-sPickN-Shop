<!-- Programmed By: Isaiah John Ching Fernando -->
<?php

if (isset($_POST["reset-request-submit"])) {
    require 'dbh.inc.php';
    $userEmail = $_POST["email"];

    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        header("location: ../reset-password.php?error=invalidemail");
        exit();
    }
    if (empty($_POST['email'])) {
        header("location: ../reset-password.php?error=empty");
        exit();
    }
    $sel = mysqli_query($conn, "SELECT userEmail FROM users WHERE userEmail = '$userEmail'; ") or exit(mysqli_error($conn));
    if(!mysqli_num_rows($sel)){
        header("location: ../reset-password.php?error=notexists");
        exit();
    }
    
    $selector = bin2hex(random_bytes(8));
    $token = random_bytes(32);

    $url = "https://michellapicknshop.com/create-new-password.php?selector=". $selector . "&validator=". bin2hex($token);

    $expires = date("U") + 3600;

    require 'dbh.inc.php';

    $userEmail = $_POST["email"];

    $sql = "DELETE FROM pwdreset WHERE pwdResetEmail=?";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        echo "There was an error";
        exit();
    }else{
        mysqli_stmt_bind_param($stmt, "s", $userEmail);
        mysqli_stmt_execute($stmt);
    }

    $sql = "INSERT INTO pwdreset (pwdResetEmail, pwdResetSelector, pwdResetToken, pwdResetExpires) VALUES (?, ?, ?, ?);";

    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        echo "There was an error";
        exit();
    }else{
        $hashedToken = password_hash($token, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($stmt, "ssss", $userEmail, $selector, $hashedToken, $expires);
        mysqli_stmt_execute($stmt);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    // info to send email
    $to = $userEmail;
    $subject = "Reset Password | Michelle's Pick N' Shop";
    //html message
    $message ='
    <html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michelle\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #fff;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Password Reset Request</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you, to reset your password. Do not reply to this message.</center></i>

            <p><center>We received a password reset request.</center></p>
            <p><center>Click the button bellow to reset your password.</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="'.$url.'" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Reset Password</a>
            </center></p>
            <p style="padding: 1rem; margin: 0.2rem 1rem;">If you didn\'t make this request, you can ignore this email</a></p>
            
        </div>
        </div>
</body>
</html>
    ';
    // email headers
    $headers = "From: Michelle's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";

    mail($to, $subject, $message, $headers);

    header("Location: ../reset-password.php?reset=success");
    exit();

}else {
    header("Location: ../index.php");
    exit();
}
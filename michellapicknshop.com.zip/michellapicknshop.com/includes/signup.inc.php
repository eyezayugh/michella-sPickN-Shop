<!-- Programmed By: Isaiah John Ching Fernando -->
<?php

if (isset($_POST["submit"])) {

    $name = $_POST["name"];
    $username = $_POST["uid"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $pwd = $_POST["pwd"];
    $pwdRepeat = $_POST["pwdrepeat"];
    $verify = 0;
    $type = $_POST["type"];
    $vkey = md5(time().$username);
    $bday = $_POST['bday'];
    $age = 16;

    require 'dbh.inc.php';
    require_once 'functions.inc.php';
    
    if (emailExist($conn, $email) !== false) {
        header("location:../signin.php?error=emailexist");
        exit();
    }
    if (userExist($conn, $username) !== false) {
        header("location:../signin.php?error=usertaken");
        exit();
    }
    if (phoneExist($conn, $phone) !== false) {
        header("location:../signin.php?error=phoneexist");
        exit();
    }
    if (emptyInputSignup($name, $username, $email, $phone, $pwd, $pwdRepeat) !== false) {
        header("location: ../signin.php?error=emptyinput");
        exit();
    }
    if (invalidName($name) !== false) {
        header("location: ../signin.php?error=invalidname");
        exit();
    }
    if (invalidUid($username) !== false) {
        header("location: ../signin.php?error=invaliduid");
        exit();
    }
    if (invalidEmail($email) !== false) {
        header("location: ../signin.php?error=invalidemail");
        exit();
    }
    if (invalidPhone($phone) !== false) {
        header("location: ../signin.php?error=invalidphone");
        exit();
    }
    if (pwdMatch($pwd, $pwdRepeat) !== false) {
        header("location: ../signin.php?error=pwdnotmatch");
        exit();
    }
    if (uidExists($conn, $username, $email) !== false) {
        header("location: ../signin.php?error=usertaken");
        exit();
    }
    if (strlen($username) < 4 || strlen($username) > 19) {
        header("location: ../signin.php?error=srtunam");
        exit();
    }
    if (strlen($phone) < 1 || strlen($phone) > 11) {
        header("location: ../signin.php?error=numln");
        exit();
    }
    if (strlen($pwd) < 4 || strlen($pwd) > 20) {
        header("location: ../signin.php?error=pwdln");
        exit();
    }
    function validateAge($bday, $age){
      if(is_string($bday)) {
        $birthday = strtotime($bday);
      }
      if(time() - $birthday < $age * 31536000)  {
        return false;
      }
    
      return true;
    }
    if(!validateAge($bday, $age)){
      header("location: ../signin.php?error=bday");
      exit();
    }

    createUser($conn, $name, $username, $email, $phone, $pwd, $verify, $type, $vkey);
}
else{
    header("location: ../signin.php");
    exit();
}
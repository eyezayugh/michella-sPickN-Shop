<?php
session_start();
require 'dbhStore.inc.php';

if (isset($_POST['pid'])) {
    $pid = $_POST['pid'];
    $pname = $_POST['pname'];
    $pprice = $_POST['pprice'];
    $pimage = $_POST['pimage'];
    $pcode = $_POST['pcode'];
    $pdesc = $_POST['pdesc'];
    $puser = $_POST['puser'];
    $pqty = 1;

    $stmt = $conn->prepare("SELECT productCode FROM cart WHERE userName = ? AND productCode = ?;");
    $stmt->bind_param("ss", $puser, $pcode);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $code = isset($row['productCode']) ? count(array($row['productCode'])) : 0;

    if (!$code) {
        $query = $conn->prepare("INSERT INTO cart (productName, productPrice, productImage, productDesc, qty, totalPrice, productCode, userName) Values(?,?,?,?,?,?,?,?)");

        $query->bind_param("ssssisss", $pname, $pprice, $pimage, $pdesc, $pqty, $pprice, $pcode, $puser);
        $query->execute();

        echo '<div class="alert alert-success alert-dismissible fade show mt-3">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Item added to your cart</strong></div>';
    }else{
        echo '<div class="alert alert-danger alert-dismissible fade show mt-3">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Item already added to your cart</strong></div>';
    }
}

if (isset($_POST['itemQty'])) {
    $pid = $_POST['id'];
    $pname = $_POST['name'];
    $pprice = $_POST['price'];
    $pimage = $_POST['image'];
    $pcode = $_POST['code'];
    $pdesc = $_POST['desc'];
    $puser = $_POST['user'];
    $pqty = $_POST['itemQty'];
    $ppts = $_POST['ppts'];

    $stmt = $conn->prepare("SELECT productCode FROM cart WHERE productCode = ? AND userName = '$puser';");
    $stmt->bind_param("s", $pcode);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $code = isset($row['productCode']) ? count(array($row['productCode'])) : 0;

    if (!$code) {
        if ($pqty > 0) {
            $query = $conn->prepare("INSERT INTO cart (productName, productPrice, productImage, productDesc, qty, totalPrice, productCode, userName, loyalpts) Values(?,?,?,?,?,?,?,?,?)");

            $query->bind_param("ssssisssi", $pname, $pprice, $pimage, $pdesc, $pqty, $pprice, $pcode, $puser, $ppts);
            $query->execute();

            echo '<div class="alert alert-success alert-dismissible fade show mt-3">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>Item added to your cart</strong></div>';
        }else {
            header("location: ../userStoreInfo.php?error=qty");
            exit();
        }
    }else{
        echo '<div class="alert alert-danger alert-dismissible fade show mt-3">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <strong>Item already added to your cart</strong></div>';
    }
}

if (isset($_GET['cartItem']) && isset($_GET['cartItem']) == 'cart_item') {
    $userName = $_SESSION['useruid'];
    $stmt = $conn->prepare("SELECT * FROM cart WHERE userName = '$userName';");
    $stmt->execute();
    $stmt->store_result();
    $rows = $stmt->num_rows();

    echo $rows;
}

if (isset($_GET['remove'])) {
    $id = $_GET['remove'];
    $userUid = $_SESSION["useruid"];
    $stmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND userName = ?");
    $stmt->bind_param("is", $id, $userUid);
    $stmt->execute();

    $_SESSION['showAlert'] = 'block';
    $_SESSION['message'] = 'Item removed from the cart!';
    header('location: ../userCart.php');
}

if (isset($_GET['clear'])) {
    $stmt = $conn->prepare("DELETE FROM cart");
    $stmt->execute();
    $_SESSION['showAlert'] = 'block';
    $_SESSION['message'] = 'All products removed from the cart!';
    header('location: ../userCart.php');
}

if (isset($_POST['qty'])) {
    $qty = $_POST['qty'];
    $user = $_POST['puser'];
    $pid = $_POST['id'];
    $pprice = $_POST['pprice'];

    $tprice = $qty*$pprice;

    $stmt = $conn->prepare("UPDATE cart SET qty = ?, totalPrice = ? WHERE id = ? AND userName = ?");

    $stmt->bind_param("isis", $qty, $tprice, $pid, $user);
    $stmt->execute();
}
?>
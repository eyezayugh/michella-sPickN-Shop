<!-- Programmed By: Isaiah John Ching Fernando -->
<?php

if (isset($_POST['submit'])) {
    $username = $_POST['uid'];
    $pwd = $_POST['pwd'];
    $type = $_POST['type'];

    include 'dbh.inc.php';

    if (empty($username) || empty($pwd) || empty($type)) {
        header("location: ../adminUserLogin.php?error=empty");
        exit();
    }
    else{
        $sql = $conn->prepare("SELECT * FROM useradmin WHERE userUid = '$username';");
        $sql->execute();
        $result = $sql->get_result();
        while($row = $result->fetch_assoc()){
            $userId = $row['id'];
            $userName = $row['userName'];
            $userUid = $row['userUid'];
            $userEmail = $row['userEmail'];
            $userPhone = $row['userPhone'];
            $userType = $row['userType'];
            $userPwd = $row['userPwd'];
        }
        if($type == "Admin"){
            
            $checkPwd = password_verify($pwd, $userPwd);
        
            if ($userUid === null) {
                header("location: ../adminUserLogin.php?error=usernotexists");
                exit();
            }
            elseif ($userType["userType"] === "Deliver"){
                header("location: ../adminUserLogin.php?error=notallowed");
                exit();
            }
        
            elseif ($checkPwd === false) {
                header("location: ../adminUserLogin.php?error=wronglogin");
                exit();
            }
            else {
                session_start();
                $_SESSION["userId"] = $userId;
                $_SESSION["userName"] = $userName;
                $_SESSION["userUid"] = $userUid;
                $_SESSION["userEmail"] = $userEmail;
                $_SESSION["userPhone"] = $userPhone;
                $_SESSION["userType"] = $userType;
                
                header("location: ../adminHome.php");
                exit();
            }
        }
        elseif($type == "Deliver"){
            
            $checkPwd = password_verify($pwd, $userPwd);

            if ($userUid === null) {
                header("location: ../adminUserLogin.php?error=usernotexists");
                exit();
            }
            
            elseif($userType == "Pending"){
                header("location: ../adminUserLogin.php?error=notallowed");
                exit();
            }
        
            elseif ($checkPwd === false) {
                header("location: ../adminUserLogin.php?error=wronglogin");
                exit();
            }
            else {
                session_start();
                $_SESSION["userId"] = $userId;
                $_SESSION["userName"] = $userName;
                $_SESSION["userUid"] = $userUid;
                $_SESSION["userEmail"] = $userEmail;
                $_SESSION["userPhone"] = $userPhone;
                $_SESSION["userType"] = $userType;
                
                header("location: ../deliveryHome.php");
                exit();
            }
        }
        else{
            header("location: ../index.php");
            exit();
        }
    }
 }
 else {
     header("location: ../adminUserLogin.php");
     exit();
 }
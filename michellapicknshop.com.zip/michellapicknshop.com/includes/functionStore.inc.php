<!--Programmed by: Isaiah John Ching Fernando-->
<?php

function pnameExist($conn, $name){
    $result;
    $sql = mysqli_query($conn, "SELECT productName FROM prodcuct WHERE productName = '$name';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function pcodeExist($conn, $pcode){
    $result;
    $sql = mysqli_query($conn, "SELECT productCode FROM prodcuct WHERE productCode = '$pcode';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}

function createProduct($conn, $pname, $pcode, $desc, $brand, $type, $stock, $pprice, $origprice, $featured){
    $sql = "INSERT INTO prodcuct (productName, productPrice, productCode, productDesc, brand, typeProd, productStock, origPrice, feature) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: adminHome.php?error=stmterror");
        exit();
    }
    
    if($featured == "True"){
        $bool = 1;
    }
    if($featured == "False"){
        $bool = 0;
    }

    mysqli_stmt_bind_param($stmt, "ssssssisi", $pname, $pprice, $pcode, $desc, $brand, $type, $stock, $origprice, $bool);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: adminHome.php?store=product");
    exit();
}

function refundExist($conn, $orderCode){
    $result;
    $sql = mysqli_query($conn, "SELECT orderCode FROM refundorder WHERE orderCode = '$orderCode';") or exit(mysqli_error($sql));
    if(mysqli_num_rows($sql)){
        $result = true;
    }else {
        $result = false;
    }
    return $result;
}
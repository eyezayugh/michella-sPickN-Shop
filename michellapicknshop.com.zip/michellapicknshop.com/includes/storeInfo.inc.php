<?php
if (isset($_POST['addItem'])) {
    $pid = $_POST['id'];
    $pname = $_POST['name'];
    $pprice = $_POST['price'];
    $pimage = $_POST['image'];
    $pcode = $_POST['code'];
    $pdesc = $_POST['desc'];
    $userUid = $_POST['user'];
    $pqty = $_POST['itemQty'];

    include 'dbhStore.inc.php';

    $stmt = $conn->prepare("SELECT * FROM cart WHERE 'userName' = ?;");
    $stmt->bind_param("s", $userUid);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $code = isset($row['productCode']) ? count(array($row['productCode'])) : 0;
    $total = $pprice * $pqty;
    if (!$code) {
        if ($pqty > 0) {
            $query = $conn->prepare("INSERT INTO cart (productName, productPrice, productImage, productDesc, qty, totalPrice, productCode, userName) Values(?,?,?,?,?,?,?,?)");

            $query->bind_param("ssssisss", $pname, $pprice, $pimage, $pdesc, $pqty, $total, $pcode, $userUid);
            $query->execute();

            header("location: ../userStoreInfo.php?cart=success");
            exit();
        }else {
            header("location: ../userStoreInfo.php?error=qty");
            exit();
        }
    }else{
        header("location: ../userStoreInfo.php?error=cartExsist");
        exit();
    }
}
elseif (isset($_POST['userBuyNow'])) {
    $pid = $_POST['id'];
    $pname = $_POST['name'];
    $pprice = $_POST['price'];
    $pimage = $_POST['image'];
    $pcode = $_POST['code'];
    $pdesc = $_POST['desc'];
    $userUid = $_POST['user'];
    $pqty = $_POST['itemQty'];
    
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    include 'dbhStore.inc.php';

    $stmt = $conn->prepare("SELECT * FROM cart WHERE 'userName' = ?;");
    $stmt->bind_param("s", $userUid);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $code = isset($row['productCode']) ? count(array($row['productCode'])) : 0;
    $total = $pprice * $pqty;
    if (!$code) {
        if ($pqty > 0) {
            $query = $conn->prepare("INSERT INTO cart (productName, productPrice, productImage, productDesc, qty, totalPrice, productCode, userName) Values(?,?,?,?,?,?,?,?)");

            $query->bind_param("ssssisss", $pname, $pprice, $pimage, $pdesc, $pqty, $total, $pcode, $userUid);
            $query->execute();

            header("location: ../userCheckout.php");
            exit();
        }else {
            header("location: ../userStoreInfo.php?error=qty");
            exit();
        }
    }else{
        header("location: ../userStoreInfo.php?error=cartExsist");
        exit();
    }
}else{
    header("location: ../userHome.php");
    exit();
}
<?php
ini_set("display_errors", true);
error_reporting(-1);

if (isset($_GET['print'])) {
    $orderCode = $_GET['print'];
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM archorder WHERE orderCode = '$orderCode';");
    $sql->execute();
    $result = $sql->get_result();
    while ($row = $result->fetch_assoc()) {
        $name  = $row['userName'];
        $email = $row['userEmail'];
        $phone = $row['userPhone'];
        $address = $row['userAdd'];
        $orderStatus = $row['orderStatus'];
        $pmode = $row['pmode'];
        if ($pmode == 'cod') {
            $paymode = 'Cash on delivery';
        }
        elseif ($pmode == 'pop') {
            $paymode = 'Payment on pickup';
        }
        elseif ($pmode == 'credit') {
            $paymode = 'Credit Card';
        }
        else{
            $paymode = 'Gcash';
        }
        $orderDate = $row['cancelDate'];
        $products = $row['products'];
        $pay = $row['amountPaid'];
        $total = number_format($pay,2);
        $title = "Order Receipt | Michella's Pick N' Shop";
        include 'fpdf/fpdf.php';
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetTitle($title);
        $pdf->SetFont('Arial','', 12);
        $pdf->Cell(0,15,'',0,1);
        $pdf->Cell(0,5,'Owned & Optd by: Ms. Michella C. Caparas', 0, 1, 'C');
        $pdf->Cell(0,5,'KM44 McArthur Hi-Way Longos Malolos Bulacan', 0, 1, 'C');
        $pdf->Cell(0,5,'OFFICIAL RECEIPT', 0, 1, 'C');
        $pdf->Cell(0,5,'VAT 10%', 0, 1, 'C');
        $pdf->Cell(0,15,'',0,1);
        $pdf->Cell(35,5,'Order Code:', 1, 0);
        $pdf->Cell(65,5,$orderCode, 1, 0);
        if($orderStatus == 'Delivered'){
          $pdf->Cell(30,5,'Date Delivered:', 1, 0);
          $pdf->Cell(52,5,$orderDate, 1, 1);
        }elseif($orderStatus != 'Delivered'){
          $pdf->Cell(30,5,'Date Canceled:', 1, 0);
          $pdf->Cell(52,5,$orderDate, 1, 1);
        }
        
        $pdf->Cell(35,5,'Products:', 1, 0);
        $pdf->MultiCell(95,5,$products, 1);
        $pdf->Cell(20,5,'Vat: 10%', 1, 0);
        $pdf->Cell(15,5,'Total:', 1, 0);
        $pdf->Cell(95,5,'PHP '.$total, 1, 1, 'R');

        $pdf->Cell(35,5,'Payment Method:', 1, 0);
        $pdf->Cell(95,5,$paymode, 1, 1, 'C');
        $pdf->Cell(35,5,'Bill To:', 1, 0);
        $pdf->Cell(95,5,$name, 1, 1, 'C');
        $pdf->Cell(35,5,'Delivery to:', 1, 0);
        $pdf->MultiCell(95,5,$address, 1, 'C');
        $pdf->Cell(50,10,$email, 0, 0, 'C');
        $pdf->Cell(80,10,$phone, 0, 0, 'C');

        $pdf->Image('img/logo2.png', 65, 5, 80);
        $pdf->Image("qr/$orderCode.png",142,66,45);

        $pdf->Output();
    }
}
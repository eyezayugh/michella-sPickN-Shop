<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://kit.fontawesome.com/824d2c43ce.js?v=<?php echo time(); ?>" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/styleHeader.css?v=<?php echo time(); ?>">
    <title><?php if (isset($_SESSION["usertype"]) == 'User') {
      $useruid = $_SESSION['useruid'];
      echo "Michella's Pick N' Shop | $useruid";
    }else{
      echo'Welcome to Michella\'s Pick N\' Shop';
    }
    $useruid = $_SESSION['useruid'];
    ?></title>
  </head>
  <body>
    <!-- Header -->
    <nav class="cf">
      <ul class="cf">
        <?php
          require 'includes/dbhStore.inc.php';
          
          $sql = "SELECT count(id) AS total FROM cart WHERE userName ='$useruid'";
          $result = mysqli_query($conn,$sql);
          $values = mysqli_fetch_assoc($result);
          $num_rows = $values['total'];
          if (isset($_SESSION["usertype"]) == 'User') {
            if ($num_rows > 0) {
              echo '<li class="hide-on-small"><a href="userHome.php"><i class="fas fa-home"></i> Home</a></li>';
              echo '<li><a href="userStore.php"><i class="fas fa-store"></i> Store</a></li>';
              echo '<li><a href="userCart.php"><span class="badge">'.$num_rows.'</span><i class="fas fa-shopping-cart"></i> Cart</a></li>';
              echo '<li><a href="userProfile.php"><i class="fas fa-user-circle"></i></a></li>';
            }
            else {
              echo '<li class="hide-on-small"><a href="userHome.php"><i class="fas fa-home"></i> Home</a></li>';
              echo '<li><a href="userStore.php"><i class="fas fa-store"></i> Store</a></li>';
              echo '<li><a href="userCart.php"><i class="fas fa-shopping-cart"></i> Cart</a></li>';
              echo '<li><a href="userProfile.php"><i class="fas fa-user-circle"></i></a></li>';
            }
          }
          elseif (isset($_SESSION["usertype"]) == 'Reseller') {
            if ($num_rows > 0) {
              echo '<li class="hide-on-small"><a href="resellerHome.php"><i class="fas fa-home"></i> Home</a></li>';
              echo '<li><a href="userStore.php"><i class="fas fa-store"></i> Store</a></li>';
              echo '<li><a href="userCart.php"><span class="badge">'.$num_rows.'</span><i class="fas fa-shopping-cart"></i> Cart</a></li>';
              echo '<li><a href="userProfile.php"><i class="fas fa-user-circle"></i></a></li>';
            }
            else {
              echo '<li class="hide-on-small"><a href="resellerHome.php"><i class="fas fa-home"></i> Home</a></li>';
              echo '<li><a href="userStore.php"><i class="fas fa-store"></i> Store</a></li>';
              echo '<li><a href="userCart.php"><i class="fas fa-shopping-cart"></i> Cart</a></li>';
              echo '<li><a href="userProfile.php"><i class="fas fa-user-circle"></i></a></li>';
            }
          }
          else {
            echo '<li class="hide-on-small"><a href="#showcase">Home</a></li>';
            echo '<li><a href="#overview">Overview</a></li>';
            echo '<li><a href="#wrapper">Store</a></li>';
            echo '<li><a href="#cart">Cart</a></li>';
            echo '<li><a href="signin.php">Sign In</a></li>';
          }
        ?>
      </ul>
      <a href="#" id="openup">MICHELLE'S PICK N' SHOP</a>
    </nav>

    <script
      src="https://code.jquery.com/jquery-3.5.1.min.js"
      integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
      crossorigin="anonymous"
    ></script>
    <script src="js/main.js"></script>
  </body>
</html>

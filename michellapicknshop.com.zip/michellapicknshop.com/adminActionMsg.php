<!--Programmed By: Isaiah John Ching Fernando-->
<?php
error_reporting(-1);
ini_set('display_errors', true);
if(isset($_POST['submit-emailCustomer'])){
  $email = $_POST['email'];
  $subj = $_POST['subj'];
  $msg = $_POST['msg'];

  include 'includes/dbh.inc.php';
  $sql = mysqli_query($conn, "SELECT userEmail FROM users WHERE userEmail = '$email';") or exit(mysqli_error($sql));
  if(!mysqli_num_rows($sql)){
    header("location: adminHome.php?error=emailnotexist");
    exit();
  }
  elseif(empty($email) || empty($subj) || empty($msg)){
    header("location: adminHome.php?error=empty");
    exit();
  }
  else{
    // info to send email
    $to = $email;
    $subject = "$subj | Michelle's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Hello Valued Customer</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you, from one our staff. Reply to this only if stated bellow.</center></i>

            <p><center>'.$msg.'</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us again</a>
            </center></p>
            
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michelle's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    header("location: adminHome.php?more=message");
    exit();
  }
}
if(isset($_POST['submit-emailAdmin'])){
  $email = $_POST['email'];
  $subj = $_POST['subj'];
  $msg = $_POST['msg'];
  
  error_reporting(-1);
  ini_set('display_errors', true);
  include 'includes/dbh.inc.php';
  $sql = mysqli_query($conn, "SELECT userEmail FROM useradmin WHERE userEmail = '$email';") or exit(mysqli_error($sql));
  if(!mysqli_num_rows($sql)){
    header("location: adminHome.php?error=emailnotexist");
    exit();
  }
  elseif(empty($email) || empty($subj) || empty($msg)){
    haeder("location: adminHome.php?error=empty");
    exit();
  }
  else{
    // info to send email
    $to = $email;
    $subject = "$subj | Michelle's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Hello Valued Customer</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you, from one our staff. Reply to this only if stated bellow.</center></i>

            <p><center>'.$msg.'</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us again</a>
            </center></p>
            
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michelle's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    header("location: adminHome.php?more=message");
    exit();
  }
}
//news announcements
if(isset($_POST['submit-news'])){
  $subj = $_POST['subj'];
  $msg = $_POST['msg'];
  $file = $_FILES['file'];
  
  error_reporting(-1);
  ini_set('display_errors', true);

  if(empty($subj) || empty($msg) || empty($file)){
    header("location: adminHome.php?error=empty");
    exit();
  }
  else{
    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png');

    if (in_array($fileActualExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 4000000) {
                function generateRandomString($length = 6) {
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < $length; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    return $randomString;
                }
                $randstr = generateRandomString(6);
                $fileNameNew = $randstr.'.'.$fileActualExt;
                $fileDestination = 'news/'.$fileNameNew;
                move_uploaded_file($fileTmpName, $fileDestination);
                include 'includes/dbh.inc.php';
                $insert = $conn->query("INSERT INTO news (subj, body, newsImg) VALUES ('$subj', '$msg', '$fileDestination');");
                if ($insert) {
                    header("location: adminHome.php?more=message");
                    exit();
                }else {
                    echo $conn->error;
                }
            }else {
                header("location: adminHome.php?error=imgsize");
                exit();
            }
        }else {
            header("location: adminHome.php?error=upload");
            exit();
        }
    }else {
        header("location: adminHome.php?error=imgtype");
        exit();
    }
  }
}
//news update
if(isset($_POST['submitNews'])){
  $id = $_POST['id'];
  $file = $_FILES['file'];
  $subj = $_POST['subj'];
  $body = $_POST['body'];
  
  if(empty($id) || empty($subj) || empty($body)){
    header("location: adminHome.php?error=empty");
    exit();
  }
  else{
    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg', 'jpeg', 'png');

    if (in_array($fileActualExt, $allowed)) {
        if ($fileError === 0) {
            if ($fileSize < 4000000) {
                function generateRandomString($length = 6) {
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < $length; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    return $randomString;
                }
                $randstr = generateRandomString(6);
                $fileNameNew = $randstr.'.'.$fileActualExt;
                $fileDestination = 'news/'.$fileNameNew;
                move_uploaded_file($fileTmpName, $fileDestination);
                unlink($file);
                include 'includes/dbh.inc.php';
                $update = $conn->query("UPDATE news SET subj = '$subj', body = '$body', newsImg = '$fileDestination' WHERE id = '$id';");
                if ($update) {
                    header("location: adminHome.php?more=message");
                    exit();
                }else {
                    echo $conn->error;
                }
            }else {
                header("location: adminHome.php?error=imgsize");
                exit();
            }
        }else {
            header("location: adminHome.php?error=upload");
            exit();
        }
    }else {
        header("location: adminHome.php?error=imgtype");
        exit();
    }
  }
}
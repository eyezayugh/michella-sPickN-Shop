<!-- Programmed by: Isaiah John Ching Fernando -->
<?php
session_start();
if (isset($_SESSION["userUid"]) ) {
  header("location: adminUserLogin.php");
  session_unset();
  session_destroy();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleAdLog.css?v=<?php echo time(); ?>">
    <title>Sign In | Michella's Pick N' Shop</title>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['error'])) {
            if ($_GET['error'] == 'empty') {
            echo '<div class="alert alert-danger" id="close">
            <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
            <strong>Empty fields, please fill in all fields</strong>
            </div>';
            }
            if ($_GET['error'] == 'usernotexists') {
            echo '<div class="alert alert-danger" id="close">
            <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
            <strong>User does not exist</strong>
            </div>';
            }
            if ($_GET['error'] == 'wronglogin') {
            echo '<div class="alert alert-danger" id="close">
            <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
            <strong>Invalid Login, Please try again</strong>
            </div>';
            }
            if ($_GET['error'] == 'notallowed') {
            echo '<div class="alert alert-danger" id="close">
            <button type="button" class="close" data-dismiss="alert" onclick="myFunction()">&times;</button>
            <strong>Your account type is not allowed to enter</strong>
            </div>';
            }
        }
        ?>
        <div class="box">
            <img src="img/logo2.png"> 
            <div class="title">
                <h4>Admin</h4>
            </div>
            <form action="includes/signinAdmin.inc.php" method="POST" class="form-group">
                <div class="input-field">
                    <i class="fas fa-user"></i>
                    <input type="text" name="uid" placeholder="Username">
                </div>
                <div class="input-field">
                <i class="fas fa-lock"></i>
                    <input type="password" name="pwd" placeholder="Password">
                </div>
                <select name="type" class="form-control">
                    <option value="" selected disabled>Select Account Type</option>
                    <option value="Admin">Admin</option>
                    <option value="Deliver">Delivery</option>
                </select>
                <input type="submit" name="submit" class="btn-submit">
            </form>
        </div>
    </div>
    <script>
      function myFunction(){
        document.getElementById("close").style.display = "none";
      }
    </script>
</body>
</html>
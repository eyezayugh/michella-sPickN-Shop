<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleFooter.css" />
    <title></title>
</head>
<body>
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="logo">
          <img src="img/logo2.png" alt="" />
        </div>
        <hr />
        <div class="footer-cols">
          <ul>
            <li><i class="far fa-envelope"></i></li>
            <li>Email Us</li>
            <li>michella122770@gmail.com</li>
          </ul>
          <ul>
            <li><i class="fas fa-phone-square-alt"></i></li>
            <li>Call Us</li>
            <li>09610913468</li>
          </ul>
          <ul>
            <i class="fab fa-facebook"></i>
            <li>Find us on Facebook</li>
            <li>
              <a href="https://www.facebook.com/washdaywithus" target="_blank"
                >Click Here to Visit Our Page</a
              >
            </li>
          </ul>
        </div>
      </div>
      <div class="container">
        <div class="footer-cols">
          <ul>
            <li><i class="far fa-comments"></i></li>
            <li>FAQ</li>
            <li><a href="faq.php" target="_blank">Click here to enter our FAQ</a></li>
          </ul>
          <ul>
            <li><i class="fas fa-store"></i></li>
            <li>About Us</li>
            <li><a href="about.php" target="_blank">Learn more about our Store</a></li>
          </ul>
          <ul>
            <li><i class="fas fa-laptop-code"></i></li>
            <li>Developers</li>
            <li><a href="developer.php" target="_blank">See the developers of the website</a></li>
          </ul>
        </div>
      </div>
    </footer>
</body>
</html>
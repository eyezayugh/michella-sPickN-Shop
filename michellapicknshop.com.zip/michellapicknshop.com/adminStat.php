<!--Programmed by: Isaiah John Ching Fernando-->
<div class="container-stat">
    <style>
        .container-stat a {
            color: #eee;
            background: #999;
            margin: 0.5rem;
            padding: 0.5rem 1.2rem;
        }
    </style>
    <a href="adminPrintStat.php?printStat" target="_blank">Reports</a>
    <div id="curve_chart" style="padding: 0.5rem 0;"></div>
    <div id="columnchart_values" style="padding: 0.5rem 0;"></div>
    <div id="chart_div" style="padding: 0.5rem 0;"></div>
</div>
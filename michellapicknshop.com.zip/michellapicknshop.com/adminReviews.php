<!--Programmed by: Isaiah John Ching Fernando-->
<?php
if(isset($_POST['orderReply'])){
  $code = $_POST['code'];
  $reply = $_POST['reply'];
  
  include 'includes/dbhStore.inc.php';
  $orderReply = $conn->prepare("UPDATE userReview SET reply = ? WHERE orderCode = '$code';");
  $orderReply->bind_param("s", $reply);
  $orderReply->execute();
  $orderReply->close();
  
  $select = $conn->prepare("SELECT userEmail FROM archorder WHERE orderCode = '$code';");
  $re = $select->get_result();
  while($r = $re->fetch_assoc()){
    $email = $r['userEmail'];
    
    $to = $email;
    $subject = "Review Reply | Michella's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Order Review has been replied by Michella\'s Pick N\' Shop</center></h1>
            
            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that we, Michella\'s Pick N\' Shop have replied to your order review.</center></i>

            <p><center>Order Code: '.$code.'</center></p>
            <p><center>Check out what we replied at your account</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/signin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Sign In</a>
            </center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
  }
}
if(isset($_POST['prodReply'])){
  $id = $_POST['id'];
  $uid = $_POST['uid'];
  $prodReply = $_POST['reply'];
  
  include 'includes/dbhStore.inc.php';
  $update = $conn->prepare("UPDATE userReview SET reply = ? WHERE id = '$id';");
  $update->bind_param("s", $prodReply);
  $update->execute();
  $update->close();
  $conn->close();
  include 'includes/dbh.inc.php';
  $loop = $conn->prepare("SELECT userEmail FROM users WHERE userUid = '$uid';");
  $loop->execute();
  $results = $loop->get_result();
  while($rows = $results->fetch_assoc()){
    $email = $rows['userEmail'];
  }
  $to = $email;
    $subject = "Product Review Reply | Michella's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Product Review has been replied by Michella\'s Pick N\' Shop</center></h1>
            
            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that we, Michella\'s Pick N\' Shop have replied to your product review.</center></i>

            <p><center>Check out what we replied at our store</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/signin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Sign In</a>
            </center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
}
?>
<!--Order/Product Review Start-->
<div class="container-user">
<div class="bottom-order">
    <div class="order-title" style="margin-bottom: 1rem;">
        <h5>Order Reviews</h5>
    </div>
    <?php
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM userReview WHERE revType = 'order' ORDER BY `userReview`.`id` DESC;");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
        $orderCode = $row['orderCode'];
    ?>
    <div class="view-review" style="margin-bottom: 1rem;">
        <h5>Order Code: <?= $orderCode; ?></h5>
        <?php
        $stmt = $conn->prepare("SELECT * FROM archorder WHERE orderCode = '$orderCode';");
        $stmt->execute();
        $res = $stmt->get_result();
        while($rw = $res->fetch_assoc()){
        ?>
        <h5>Date Delivered: <?= $rw['cancelDate']; ?></h5>
        <h5>Products Ordered: <?= $rw['products']; ?></h5>
        <h5>Amount Paid: php <?= number_format($rw['amountPaid'], 2); ?></h5>
        <?php
        }
        ?>
        <h5 style="color: #279eb0;">Customer Review: <?= $row['review']; ?></h5>
        <?php
        $reply = $row['reply'];
        if(empty($reply)){
        ?>
        <form action="" method="POST" class="form-reply">
          <input type="hidden" name="code" value="<?= $orderCode; ?>">
          <textarea name="reply" style="resize: none;" cols="10" rows="3" maxlength="480" placeholder="Enter Your Reply"></textarea>
          <button type="submit" name="orderReply" class="btn btn-warning m-1"> Send Reply</button>
        </form>
        <?php
        }else{
          echo '
          <h5>Store Reply: </h5>
          <h5>'.$reply.'</h5>';
        }
        ?>
    </div>
    <?php
    }
    ?>
    <div class="order-title" style="margin-bottom: 1rem;">
        <h5>Product Reviews</h5>
    </div>
    <?php
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM userReview WHERE revType = 'product' ORDER BY `userReview`.`id` DESC;");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
        $orderCode = $row['orderCode'];
    ?>
    <div class="view-review" style="margin-bottom: 1rem;">
        <h5>Customer: <?= $row['userUid'];; ?></h5>
        <?php
        $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE id = '$orderCode';");
        $stmt->execute();
        $res = $stmt->get_result();
        while($rw = $res->fetch_assoc()){
        ?>
        <h5>Product Name: <?= $rw['productName']; ?></h5>
        <h5>Product Price <?= $rw['productPrice']; ?></h5>
        <h5>Product Stock: <?= $rw['productStock']; ?></h5>
        <?php
        }
        ?>
        <h5 style="color: #279eb0;">Customer Review: <?= $row['review']; ?></h5>
        <?php
        $reply = $row['reply'];
        if(empty($reply)){
        ?>
        <form action="" method="POST" class="form-reply">
          <input type="hidden" name="id" value="<?= $row['id']; ?>">
          <input type="hidden" name="uid" value="<?= $row['userUid']; ?>">
          <textarea name="reply" style="resize: none;" cols="10" rows="3" maxlength="480" placeholder="Enter Your Reply"></textarea>
          <button type="submit" name="prodReply" class="btn btn-warning m-1"> Send Reply</button>
        </form>
        <?php
        }else{
          echo '
          <h5>Store Reply: </h5>
          <h5>'.$reply.'</h5>';
        }
        ?>
    </div>
    <?php
    }
    ?>
</div>
</div>
<!--Order/Product Review End-->
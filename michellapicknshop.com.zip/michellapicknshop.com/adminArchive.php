<!--Programmed by: Isaiah John Ching Fernando-->
<?php error_reporting(-1); ?>
<?php ini_set('display_errors', true); ?>
<div class="container-archive">
  <div class="title-archive">
    <h4>Customer Accounts</h4>
  </div>
  <div class="box-archive">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Username</th>
          <th>Verified</th>
          <th>Action</th>
        </tr>
      </thead>
  <?php
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM archusers ORDER BY archId DESC");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
  ?>
      <tbody>
        <tr>
          <td><?= $row['archId']; ?></td>
          <td><?= $row['userName']; ?></td>
          <td><?= $row['userUid']; ?></td>
          <?php
          $verified = $row['verified'];
          if($verified == 0){
            echo '<td>False</td>';
          }else{
            echo '<td>True</td>';
          }
          if($verified == 0){
          ?>
          <td><a class="btn-recover" href="#" onclick = "return confirm('You are not allowed to restore a user that was not verified')"><i class="fas fa-redo"></i></a></td>
          <?php
          }
          else{
          ?>
          <td><a class="btn-recover" href="adminHome.php?recoverCus=<?= $row['archId']; ?>" onclick="return confirm('Are you sure you want to recover this account')"><i class="fas fa-redo"></i></a></td>
          <?php
          }
          ?>
        </tr>
      </tbody>
  <?php
  }
  ?>
    </table>
  </div>
  <div class="title-archive">
    <h4>Admin Accounts</h4>
  </div>
  <div class="box-archive">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Username</th>
          <th>Action</th>
        </tr>
      </thead>
  <?php
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM archuseradmin WHERE userType = 'Admin' ORDER BY id DESC;");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
  ?>
      <tbody>
        <tr>
          <td><?= $row['id']; ?></td>
          <td><?= $row['userName']; ?></td>
          <td><?= $row['userUid']; ?></td>
          <td><a class="btn-recover" href="adminHome.php?recoverAdm=<?= $row['id'];?>" onclick="return confirm('Are you sure you want to recover this account')"><i class="fas fa-redo"></i></a></td>
        </tr>
      </tbody>
  <?php
  }
  mysqli_close($conn);
  ?>
    </table>
  </div>
  <div class="title-archive">
    <h4>Porter Accounts</h4>
  </div>
  <div class="box-archive">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Username</th>
          <th>Action</th>
        </tr>
      </thead>
  <?php
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM archuseradmin WHERE userType = 'Deliver' ORDER BY id DESC;");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
  ?>
      <tbody>
        <tr>
          <td><?= $row['id']; ?></td>
          <td><?= $row['userName']; ?></td>
          <td><?= $row['userUid']; ?></td>
          <td><a class="btn-recover" href="adminHome.php?recoverPort=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to recover this account')"><i class="fas fa-redo"></i></a></td>
        </tr>
      </tbody>
  <?php
  }
  mysqli_close($conn);
  ?>
    </table>
  </div>
  <div class="title-archive">
    <h4>Product Archive</h4>
  </div>
  <div class="box-archive">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Product Name</th>
          <th>Code</th>
          <th>Brand</th>
          <th>Type</th>
          <th>Price</th>
          <th>Action</th>
        </tr>
      </thead>
  <?php
  include 'includes/dbhStore.inc.php';
  $sql = $conn->prepare("SELECT * FROM archprodcuct ORDER BY id DESC;");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
  ?>
      <tbody>
        <tr>
          <td><?= $row['id']; ?></td>
          <td><?= $row['productName']; ?></td>
          <td><?= $row['productCode']; ?></td>
          <td><?= $row['brand']; ?></td>
          <td><?= $row['typeProd']; ?></td>
          <td><?= $row['productPrice']; ?></td>
          <td><a class="btn-recover" href="adminHome.php?recoverProd=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to recover this product')"><i class="fas fa-redo"></i></a></td>
        </tr>
      </tbody>
  <?php
  }
  mysqli_close($conn);
  ?>
    </table>
  </div>
  <div class="title-archive">
    <h4>News/Announcements Archive</h4>
  </div>
  <div class="box-archive">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Title</th>
          <th>Body</th>
          <th>Date Deleted</th>
          <th>Action</th>
        </tr>
      </thead>
  <?php
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM archnews ORDER BY id DESC;");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
  ?>
      <tbody>
        <tr>
          <td><?= $row['id']; ?></td>
          <td><?= $row['subj']; ?></td>
          <td><?= $row['body']; ?></td>
          <td><?= $row['deleteDate']; ?></td>
          <td><a class="btn-recover" href="adminHome.php?recoverNews=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to recover this Post')"><i class="fas fa-redo"></i></a></td>
        </tr>
      </tbody>
  <?php
  }
  mysqli_close($conn);
  ?>
    </table>
  </div>
</div>
<!-- Programmed by: Isaiah John Ching Fernando-->
<?php
session_start();
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];

if(isset($_POST['submitReview'])){
  $prodCode = $_POST['prodCode'];
  $uid = $_POST['uid'];
  $review = $_POST['review'];
  $revType = 'product';
  
  if(empty($review)){
    header("location: userStoreInfo.php?error=empty");
    exit();
  }
  
  include 'includes/dbhStore.inc.php';
  $insert = $conn->prepare("INSERT INTO userReview(userUid, orderCode, review, revType) VALUES(?, ?, ?, ?);");
  $insert->bind_param("ssss", $uid, $prodCode, $review, $revType);
  $insert->execute();
  $insert->close();
  $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/magnify.css?v=<?php echo time(); ?>" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Store | Michella's Pick N' Shop |<?php echo ' '.$userUid; ?></title>
</head>
<body>
<?php
    if ($userType == 'User' ) {
  ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="userHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    }
    if ($userType == 'Reseller') {
    ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="resellerHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php }?>
    <div class="message">
        <?php
        if (isset($_GET['error'])) {
            if ($_GET['error'] == 'qty') {
          ?>
          <div class="alert alert-danger alert-dismissible text-center mt-1">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>Invalid Quantity, Please Enter a valid quantity!</strong>
          </div>
        <?php 
            }
            if ($_GET['error'] == 'empty') {
          ?>
          <div class="alert alert-danger alert-dismissible text-center mt-1">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>Please Fill In all Fields</strong>
          </div>
        <?php 
            }
            if ($_GET['error'] == 'cartExsist') {
            ?>
            <div class="alert alert-danger alert-dismissible text-center mt-1">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Item already in your cart</strong>
            </div>
            <?php 
                }
        }
        if (isset($_GET['cart'])) {
            if ($_GET['cart'] == 'success') {
            ?>
            <div class="alert alert-success alert-dismissible text-center mt-1">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Item added to your cart!</strong>
            </div>
            <?php 
            }
        }?>
    </div>
    <div class="container">
      <div class="row m-5">
        <?php
          if (isset($_GET['product'])) {
            $id = $_GET['product'];
            include 'includes/dbhStore.inc.php';
            $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE id ='$id';");
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()){
        ?>
        <div class="card p-2 border-left justify-content-center m-2 ml-5 pl-5" style="display: grid; grid-template-columns: repeat(2, 1fr);">
          <div class="inner">
            <img src="<?=$row['productImage'];?>" width="250" id="image" class="zoom" data-magnify-src="<?=$row['productImage'];?>">
          </div>
          <div>
            <h3 class="text-center"><?=$row['productName'];?></h3>
            <p class="text-xl-left"><?=$row['productDesc']; ?></p>
            <h5 class="text-danger m-2 p-2">PHP <?=$row['productPrice']; ?></h5>
            <div class="button-box p-3">
                <form action="includes/storeInfo.inc.php" method="POST" class="justify-content-center">
                    <div class="row ml-1">
                        <h6 class="text-lg-left mr-3">Quantity</h6>
                        <input type="number" min="1" max="<?= $row['productStock']; ?>" class="form-control mt-2 mb-2" name="itemQty" placeholder="1" value="1" style="width: 65px;">
                        <h7 class="text-lg-right ml-3"><?= $row['productStock'] ?> item(s) available</h7>
                    </div>
                    <input type="hidden" name="id" value="<?=$row['id']; ?>">
                    <input type="hidden" name="name" value="<?=$row['productName']; ?>">
                    <input type="hidden" name="price" value="<?=$row['productPrice']; ?>">
                    <input type="hidden" name="image" value="<?=$row['productImage']; ?>">
                    <input type="hidden" name="code" value="<?=$row['productCode']; ?>">
                    <input type="hidden" name="desc" value="<?=$row['productDesc']; ?>">
                    <input type="hidden" name="user" value="<?= $userUid ?>">
                    <div style="display:grid; grid-template-column:1fr;">
                        <button class="btn btn-warning mb-2" name="addItem" style="width: 200px;"><i class="fas fa-shopping-cart"></i> Add to cart</button>
                        <button class="btn btn-info mt-2" style="width: 200px;" name="userBuyNow"><i class="fas fa-credit-card"></i> Buy Now</button>
                    </div>
                </form>
            </div>
          </div>
          <div class="col ml-4">
            <div class="row">
                
            </div>
          </div>
        </div>
        <?php 
          }
        }else{
          echo '<a href="userStore.php" class="btn btn-info m-3"><i class="fas fa-store"></i> Back to Store</a>';
        }
        ?>
      </div>
    </div>
    <?php
    if (isset($_GET['cart'])) {
      if ($_GET['cart'] == 'success') {
    ?>
    <div class="row justify-content-center">
     <h5 class="text-center text-info" style="text-transform: uppercase; letter-spacing: 2px;">Featured Products</h5>
    </div>
    <div class="container">
      <div class="row mt-2 pb-3">
    <?php    
        include 'includes/dbhStore.inc.php';

        $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE feature = 1;");
        $stmt->execute();
        $result = $stmt->get_result();
        while($row = $result->fetch_assoc()){
   ?>
   <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
    <div class="card-deck">
      <div class="card p-2 border-bottom md-2">
        <a href="userStoreInfo.php?product=<?=$row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="180"></a>
        <div class="card-body p-1">
          <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
          <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
        </div>
        <div class="card-footer p-1 pb-2">
          <a href="store.php?error=signin" class="btn btn-warning btn-block"><i class="fas fa-shopping-cart"></i> Add to cart</a>
        </div>
        </div>
      </div>
    </div>
   <?php
        }     
      }
    ?>
    </div>
    </div>
    <?php
    }else{
    ?>
    <div class="row justify-content-center">
        <h5 class="text-center text-info" style="text-transform: uppercase; letter-spacing: 2px;">Similar Products</h5>
    </div>
    <div class="container">
      <div class="row mt-2 pb-3">
        <?php
        include 'includes/dbhStore.inc.php';
        $id = $_GET['product'];
        $sql = $conn->prepare("SELECT * FROM prodcuct WHERE id = '$id';");
        $sql->execute();
        $res = $sql->get_result();
        while($rw = $res->fetch_assoc()){
          $brand = $rw['brand'];
          $type = $rw['typeProd'];
          $space = '/\s/';
          $stmt = $conn->prepare("SELECT * FROM prodcuct WHERE brand LIKE '%$brand%' OR typeProd LIKE '%$type%';");
          $stmt->execute();
          $result = $stmt->get_result();
          while ($row = $result->fetch_assoc()){
          ?>
          <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
            <div class="card-deck">
              <div class="card p-2 border-bottom md-2">
                <a href="userStoreInfo.php?product=<?=$row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="180"></a>
                <div class="card-body p-1">
                  <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
                  <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                </div>
                <div class="card-footer p-1 pb-2">
                  <a href="store.php?error=signin" class="btn btn-warning btn-block"><i class="fas fa-shopping-cart"></i> Add to cart</a>
                </div>
              </div>
            </div>
          </div>
        <?php
          } 
        } 
      }?>
      </div>
    </div>
    
    <div class="container mb-2">
      <?php
      if(isset($_GET['product'])){
        $prodId = $_GET['product'];
      }
      ?>
      <h5 class="text-primary">Post a Review</h5>
      <form action="" method="POST" class="m-1">
        <input type="hidden" name="prodCode" value="<?= $prodId; ?>">
        <input type="hidden" name="uid" value="<?= $userUid; ?>">
        <textarea name="review" class="form-control m-1" style="resize: none;" cols="10" rows="3" maxlength="460" placeholder="Enter your Review of the Product Here"></textarea>
        <button type="submit" name="submitReview" class="btn btn-success m-1">Post Review</button>
      </form>
      <h5 class="text-primary mt-4">All Reviews of Product</h5>
        <?php
        include 'includes/dbhStore.inc.php';
        $select = $conn->prepare("SELECT * FROM userReview WHERE orderCode = '$prodId' ORDER BY `id` DESC;");
        $select->execute();
        $re = $select->get_result();
        while($r = $re->fetch_assoc()){
          $reply = $r['reply'];
        ?>
        <div class="m-2 mb-4 p-1" style="background: #eee;">
          <h6 class="m-1 p-1"><?= $r['userUid']; ?></h6>
          <h6 class="m-1 p-1"><?= $r['review']; ?></h6>
          <?php
          if(!empty($reply)){
          ?>
          <h6 class="m-1 mt-3 p-1"><i class="far fa-gem"> Michella's Pick N' Shop</i></h6>
          <h6 class="m-1 p-1"><?= $reply; ?></h6>
          <?php
          }
          ?>
        </div>
        <?php
        }
        ?>
    </div>

    <?php
      include_once 'footer.php';
    ?>
    <script src="js/jquery.magnify.js" charset="UTF-8"></script>
    <script>
    $(document).ready(function() {
      $('.zoom').magnify();
    });
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
        $(".addItemBtn2").click(function(e){
          e.preventDefault();
          var $form = $(this).closest(".form-submit");
          var itemQty = $form.find(".itemQty").val();
          var id = $form.find(".id").val();
          var name = $form.find(".name").val();
          var price = $form.find(".price").val();
          var image = $form.find(".image").val();
          var code = $form.find(".code").val();
          var desc = $form.find(".desc").val();
          var user = $form.find(".user").val();

          $.ajax({
            url: 'includes/storeInfo.inc.php',
            method: 'post',
            data: {itemQty:itemQty,id:id,name:name,price:price,image:image,code:code,desc:desc,user:user},
            success:function(response){
              $("#message").html(response);
              window.scrollTo(0,0);
              load_cart_item_number();
            }
          });
        });

        load_cart_item_number();

        function load_cart_item_number(){
          $.ajax({
            url: 'includes/actionCart.inc.php',
            method: 'get',
            data: {cartItem:"cart_item"},
            success:function(response){
              $("#cart-item").html(response);
            }
          });
        }

      });
    </script>
</body>
</html>
<!-- Programmed by: Isaiah John Ching Fernando-->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/mobile.css?v=<?php echo time(); ?>">
    <title>Store | Michella's Pick N' Shop</title>
  </head>
  <body class="bg-light" style="overflow-x: hidden;">
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="index.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="store.php">Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="store.php?error=signin"><i class="fab fa-opencart" style="color: #49b7ca;"></i></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="signin.php">Sign In</a>
          </li>
        </ul>
      </div>
    </nav>
    <div class="row">
      <!-- Categories Section-->
      <div class="col-lg-3">
        <div class="container">
          <h5 class="mt-2 ml-2">Filter Product</h5>
          <hr>
          <h6 class="text-info m-2">Select Brand <button class="btn btn-light" onclick="show_hide()"><i class="fas fa-chevron-down"></i></button></h6>
          <ul class="list-group" id="hide">
            <?php
              include 'includes/dbhStore.inc.php';
              $sql = "SELECT DISTINCT brand FROM prodcuct ORDER BY brand;";
              $result = $conn->query($sql);
              while($row = $result->fetch_assoc()){
            ?>
            <li class="list-group-item">
              <div class="form-check">
                <label class="form-check-label">
                  <input type="checkbox" class="form-check-input product_check" value="<?= $row['brand'];?>" id="brand"><?= $row['brand']; ?>
                </label>
              </div>
            </li>
            <?php 
            } 
            ?>
          </ul>
          <h6 class="text-info m-2">Product Category<button class="btn btn-light" onclick="show_hide2()"><i class="fas fa-chevron-down"></i></button></h6>
            <ul class="list-group" id="hide2">
              <?php
                include 'includes/dbhStore.inc.php';
                $sql = "SELECT DISTINCT typeProd FROM prodcuct ORDER BY typeProd;";
                $result = $conn->query($sql);
                while($row = $result->fetch_assoc()){
              ?>
              <li class="list-group-item">
                <div class="form-check">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input product_check" value="<?= $row['typeProd']; ?>" id="typeProd"><?= $row['typeProd']; ?>
                  </label>
                </div>
              </li>
              <?php 
              } 
              ?>
            </ul>
        </div>
      </div>
      <!-- Product Section-->
      <div class="col">
        <div class="container">
          <!-- Search Field -->
          <?php include 'includes/dbhStore.inc.php';?>
          <form action="" method="POST">
            <div class="form-inline input-group col-sm-8 col-xs-12 col-lg-4 mt-2 mb-1">
              <input type="text" name="search" class="form-control" placeholder="Search">
              <button type="submit" name="submit-search" class="btn btn-outline-info"><i class="fas fa-search"></i></button>
            </div>
          </form>
          <!-- Error Messages -->
          <div class="message">
            <?php
            if (isset($_GET['error'])) {
              if ($_GET['error'] == 'signin') {
            ?>
            <div class="alert alert-danger alert-dismissible  mt-1 fade show">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong>Please Sign In to  Access your Cart!</strong>
            </div>
            <?php 
              }
            }
           ?>
            
          </div>
          <!-- Product Output -->
          <div class="text-center">
            <img src="img/load.gif" id="loader" width="200" style="display: none;">
          </div>
          <div class="row mt-2 pb-3" id="result">
            <?php
            include 'includes/dbhStore.inc.php';
            if (isset($_POST['submit-search'])) {
              $space = '/\s/';
              $search = mysqli_real_escape_string($conn, $_POST['search']);
              $sql="SELECT * FROM prodcuct WHERE productName LIKE '%$search%' OR productDesc LIKE '%$search%' OR productName LIKE '%$space%' OR productDesc LIKE '%$space%';";
              $result = mysqli_query($conn, $sql);
              $queryResult = mysqli_num_rows($result);

              if ($queryResult > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
              ?>
              <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
                <div class="card-deck" height = "100">
                  <div class="card p-2 border-bottom md-2">
                    <a href="actionInfo.php?id=<?=$row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="180"></a>
                    <div class="card-body p-1">
                      <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
                      <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                    </div>
                    <div class="card-footer p-1 pb-2">
                      <a href="store.php?error=signin" class="btn btn-warning btn-block"><i class="fas fa-shopping-cart"></i> Add to cart</a>
                    </div>
                  </div>
                </div>
              </div>
            <?php
                }

              }else{
                echo'<div class="alert alert-danger alert-dismissible  mt-2">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>There are no results matching your search</strong>
              </div>';
                exit();
              }
            }
            else{
              include 'includes/dbhStore.inc.php';
              $stmt = $conn->prepare("SELECT * FROM prodcuct;");
              $stmt->execute();
              $result = $stmt->get_result();
              while ($row = $result->fetch_assoc()){
            ?>
            <div class="col-sm-6 col-md-4 col-lg-3 mb-2">
              <div class="card-deck">
                <div class="card p-2 border-bottom mb-2">
                  <a href="actionInfo.php?id=<?=$row['id']; ?>"><img src="<?= $row['productImage']?>" class="card-img-top" width="100%" height="100%"></a>
                  <div class="card-body p-1">
                    <h5 class="card-title text-center text-info"><?=$row['productName']; ?></h5>
                    <h6 class="card-text text-center text-danger">PHP <?=number_format($row['productPrice'],2); ?></h6>
                  </div>
                  <div class="card-footer p-1 pb-2">
                    <a href="store.php?error=signin" class="btn btn-warning btn-block"><i class="fas fa-shopping-cart"></i> Add to cart</a>
                  </div>
                </div>
              </div>
            </div>
            <?php
              }
            }
            ?>
          </div>
        </div>
      </div>
    </div>

    <?php
      include_once 'footer.php';
    ?>
    <script type="text/javascript">
      $(document).ready(function(){

        $(".product_check").click(function(){
          $('#loader').show();
          var action = 'data';
          var brand = get_filter_text('brand');
          var typeProd = get_filter_text('typeProd');

          $.ajax({
            url:'action.php',
            method:'POST',
            data:{action:action,brand:brand,typeProd:typeProd},
            success:function(response){
              $("#result").html(response);
              $("#loader").hide();
            }
          });
        });

        function get_filter_text(text_id){
          var filterData = [];
          $('#'+text_id+':checked').each(function(){
            filterData.push($(this).val());
          });
          return filterData;
        }

      });
    </script>
    <script src="js/showhide.js"></script>
  </body>
</html>
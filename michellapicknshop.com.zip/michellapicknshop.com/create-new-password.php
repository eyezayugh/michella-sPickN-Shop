<!-- Programmed by: Isaiah John Ching Fernando -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sign in & Sign Up</title>
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleLogin.css" />
  </head>
  <body>
    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
            <?php
                $selector = $_GET["selector"];
                $validator = $_GET["validator"];

                if (empty($selector) || empty($validator)) {
                    header("location: index.php");
                    exit();
                }else{
                    if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false) {
                        ?>

                        <form action="includes/reset-password.inc.php" method="POST" class="sign-in-form">
                            <h2 class="title">Create New Password</h2>
                            <p>An e-mail will be sent to you with instructions on how to reset your password</p>
                            <?php
                              if (isset($_GET["error"])) {
                                if ($_GET["error"] == "resubmit") {
                                  echo "<p style='color: red;'>You need to re-submit your reset request. Reset password will no longer work</p>";
                                }
                              }
                            ?>
                            <input type="hidden" name="selector" value="<?php echo $selector;?>">
                            <input type="hidden" name="validator" value="<?php echo $validator;?>">
                            <div class="input-field">
                                <i class="fas fa-lock"></i>
                                <input type="password" name="pwd" placeholder="Enter a New Password" />
                            </div>
                            <div class="input-field">
                                <i class="fas fa-lock"></i>
                                <input type="password" name="pwd-repeat" placeholder="Confirm New Password" />
                            </div>
                            <input type="submit" name="reset-password-submit" value="Reset Password" class="btn solid" />
                        </form>

                        <?php
                    }
                }
            ?>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h3>Password Security</h3>
            <p>
              Keep your password secure, do not share it with anyone. Remember to not have the same password on multiple sites, and make it a strong unique set of characters.
            </p>
          </div>
          <img src="img/secure.svg" class="image" alt="" />
        </div>
      </div>
    </div>
  </body>
</html>
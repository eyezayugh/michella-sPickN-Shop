<!--Programmed by: Isaiah John Ching Fernando-->
<!--Refund order start-->
<div class="container-user">
  <div class="top-customer">
    <h4 class="title">Refund Request</h4>
    <form action="" method="POST" class="search-form">
        <input type="text" name="search" class="search-customer" placeholder="Search">
        <button type="submit" name="submit-searchAdmin" class="btn-search"><i class="fas fa-search"></i></button>
    </form>
  </div>
  <div class="bottom-refund">
    <?php
    include 'includes/dbhStore.inc.php';
    if (isset($_POST['submit-searchAdmin'])) {
      $space = '/\s/';
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $sql="SELECT * FROM refundorder WHERE orderCode LIKE '%$search%' OR prodDesc LIKE '%$search%' OR orderCode LIKE '%$space%' OR prodDesc LIKE '%$space%';";
      $result = mysqli_query($conn, $sql);
      $queryResult = mysqli_num_rows($result);
      ?>
      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Description</th>
            <th>Order</th>
            <th>Payment Mode</th>
            <td colspan = "3">Action</td>
          </tr>
        </thead>
     <?php

      if ($queryResult > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $orderCode = $row['orderCode'];
            $newstring = substr($orderCode, -4);
            $str = $conn->prepare("SELECT * FROM archorder WHERE orderCode ='$orderCode';");
            $str->execute();
            $re = $str->get_result();
            while($r = $re->fetch_assoc()){
                $pmode = $r['pmode'];
            }
     ?>
        <tbody>
          <tr>
            <td><img src="<?= $row['prodimg']; ?>" style="width: 120px;"></td>
            <td style="width-space:pre;"><?= $row['prodDesc']; ?></td>
            <td>*****<?= $newstring; ?></td>
            <?php
            if($pmode == 'cod'){
                echo '<td>Cash on Delivery</td>';
            }
            elseif($pmode == 'pop'){
                echo '<td>Payment on Pickup</td>';
            }
            elseif($pmode == 'credit'){
                echo '<td>Credit Card</td>';
            }
            ?>
            <td style="border-right: 0px none;">
                <a href="adminHome.php?viewRefund=<?=$id;?>" class="btn-show"><i class="far fa-eye"></i></a>
            </td>
            <td style="border-left: 0px none; border-right: 0px none;">
                <a href="adminHome.php?refundapprove=<?=$id;?>" class="btn-show" style="background:#3CA42F;"><i class="fas fa-check"></i></a>
            </td>
            <td style="border-left: 0px none;">
                <a href="adminHome.php?refunddecline=<?=$id;?>" onclick = "return confirm('Are you sure you want to decline this request?')"style="color:#C41A1A; font-size: 2rem"><i class="fas fa-times-circle"></i></a>
            </td>
          </tr>
        </tbody>
    
    <?php
        }
    ?>
    </table>
    <?php
      }
      else{
    ?>
    <h4 style="color: red; text-align: center;">No Results Found</h4>
    <?php
      }
    }else{
    ?>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Description</th>
                <th>Order</th>
                <th>Payment Mode</th>
                <th>Amount Paid</th>
                <td colspan = "3">Action</td>
            </tr>
        </thead>
        <tbody>
        <?php
          include 'includes/dbhStore.inc.php';
          $sql = $conn->prepare("SELECT * FROM refundorder");
          $sql->execute();
          $result = $sql->get_result();
          while($row = $result->fetch_assoc()){
              $id = $row['id'];
              $orderCode = $row['orderCode'];
              $newstring = substr($orderCode, -4);
              $stmt = $conn->prepare("SELECT * FROM archorder WHERE orderCode = '$orderCode';");
              $stmt->execute();
              $res = $stmt->get_result();
              while($rw = $res->fetch_assoc()){
                  $pmode = $rw['pmode'];
                  $amountPaid = $rw['amountPaid'];
              }
        ?>
            <tr>
                <td><img src="<?= $row['prodimg']; ?>" style="width: 120px;"></td>
                <td style="width-space:pre;"><?= $row['prodDesc']; ?></td>
                <td>*****<?= $newstring; ?></td>
                <?php
                if($pmode == 'cod'){
                    echo '<td>Cash on Delivery</td>';
                }
                elseif($pmode == 'pop'){
                    echo '<td>Payment on Pickup</td>';
                }
                elseif($pmode == 'credit'){
                    echo '<td>Credit Card</td>';
                }
                ?>
                <td>php <?= number_format($amountPaid, 2); ?></td>
                <td style="border-right: 0px none;">
                    <a href="adminHome.php?viewRefund=<?=$id;?>" class="btn-show"><i class="far fa-eye"></i></a>
                </td>
                <td style="border-left: 0px none; border-right: 0px none;">
                    <a href="adminHome.php?refundapprove=<?=$id;?>" class="btn-show" style="background:#3CA42F;"><i class="fas fa-check"></i></a>
                </td>
                <td style="border-left: 0px none;">
                    <a href="adminHome.php?refunddecline=<?=$id;?>" onclick = "return confirm('Are you sure you want to decline this request?')"style="color:#C41A1A; font-size: 2rem"><i class="fas fa-times-circle"></i></a>
                </td>
            </tr>
        <?php
          }?>
        </tbody>
    </table>
    <?php
    }
    ?>
  </div>
</div>
<!--Refund order end-->
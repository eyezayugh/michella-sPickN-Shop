<!-- Programmed by: Isaiah John Ching Fernando-->
<?php
session_start();
if ($_SESSION["useruid"] == null) {
    header('location: index.php');
    exit();
}
$userId = $_SESSION["userid"];
$userUid = $_SESSION["useruid"];
$userName = $_SESSION["username"];
$userEmail = $_SESSION["useremail"];
$userPhone = $_SESSION["userphone"];
$verify = $_SESSION["verify"];
$userType = $_SESSION["usertype"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?php echo time(); ?>">
    <title>Cart | Michella's Pick N' Shop |<?php echo ' '.$userUid; ?></title>
</head>
<body class="bg-light" style="overflow-x: hidden;">
<?php
    if ($userType == 'User' ) {
  ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="userHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
    }
    if ($userType == 'Reseller') {
    ?>
    <nav class="navbar navbar-expand-md bg-white navbar-light">
      <!-- Brand -->
      <a class="navbar-brand" href="userHome.php"><img src="img/logo2.png" style="height: 2rem;" alt=""></a>

      <!-- Toggler/collapsibe Button -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Navbar links -->
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="resellerHome.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userStore.php"><i class="fas fa-store"></i> Store</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userCart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userProfile.php"><i class="fas fa-user-circle"></i></a>
          </li>
        </ul>
      </div>
    </nav>
    <?php
  }
  ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div style="display:<?php if(isset($_SESSION['showAlert'])){echo $_SESSION['showAlert'];}
                else{echo 'none';} unset($_SESSION['showAlert']);?>;" class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <strong><?php if(isset($_SESSION['message'])){echo $_SESSION['message'];} unset($_SESSION['message']);?></strong>
                </div>
                <div class="table-responsive mt-2">
                    <table class="table table-bordered table-striped text-center">
                        <thead class="thead-dark">
                            <tr class="bg-dark">
                                <td colspan="7">
                                    <h4 class="text-center text-white m-0">Products in your cart</h4>
                                </td>
                            </tr>
                            <tr>
                                <th>Product</th>
                                <th>Name</th>
                                <th>Product Code</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total Price</th>
                                <th>
                                    <a href="includes/actionCart.inc.php?clear=all" class="badge-danger badge p-1" 
                                    onclick="return confirm('Are you sure you want to clear your cart?');">
                                    <i class="fas fa-trash"></i> Clear Cart</a>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require 'includes/dbhStore.inc.php';
                            $stmt = $conn->prepare("SELECT * FROM cart WHERE userName ='$userUid'");
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $grand_total = 0;
                            while($row = $result->fetch_assoc()){
                            ?>
                            <tr>
                                <input type="hidden" class="puser" value="<?= $row['userName']; ?>">
                                <input type="hidden" class="id" value="<?= $row['id']; ?>">
                                <td><img src="<?= $row['productImage']; ?>" width="50"></td>
                                <td style="font-size: 14px;"><?= $row['productName']; ?></td>
                                <td><?= $row['productCode']; ?></td>
                                <td>PHP <?= number_format($row['productPrice'],2); ?></td>
                                <input type="hidden" class="pprice" value="<?= $row['productPrice']; ?>">
                                <?php
                                $pname = $row['productName'];
                                $sql = $conn->prepare("SELECT * FROM prodcuct WHERE productName = '$pname';");
                                $sql->execute();
                                $res = $sql->get_result();
                                while($rw = $res->fetch_assoc()){
                                    $pstock = $rw['productStock'];
                                ?>
                                <td><input type="number" min="1" max="<?= $pstock; ?>" oninput="validity.valid||(value='');" class="form-control itemQty" value="<?= $row['qty'];?>" style="width: 65px;"></td>
                                <?php
                                }
                                ?>
                                <td>PHP <?= number_format($row['totalPrice'],2); ?></td>
                                <td>
                                    <a href="includes/actionCart.inc.php?remove=<?= $row['id'];?>" class="text-danger lead" onclick="return confirm('Are you sure you want to remove this item?')"><i class="fas fa-trash-alt"></i></a>
                                </td>
                            </tr>
                            <?php $grand_total += $row['totalPrice'];
                            } ?>
                            <tr>
                                <td colspan="3">
                                    <a href="userStore.php" class="btn btn-success"><i class="fas fa-shopping-bag"></i> Continue Shopping</a>
                                </td>
                                <td colspan="2"><b>Grand Total</b></td>
                                <td><b>PHP <?= number_format($grand_total,2); ?></b></td>
                                <td>
                                    <a href="userCheckout.php" class="btn btn-info <?= ($grand_total > 1)?"":"disabled" ?>">Checkout</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php
      include_once 'footer.php';
    ?>
    
    <script type="text/javascript">
      $(document).ready(function(){
        
        $(".itemQty").on('change', function(){
            var $el = $(this).closest('tr');

            var puser = $el.find(".puser").val();
            var id = $el.find(".id").val();    
            var pprice = $el.find(".pprice").val();   
            var qty = $el.find(".itemQty").val();
            location.reload(true);
            $.ajax({
                url: 'includes/actionCart.inc.php',
                method: 'post',
                cache: false,
                data: {qty:qty,id:id,pprice:pprice,puser:puser},
                success: function(response){
                    console.log(response);
                }
            });   
        });

        load_cart_item_number();

        function load_cart_item_number(){
          $.ajax({
            url: 'includes/actionCart.inc.php',
            method: 'get',
            data: {cartItem:"cart_item"},
            success:function(response){
              $("#cart-item").html(response);
            }
          });
        }

      });
    </script>
</body>
</html>
//Programmed by: Isaiah John Ching Fernando
var modalBtnView = document.querySelector(".");
var modalBgView = document.querySelector(".modal-bgView");

modalBtnView.addEventListener("click", function () {
  modalBgView.classList.add("bg-active");
});

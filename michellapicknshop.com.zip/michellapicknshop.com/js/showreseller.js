var a = 0;
function show_hide() {
  if (a == 0) {
    document.getElementById("show").style.display = "inline";
    return (a = 1);
  } else {
    document.getElementById("show").style.display = "none";
    return (a = 0);
  }
}

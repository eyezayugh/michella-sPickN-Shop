var a;
function show_hide() {
  if (a == 1) {
    document.getElementById("hide").style.display = "inline";
    return (a = 0);
  } else {
    document.getElementById("hide").style.display = "none";
    return (a = 1);
  }
}
var b;
function show_hide2() {
  if (b == 1) {
    document.getElementById("hide2").style.display = "inline";
    return (b = 0);
  } else {
    document.getElementById("hide2").style.display = "none";
    return (b = 1);
  }
}

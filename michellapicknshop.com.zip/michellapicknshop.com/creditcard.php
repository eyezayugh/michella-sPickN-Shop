<!-- Programmed by: Isaiah John Ching Fernando -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script src="https://kit.fontawesome.com/824d2c43ce.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="css/styleCreditCard.css?v=<?php echo time(); ?>">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css?v=<?php echo time(); ?>">

  <title>Credit Card | Michella's Pick N' Shop</title>
</head>
<body>
  <div class="container">
    <span style="background:#fff; color:#fff; -moz-user-select: none; -webkit-user-select: none; -ms-user-select:none; user-select:none;-o-user-select:none;" unselectable="on" onselectstart="return false;" onmousedown="return false;"><h1>|</h1></span>
    <h5 class="my-4 text-center">Products: <?= $products;?></h5>
    <h2 class="my-4 text-center"><?= "php ".number_format($grandTotal, 2);?></h2>
    <form action="charge.php" method="POST" id="payment-form">
      <div class="form-row">
      <input type="hidden" name="products" value="<?= $products;?>">
      <input type="hidden" name="price" value="<?= $grandTotal;?>">
      <input type="hidden" name="pmode" value="<?= $pmode;?>">
      <input type = "hidden" name="uid" value="<?= $userUid;?>">
      <input type = "hidden" name="loyal" value="<?= $loyalpts;?>">
      <input type="text" name="name" class="form-control mb-3 StripeElement StripeElement--empty" value="<?= $userName;?>" placeholder="Enter Full Name">
      <input type="email" name="email" class="form-control mb-3 StripeElement StripeElement--empty" value="<?= $userEmail?>" placeholder="Enter Email Address">
      <input type="tel" name="phone" class="form-control mb-3 StripeElement StripeElement--empty" value="<?= $userPhone;?>" placeholder="Enter Phone Number">
      <input type="text" name="address" class="form-control mb-3 StripeElement StripeElement--empty" value="<?= $address;?>" placeholder="Enter Address">
      <label for="card-element">
        Credit or Debit card
      </label>
      <div id="card-element" class="form-control">
        <!-- a Stripe Element will be inserted here. -->
      </div>

        <!-- Used to display form errors -->
        <div id="card-errors" role="alert"></div>
      </div>

      <button <?php echo ($grandTotal>1)?"":"disabled";?>>Submit Payment</button>
      <a href="userCheckout.php"class="btn btn-danger" style="margin-top: 1rem; width: 100%;">Cancel</a>
    </form>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://js.stripe.com/v3/"></script>
  <script src="js/charge.js?v=<?php echo time(); ?>"></script>
</body>
</html>
<?php
if (isset($_GET['printStat'])) {
    error_reporting(-1);
    ini_set('display_errors', true);
    $title = "Reports Statistics | Michella's Pick N' Shop";
    include 'fpdf/fpdf.php';
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetTitle($title);
    $pdf->SetFont('Arial','', 11);
    $pdf->Image('img/logo2.png', 80, 5, 50);
    $pdf->Cell(0,20,'Reports Statistics',0,1,'C');
    $pdf->Cell(0,10,'Summary of Sales',0,1,'C');
    include_once 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM archorder WHERE orderStatus = 'Delivered';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
      $timestamp = strtotime($row['cancelDate']);
      $products = $row['products'];
      $orderCode = $row['orderCode'];
      $pcode = $row['prodCode'];
      $rev = 0;
      $rev += $row['amountPaid'];
      $prodAr = explode(',', $pcode);
      $length = count($prodAr);
      $i = 0;
      while($length > $i){
        $prodAr[$i];
        $prodName = explode('-', $prodAr[$i]);
        $trimName = trim($prodName[0]);
        $stmt = $conn->prepare("SELECT origPrice FROM prodcuct WHERE productCode = '$trimName';");
        $stmt->execute();
        $res = $stmt->get_result();
        while($rw = $res->fetch_assoc()){
          $expint = 0;
          $expint += $rw['origPrice'];
          $prof = $rev - $expint;
        }
        $i++;
      }
      $pdf->Cell(25,5,'Order Code: ', 1, 0, 'C');
      $pdf->Cell(85,5,$orderCode, 1, 0, 'C');
      $pdf->Cell(25,5,'Date: ', 1, 0, 'C');
      $pdf->Cell(55,5,$row['cancelDate'], 1, 1, 'C');
      $pdf->Cell(25,5,'Products: ', 1, 0, 'C');
      $pdf->MultiCell(165,5,$products, 1, 'L');
      $pdf->Cell(10,5,'Total: ', 0, 0, 'C');
      $pdf->Cell(25,5,'Sales: ', 1, 0, 'C');
      $pdf->Cell(35,5,'php '.number_format($rev,2), 1, 0, 'C');
      $pdf->Cell(25,5,'Expenses: ', 1, 0, 'C');
      $pdf->Cell(35,5,'php '.number_format($expint, 2), 1, 0, 'C');
      $pdf->Cell(25,5,'Profit: ', 1, 0, 'C');
      $pdf->Cell(35,5,'php '.number_format($prof,2), 1, 1, 'C');
      $pdf->Cell(0,9,'',0,1);
  }
  $sql->close();
  $stmt->close();
  $month = date('m');
  $year = date('Y');
  $Month = date('M');
  $pdf->Cell(0,10,'Monthly Sales ('.$Month.')',0,1,'C');
  include_once 'includes/dbhStore.inc.php';
  $sql = $conn->prepare("SELECT * FROM archorder WHERE orderStatus = 'Delivered' AND MONTH(cancelDate) = $month AND YEAR(cancelDate) = '$year';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $products = $row['products'];
    $ocode = $row['orderCode'];
    $timestamp = strtotime($row['cancelDate']);
    $pcode = $row['prodCode'];
    $sale = $row['amountPaid'];
    $prodAr = explode(',', $pcode);
    $length = count($prodAr);
    $i = 0;
    while($length > $i){
      $prodAr[$i];
      $prodName = explode('-', $prodAr[$i]);
      $trimName = trim($prodName[0]);
      $stmt = $conn->prepare("SELECT origPrice FROM prodcuct WHERE productCode = '$trimName';");
      $stmt->execute();
      $res = $stmt->get_result();
      while($rw = $res->fetch_assoc()){
        $expense = $rw['origPrice'];
        $profit = $sale - $expense;
      }
      $i++;
    }
    $pdf->Cell(25,5,'Order Code: ', 1, 0, 'C');
    $pdf->Cell(85,5,$orderCode, 1, 0, 'C');
    $pdf->Cell(25,5,'Date: ', 1, 0, 'C');
    $pdf->Cell(55,5,$row['cancelDate'], 1, 1, 'C');
    $pdf->Cell(25,5,'Products: ', 1, 0, 'C');
    $pdf->MultiCell(165,5,$products, 1, 'L');
    $pdf->Cell(25,5,'Per Order: ', 0, 0, 'C');
    $pdf->Cell(25,5,'Sales: ', 1, 0, 'C');
    $pdf->Cell(50,5,'php '.number_format($sale,2), 1, 0, 'C');
    $pdf->Cell(0,9,'',0,1);
  }
        
  $pdf->Output();
}else{
    die('invalid access');
}
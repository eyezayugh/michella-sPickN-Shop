<?php
session_start();
require 'includes/dbhStore.inc.php';
if (isset($_POST['action'])) {
    $sql = "SELECT * FROM prodcuct WHERE brand != ''";

    if (isset($_POST['brand'])) {
    $brand = implode("','", $_POST['brand']);
    $sql .= "AND brand IN('".$brand."')";
    }
    if (isset($_POST['typeProd'])) {
    $typeProd = implode("','", $_POST['typeProd']);
    $sql .= "AND typeProd IN('".$typeProd."')";
    }
    $result = $conn->query($sql);
    $output='';

    if($result->num_rows>0){
    while ($row=$result->fetch_assoc()) {
        $userName = $_SESSION['useruid'];
        $output .= '<div class="col-sm-6 col-md-4 col-lg-3 mb-2">
        <div class="card-deck">
          <div class="card p-2 border-bottom md-2" style="box-shadow: 1px 2px 4px rgba(0, 0, 0, 0.3), 0px 0px 6px rgba(0, 0, 0, 0.3);">
            <a href="userStoreInfo.php?product='.$row['id'].'"><img src="'. $row['productImage'].'" class="card-img-top" width="180"></a>
            <div class="card-body p-1">
              <h6 class="card-title text-center text-info">'.$row['productName'].'</h6>
              <h6 class="card-text text-center text-danger">PHP '.number_format($row['productPrice'],2).'</h6>
            </div>
            <div class="card-footer p-1 pb-2">
              <a href="userStoreInfo.php?product='.$row['id'].'" class="btn btn-warning btn-block"><i class="fas fa-shopping-cart"></i> Add to cart</a>
            </div>
          </div>
        </div>
      </div>
      ';
    }
  }
    else{
    $output = "<h3>No Products Found!</h3>";
    }
    echo $output;
    exit;
}
?>
<!-- Programmed by: Isaiah John Ching Fernando -->
<?php
session_start();
if ($_SESSION["userUid"] == null) {
  header("location: index.php");
  exit();
}
if($_SESSION["userType"] == "Deliver" || $_SESSION["userType"] == "Pending"){
  header("location: adminUserLogin.php?error=notallowed");
  session_unset();
  session_destroy();
  exit();
}
$userId = $_SESSION["userId"];
$userUid = $_SESSION["userUid"];
$userEmail = $_SESSION["userEmail"];
$userPhone = $_SESSION["userPhone"];
$userType = $_SESSION["userType"];

if(isset($_GET['delete'])){
  $id = $_GET['delete'];
  
  include_once 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM users WHERE userId = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $userId = $row['userId'];
    $userName = $row['userName'];
    $userEmail = $row['userEmail'];
    $userUid = $row['userUid'];
    $userPhone = $row['userPhone'];
    $userAdd = $row['userAdd'];
    $userPwd = $row['userPwd'];
    $verified = $row['verified'];
    $userType = $row['userType'];
    $vKey = $row['vKey'];
    $loyalpts = $row['loyalpts'];
    
    $stmt = $conn->prepare("INSERT INTO archusers (userId,userName,userEmail,userUid,userPhone,userAdd,userPwd,verified,userType,vKey,loyalpts) VALUES ('$userId','$userName','$userEmail','$userUid','$userPhone','$userAdd','$userPwd','$verified','$userType','$vKey','$loyalpts');");
    $stmt->execute();
     // info to send email
    $to = $userEmail;
    $subject = "Account Deletion | Michella's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michelle\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Account Has Been Deleted</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your account has been removed. Do not reply to this message.</center></i>

            <p><center>Bellow are reasons to why your account has been removed</center></p>
            <p><center>1) You have violated the Terms and Conditions/Privacy Policy</center></p>
            <p><center>2) You have requested account removal</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us Again</a>
            </center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    //delete
    $del = $conn->prepare("DELETE FROM users WHERE userId = '$userId';");
    $del->execute();
    header('location: adminHome.php?users=customers');
    mysqli_close($conn);
  }
}

if(isset($_GET['admindelete'])){
  $id = $_GET['admindelete'];
  
  include_once 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $userName = $row['userName'];
    $userEmail = $row['userEmail'];
    $userUid = $row['userUid'];
    $userPhone = $row['userPhone'];
    $userPwd = $row['userPwd'];
    $userType = $row['userType'];
    
    $stmt = $conn->prepare("INSERT INTO archuseradmin (userName,userUid,userEmail,userPhone,userType,userPwd) VALUES ('$userName','$userUid','$userEmail','$userPhone','$userType','$userPwd');");
    $stmt->execute();
     // info to send email
    $to = $userEmail;
    $subject = "Account Deletion | Michella's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Account Has Been Deleted</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your account has been removed. Do not reply to this message.</center></i>

            <p><center>Bellow are reasons to why your account has been removed</center></p>
            <p><center>1) You have violated the Terms and Conditions/Privacy Policy</center></p>
            <p><center>2) You have requested account removal</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us Again</a>
            </center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    //delete
    $del = $conn->prepare("DELETE FROM useradmin WHERE id = '$id';");
    $del->execute();
    header('location: adminHome.php?users=admin');
    mysqli_close($conn);
  }
}

if(isset($_GET['portercheck'])){
    $id = $_GET['portercheck'];
    error_reporting(-1);
    ini_set('display_errors', true);
    include_once 'includes/dbh.inc.php';
    $stmt = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()){
      $name = $row['userName'];
      $email = $row['userEmail'];
      // info to send email
      $to = $email;
      $subject = "Porter Application Approved | Michella's Pick N' Shop";

      //html message
      $message = '
      <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <script
        src="https://kit.fontawesome.com/824d2c43ce.js"
        crossorigin="anonymous"
      ></script>
      <title>Document</title>
  </head>
  <body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
      <div style="max-width: 600px; margin: auto; padding: 20px;">
          <div>
              <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
              <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
          </div>

          <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
              moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
              border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

              <h1 style="font-size: 22px;"><center>You have been approved to be one of our porters</center></h1>

              <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your account has been approved. Do not reply to this message.</center></i>

              <p><center>Welcome '.$name.' to our company.</center></p>
              <p><center>We will assign orders for you to complete</center></p>
              <p><center>In your account you will find instructions, follow them to complete your order</center></p>
              <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/adminUserLogin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Login to your account</a>
              </center></p>
              <p><center>Or use this link <a href="https://michellapicknshop.com/adminUserLogin.php">https://michellapicknshop.com/adminUserLogin.php</a></center></p>
              <p><center>Click the link above or copy and paste in to the url.</center></p>
          </div>
          </div>
  </body>
  </html>
    ';

      // email headers
      $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
      $headers .= "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
      mail($to, $subject, $message, $headers);
    }
    $delfile = $conn->prepare("SELECT * FROM idvalid WHERE userId = '$id';");
    $delfile->execute();
    $res = $delfile->get_result();
    while($rw = $res->fetch_assoc()){
      $file = $rw['nameFile'];
      $file_to_delete = "resellerID/$file";
      unlink($file_to_delete);
    }
    $sql = $conn->prepare("DELETE FROM idvalid WHERE userId = '$id';");
    $sql->execute();
    $update = $conn->prepare("UPDATE useradmin SET userType = 'Deliver' WHERE id = '$id';");
    $update->execute();
    header('location: adminHome.php?users=porters');
    mysqli_close($conn);
}

if(isset($_GET['porterdelete'])){
    $id = $_GET['porterdelete'];
    error_reporting(-1);
    ini_set('display_errors', true);
    include_once 'includes/dbh.inc.php';
    $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
      $userName = $row['userName'];
      $userEmail = $row['userEmail'];
      $userUid = $row['userUid'];
      $userPhone = $row['userPhone'];
      $userPwd = $row['userPwd'];
      $userType = $row['userType'];
    
      $stmt = $conn->prepare("INSERT INTO archuseradmin (userName,userUid,userEmail,userPhone,userType,userPwd) VALUES ('$userName','$userUid','$userEmail','$userPhone','$userType','$userPwd');");
      $stmt->execute();
      // info to send email
      $to = $email;
      $subject = "Porter Account Deletion | Michella's Pick N' Shop";

      //html message
      $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michelle\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Account Has Been Deleted</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your account has been removed. Do not reply to this message.</center></i>

            <p><center>Bellow are reasons to why your account has been removed</center></p>
            <p><center>1) You have violated the Terms and Conditions/Privacy Policy</center></p>
            <p><center>2) You have requested account removal</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us Again</a>
            </center></p>
        </div>
        </div>
</body>
</html>
    ';

      // email headers
      $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
      $headers .= "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
      mail($to, $subject, $message, $headers);
    }
    $del = $conn->prepare("DELETE FROM useradmin WHERE id = '$id';");
    $del->execute();
    header('location: adminHome.php?users=porters');
    mysqli_close($conn);
}

if(isset($_GET['porterdecline'])){
    $id = $_GET['porterdecline'];
    error_reporting(-1);
    ini_set('display_errors', true);
    include_once 'includes/dbh.inc.php';
    $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
      $email = $row['userEmail'];
      // info to send email
      $to = $email;
      $subject = "Decline Porter Application | Michelle's Pick N' Shop";

      //html message
      $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Applicaiton Has Been Declined</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your application has been declined. Do not reply to this message.</center></i>

            <p><center>Bellow are reasons to why your application has been declined</center></p>
            <p><center>1) You have violated the Terms and Conditions/Privacy Policy</center></p>
            <p><center>2) During phone interview you gave us reasons to decline your application</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us Again</a>
            </center></p>
            <p><center>Thank you for your application</center></p>
        </div>
        </div>
</body>
</html>
    ';

      // email headers
      $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
      $headers .= "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
      mail($to, $subject, $message, $headers);
    }
    $stmt = $conn->prepare("SELECT * FROM idvalid WHERE userId = '$id';");
    $stmt->execute();
    $res = $stmt->get_result();
    while($rw = $res->fetch_assoc()){
      $file = $rw['nameFile'];
      $file_to_delete = "resellerID/$file";
      unlink($file_to_delete);
    }
    $del = $conn->prepare("DELETE FROM idvalid WHERE userId = '$id';");
    $del->execute();
    $del2 = $conn->prepare("DELETE FROM useradmin WHERE id = '$id';");
    $del2->execute();
    mysqli_close($conn);
    header("location: adminHome.php?users=porters");
    mysqli_close($conn);
}

if(isset($_GET['proddelete'])){
    $prodid = $_GET['proddelete'];
    error_reporting(-1);
    ini_set('display_errors', true);
    include_once 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM prodcuct WHERE id = '$prodid';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
      $name = $row['productName'];
      $pprice = $row['productPrice'];
      $pimg = $row['productImage'];
      $pcode = $row['productCode'];
      $desc = $row['productDesc'];
      $brand = $row['brand'];
      $typeProd = $row['typeProd'];
      $stock = $row['productStock'];
      $oprice = $row['origPrice'];
      $feature = $row['feature'];
      $loyalpts = $row['loyalpts'];
      
      $insert2 = $conn->prepare("INSERT INTO archprodcuct (productName, productPrice, productImage, productCode, productDesc, brand, typeProd, productStock, origPrice, feature, loyalpts) VALUES ('$name', '$pprice', '$pimg', '$pcode', '$desc', '$brand', '$typeProd', '$stock', '$oprice', '$feature', '$loyalpts');");
      if($insert2 == false){
        die('prepare() failed: ' . htmlspecialchars($conn->error));
      }
      $insert2->execute();
      $delete2 = $conn->prepare("DELETE FROM prodcuct WHERE id = '$prodid';");
      $delete2->execute();
      header("location: adminHome.php?store=product");
      exit();
    }
    mysqli_close($conn);
}

if(isset($_GET['cancelOrder'])){
  
  $orderid = $_GET['cancelOrder'];
  
  error_reporting(-1);
  ini_set('display_errors', true);
  include 'includes/dbhStore.inc.php';
  $st = $conn->prepare("SELECT * FROM orders WHERE id = '$orderid';");
  $st->execute();
  $re = $st->get_result();
  while ($rw = $re->fetch_assoc()) {
    $useName = $rw['userName'];
    $useUid = $rw['userUid'];
    $useEmail = $rw['userEmail'];
    $usePhone = $rw['userPhone'];
    $useAdd = $rw['userAdd'];
    $pmode = $rw['pmode'];
    $products = $rw['products'];
    $grandTotal = $rw['amountPaid'];
    $orderCode = $rw['orderCode'];
    $userAddress = $rw['userAdd'];
    $pCode = $rw['prodCode'];

    $stat = $conn->prepare("SELECT prodCode FROM orders WHERE id = '$orderid';");
    $stat->execute();
    $rs = $stat->get_result();
    while ($ro = $rs->fetch_assoc()) {
      $prod = $ro['prodCode'];
      $prodAr = explode(',', $prod);
      $length = count($prodAr);
      $i = 0;
      while ($length > $i) {
          $prodAr[$i];
          $prodName = explode('-', $prodAr[$i]);
          $trimName = trim($prodName[0]);
          $trimNum = trim($prodName[1]);
          $statem = $conn->prepare("SELECT * FROM prodcuct WHERE productCode = '$trimName';");
          $statem->execute();
          $rt = $statem->get_result();
          while ($rws = $rt->fetch_assoc()) {
              $stock = $rws['productStock'];
              $stockTots = $stock + $trimNum;
              $sqli = $conn->prepare("UPDATE prodcuct SET productStock = '$stockTots' WHERE productCode = '$trimName';");
              $sqli->execute();
          }
          $i++;
        }
      }
    // info to send email
    $to = $useEmail;
    $subject = "Order Cancelation| Michelle's Pick N' Shop";
    
    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Order Has Been Canceled</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your order has been canceled. Do not reply to this message.</center></i>

            <p><center>Bellow are reasons to why your application has been declined</center></p>
            <p><center>1) You have violated the Terms and Conditions/Privacy Policy</center></p>
            <p><center>2) There was a problem with the order proccess and you will be sent an email or text/call</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us Again</a>
            </center></p>
            <p><center>Thank you for your understanding</center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
  }
  $update = $conn->prepare("UPDATE orders SET orderStatus = 'Canceled by the Store' WHERE id = '$orderid';");
  $update->execute();
  
  $loyal = $grandTotal/25;
  
  include 'includes/dbh.inc.php';
  $e = $conn->prepare("DELETE FROM qrcode WHERE orderCode = '$orderCode';");
  $e->execute();

  $select = $conn->prepare("SELECT loyalpts FROM users WHERE userUid = '$userUid';");
  $select->execute();
  $result = $select->get_result();
  while($row_select = $result->fetch_assoc()){
    $pts = $row_select['loyalpts'];
    $loyalpts = $pts - $loyal;
    $update = $conn->prepare("UPDATE users SET loyalpts = '$loyalpts' WHERE userUid = '$userUid';");
    $update->execute();
  }

  mysqli_close($conn);
  header("location: adminHome.php?store=order");
  exit();
}
if(isset($_GET['refundapprove'])){
    $refundid = $_GET['refundapprove'];
    include 'includes/dbhStore.inc.php';
    
    $sql = $conn->prepare("SELECT * FROM refundorder WHERE id = '$refundid';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
        $orderCode = $row['orderCode'];
        $prodimg = $row['prodimg'];
        unlink($prodimg);
        $update = $conn->prepare("UPDATE archorder SET orderStatus = 'Refund Request Accepted' WHERE orderCode = '$orderCode';");
        $update->execute();
    }
    $select = $conn->prepare("SELECT * FROM archorder WHERE orderCode = '$orderCode';");
    $select->execute();
    $res = $select->get_result();
    while($rw = $res->fetch_assoc()){
        $userEmail = $rw['userEmail'];
        $userUid = $rw['userUid'];
        $userAdd = $rw['userAdd'];
        $amountPaid = $rw['amountPaid'];
        $pmode = $rw['pmode'];
    }
    // info to send email
    $to = $userEmail;
    $subject = "Approved Refund Request | Michella's Pick N' Shop";
    
    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michelle\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Refund Request Has Been Approved</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that refund request has been approved. Do not reply to this message.</center></i>

            <p><center>We will deliver your refunded payments to you at your deliver address:</center></p>
            <p><center>'.$userAdd.'</center></p>
            <p><center>Refunded Payment: php '.number_format($amountPaid, 2).'</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us Again</a>
            </center></p>
            <p><center>Thank you for your patronage</center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    
    $pts = $amountPaid / 25;
    $connect = mysqli_connect("localhost", "u391276243_me", "rR37Vqs6@:", "u391276243_useraccounts");
    $user = $connect->prepare("SELECT * FROM users WHERE userUid = '$userUid';");
    $user->execute();
    $resultuser = $user->get_result();
    while($rowuser = $resultuser->fetch_assoc()){
        $loyalpts = $rowuser['loyalpts'];
        $newloyal = $loyalpts - $pts;
        $insert = $connect->prepare("UPDATE users SET loyalpts = '$newloyal' WHERE userUid = '$userUid';");
        $insert->execute();
    }
    mysqli_close($connect);
    
    $delete = $conn->prepare("DELETE FROM refundorder WHERE id ='$refundid';");
    $delete->execute();
    mysqli_close($conn);
    header("location: adminHome.php?more=refund");
    exit();
}
if(isset($_GET['refunddecline'])){
    $id = $_GET['refunddecline'];
    $sql = $conn->prepare("SELECT * FROM refundorder WHERE id ='$id';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
        $orderCode = $row['orderCode'];
        $prodimg = $row['prodimg'];
        unlink($prodimg);
        $update = $conn->prepare("UPDATE archorder SET orderStatus = 'Delivered' WHERE orderCode = '$orderCode';");
        $update->execute();
    }
    $select = $conn->prepare("SELECT * FROM archorder WHERE orderCode = '$orderCode';");
    $select->execute();
    $res = $select->get_result();
    while($rw = $res->fetch_assoc()){
        $userEmail = $rw['userEmail'];
    }
    // info to send email
    $to = $userEmail;
    $subject = "Declined Refund Request | Michella's Pick N' Shop";
    
    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michelle\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Refund Request Has Been Declined</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that refund request has been declined. Do not reply to this message.</center></i>

            <p><center>Your refund request for your order '.$orderCode.' has been declined</center></p>
            <p><center>Bellow are resons why</center></p>
            <p><center>1) The picture of the product order you gave us was not enough proof, or you gave a picture that had nothing to do with the order</center></p>
            <p><center>2) The reasons or descriptions you gave were not enough proof, or had nothing to do with your order</center></p>
            <p><center>Return Policy: <a href="https://michellapicknshop.com/termscondition.php" target="_blank">Terms and Conditions</a></center></p>
            <p><center>If not stated above, please send us a refund request again</center></p>
            <i><center>WARNING: Abusing the Refund Request Module will result in account deletion</center></i>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Visit Us Again</a>
            </center></p>
            <p><center>Thank you for your patronage</center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    
    $delete = $conn->prepare("DELETE FROM refundorder WHERE id ='$id';");
    $delete->execute();
    mysqli_close($conn);
    header("location: adminHome.php?more=refund");
    exit();
}

if(isset($_GET['newdelete'])){
  $id = $_GET['newdelete'];
  error_reporting(-1);
  ini_set('display_errors', true);
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM news WHERE id = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $subj = $row['subj'];
    $body = $row['body'];
    $newsimg = $row['newsImg'];
    $insert = $conn->prepare("INSERT INTO archnews(subj, body, newsImg) VALUES('$subj', '$body', '$newsimg');");
    $insert->execute();
    $delete = $conn->prepare("DELETE FROM news WHERE id = '$id';");
    $delete->execute();
  }
  mysqli_close($conn);
  header("location: adminHome.php?more=message");
  exit();
}

if(isset($_GET['recoverCus'])){
  $id = $_GET['recoverCus'];
  ini_set('display_errors', true);
  include_once 'includes/dbhStore.inc.php';
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM archusers WHERE archId = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $name = $row['userName'];
    $email = $row['userEmail'];
    $username = $row['userUid'];
    $phone = $row['userPhone'];
    $pwd = $row['userPwd'];
    $verified = $row['verified'];
    $userType = $row['userType'];
    $vKey = $row['vKey'];
    $loyalpts = $row['loyalpts'];
    include 'includes/functions.inc.php';
    if(userExist($conn, $username) !== false){
      header("location: adminHome.php?error=userexist");
      exit();
    }else{
      $insert = $conn->prepare("INSERT INTO users (userName, userEmail, userUid, userPhone, userPwd, verified, userType, vKey, loyalpts) VALUES ('$name', '$email', '$username', '$phone', '$pwd', '$verified', '$userType', '$vKey', '$loyalpts');");
      $insert->execute();
      $delete = $conn->prepare("DELETE FROM archusers WHERE archId = '$id';");
      $delete->execute();
      // info to send email
    $to = $email;
    $subject = "Account Restored | Michelle's Pick N' Shop";
    
    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Account Has Been Restored</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your account has been restored. Do not reply to this message.</center></i>

            <p><center>Your account '.$username.' has been restored by us</center></p>
            <p><center>Come please visit us again</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Click Here</a>
            </center></p>
            <p><center>Thank you for your patronage</center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    header("location: adminHome.php?more=archive");
    exit();
    }
    header("location: adminHome.php?more=archive");
    exit();
  }
  header("location: adminHome.php?more=archive");
  exit();
  mysqli_close($conn);
}

if(isset($_GET['recoverAdm'])){
  $id = $_GET['recoverAdm'];
  include 'includes/dbh.inc.php';
  include 'includes/functions.inc.php';
  $sql = $conn->prepare("SELECT * FROM archuseradmin WHERE id = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $name = $row['userName'];
    $username = $row['userUid'];
    $email = $row['userEmail'];
    $phone = $row['userPhone'];
    $type = $row['userType'];
    $pwd = $row['userPwd'];
    if(adminUserExist($conn, $username) !== false){
      header("location: adminHome.php?error=userexist");
      exit();
    }else{
      $insert = $conn->prepare("INSERT INTO useradmin (userName, userUid, userEmail, userPhone, userType, userPwd) VALUES ('$name', '$username', '$email', '$phone', '$type', '$pwd');");
      $insert->execute();
      $delete = $conn->prepare("DELETE FROM archuseradmin WHERE id = '$id';");
      $delete->execute();
      header("location: adminHome.php?more=archive");
      exit();
    }
  }
  mysqli_close($conn);
}

if(isset($_GET['recoverPort'])){
  $id = $_GET['recoverPort'];
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM archuseradmin WHERE id = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $name = $row['userName'];
    $username = $row['userUid'];
    $email = $row['userEmail'];
    $phone = $row['userPhone'];
    $type = $row['userType'];
    $pwd = $row['userPwd'];
    include 'includes/functions.inc.php';
    if(adminUserExist($conn, $username) !== false){
      header("location: adminHome.php?error=userexist");
      exit();
    }else{
      // info to send email
    $to = $email;
    $subject = "Account Restored | Michelle's Pick N' Shop";
    
    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Account Has Been Restored</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your account has been restored. Do not reply to this message.</center></i>

            <p><center>Your Porter Account '.$username.' has been restored by us</center></p>
            <p><center>Sign in to your account</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/adminUserLogin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Your Account</a>
            </center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/index.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Our Store</a>
            </center></p>
            <p><center>Thank you for your patronage</center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    
      $insert = $conn->prepare("INSERT INTO useradmin (userName, userUid, userEmail, userPhone, userType, userPwd) VALUES ('$name', '$username', '$email', '$phone', '$type', '$pwd');");
      $insert->execute();
      $delete = $conn->prepare("DELETE FROM archuseradmin WHERE id = '$id';");
      $delete->execute();
      header("location: adminHome.php?more=archive");
      exit();
    }
  }
  mysqli_close($conn);
}

if(isset($_GET['recoverNews'])){
  $id = $_GET['recoverNews'];
  include 'includes/dbh.inc.php';
  $sql = $conn->prepare("SELECT * FROM archnews WHERE id = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $subj = $row['subj'];
    $body = $row['body'];
    $newsimg = $row['newsImg'];
    $insert = $conn->prepare("INSERT INTO news (subj, body, newsImg) VALUES ('$subj', '$body', '$newsimg');");
    $insert->execute();
    $delete = $conn->prepare("DELETE FROM archnews WHERE id = '$id';");
    $delete->execute();
    header("location: adminHome.php?more=archive");
    exit();
  }
  mysqli_close($conn);
}

if(isset($_GET['recoverProd'])){
  $id = $_GET['recoverProd'];
  ini_set('display_errors', true);
  include 'includes/dbhStore.inc.php';
  $sql = $conn->prepare("SELECT * FROM archprodcuct WHERE id = '$id';");
  $sql->execute();
  $result = $sql->get_result();
  while($row = $result->fetch_assoc()){
    $name = $row['productName'];
    $pprice = $row['productPrice'];
    $pimg = $row['productImage'];
    $pcode = $row['productCode'];
    $desc = $row['productDesc'];
    $brand = $row['brand'];
    $typeProd = $row['typeProd'];
    $stock = $row['productStock'];
    $oprice = $row['origPrice'];
    $feature = $row['feature'];
    $loyalpts = $row['loyalpts'];
    include 'includes/functionStore.inc.php';
    if(pnameExist($conn, $name)){
      header("location: adminHome.php?error=nameexist");
      exit();
    }
    elseif(pcodeExist($conn, $pcode)){
      header("location: adminHome.php?error=codeexist");
      exit();
    }
    else{
      $insert = $conn->prepare("INSERT INTO prodcuct (productName, productPrice, productImage, productCode, productDesc, brand, typeProd, productStock, origPrice, feature, loyalpts) VALUES ('$name', '$pprice', '$pimg', '$pcode', '$desc', '$brand', '$typeProd', '$stock', '$oprice', '$feature', '$loyalpts');");
      $insert->execute();
      $delete = $conn->prepare("DELETE FROM archprodcuct WHERE id = '$id';");
      $delete->execute();
      header("location: adminHome.php?more=archive");
      exit();
    }
  }
  mysqli_close($conn);
}

if(isset($_GET['pickupOrder'])){
    error_reporting(-1);
    ini_set('display_errors', true);
    $id = $_GET['pickupOrder'];
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("UPDATE orders SET orderStatus = 'Ready for Pickup' WHERE id = '$id';");
    $sql->execute();
    $stmt = $conn->prepare("SELECT * FROM orders WHERE id = '$id';");
    $stmt->execute();
    $result = $stmt->get_result();
    while($row = $result->fetch_assoc()){
        $email = $row['userEmail'];
        $orderCode = $row['orderCode'];
        $orderDate = $row['orderDate'];
        $date = $orderDate->format('Y-m-d-H-i-s');
    }
    // info to send email
    $to = $email;
    $subject = "Order Pickup | Michella's Pick N' Shop";
    
    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title>Document</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Order is Ready For Pickup</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to you to notify you that your account has been restored. Do not reply to this message.</center></i>

            <p><center>Your Order: '.$orderCode.' is now ready for pickup</center></p>
            <p><center>Date Ordered: '.$date.'</center></p>
            <p><center>Store Address: KM44 Longos Malolos Bulacan, Philippines</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/signin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">For more information about your order Click Here</a>
            </center></p>
            <p><center>Thank you for your patronage</center></p>
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    header("location: adminHome.php?store=order");
    exit();
}
if(isset($_GET['pickupSuccess'])){
    error_reporting(-1);
    ini_set('display_errors', true);
    $id = $_GET['pickupSuccess'];
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM orders WHERE id = '$id';");
    $sql->execute();
    $result = $sql->get_result(); 
    while($row = $result->fetch_assoc()){
        $userName = $row['userName'];
        $userUid = $row['userUid'];
        $userEmail = $row['userEmail'];
        $userPhone = $row['userPhone'];
        $userAdd = $row['userAdd'];
        $pmode = $row['pmode'];
        $products = $row['products'];
        $amountPaid = $row['amountPaid'];
        $orderCode = $row['orderCode'];
        $prodCode = $row['prodCode'];
        $orderStatus = 'Delivered';
        
        $insert = $conn->prepare("INSERT INTO archorder(userName, userUid, userEmail, userPhone, userAdd, pmode, products, amountPaid, orderCode, prodCode, orderStatus) VALUES('$userName', '$userUid', '$userEmail', '$userPhone', '$userAdd', '$pmode', '$products', '$amountPaid', '$orderCode', '$prodCode', '$orderStatus')");
        $insert->execute();
        $delete = $conn->prepare("DELETE FROM orders WHERE id = '$id';");
        $delete->execute();
        header("location: adminHome.php?store=order");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="css/styleAdminHome.css?v=<?php echo time(); ?>" />
    <link rel="stylesheet" href="css/magnify.css?v=<?php echo time(); ?>" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
      integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA=="
      crossorigin="anonymous"
    />
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"
      integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg=="
      crossorigin="anonymous"
    ></script>
    <script
      type="text/javascript"
      src="https://www.gstatic.com/charts/loader.js"
    ></script>
    <script type="text/javascript">
      google.charts.load("current", { packages: ["corechart"] });
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ["Date", "Sales", "Expense", "Profit"],
          <?php
          include_once 'includes/dbhStore.inc.php';
          $sql = $conn->prepare("SELECT * FROM archorder WHERE orderStatus = 'Delivered';");
          $sql->execute();
          $result = $sql->get_result();
          while($row = $result->fetch_assoc()){
            $timestamp = strtotime($row['cancelDate']);
            $pcode = $row['prodCode'];
            $rev = $rev+ $row['amountPaid'];
            $prodAr = explode(',', $pcode);
            $length = count($prodAr);
            $i = 0;
            while($length > $i){
              $prodAr[$i];
              $prodName = explode('-', $prodAr[$i]);
              $trimName = trim($prodName[0]);
              $stmt = $conn->prepare("SELECT origPrice FROM prodcuct WHERE productCode = '$trimName';");
              $stmt->execute();
              $res = $stmt->get_result();
              while($rw = $res->fetch_assoc()){
                $expint = $expint + $rw['origPrice'];
                $prof = $rev - $expint;
              }
              $i++;
            }
          ?>
          ["<?= $date = date('d-m-Y', $timestamp);?>", <?= $rev?>, <?= $expint;?>, <?= $prof;?>],
          <?php
          }
          mysqli_close($conn);
          ?>
        ]);

        var options = {
          title: "Summary of Sales",
          curveType: "function",
          legend: { position: "bottom" },
          colors: ["#329CE7", "#E73232", "#097138"],
        };

        var chart = new google.visualization.LineChart(
          document.getElementById("curve_chart")
        );

        chart.draw(data, options);
      }
    </script>
    <script type="text/javascript">
    google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Customer", "Amount Paid", { role: "style" } ],
    <?php
    error_reporting(-1);
    ini_set('display_errors', true);
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM archorder WHERE orderStatus = 'Delivered' ORDER BY `archorder`.`id` DESC LIMIT 10;");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
    ?>
        ["<?= $row['userUid'];?>",<?= number_format($row['amountPaid'], 2);?>, 'stroke-color: #703593; stroke-width: 4; fill-color: #C5A5CF'],
    <?php
    }
    ?>
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Summary of Orders (Last 10)",
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options);
  }
  </script>
  <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ["Date", "Sales"],
          <?php
          error_reporting(-1);
          ini_set('display_errors', true);
          include_once 'includes/dbhStore.inc.php';
          $month = date('m');
          $year = date('Y');
          $sql = $conn->prepare("SELECT * FROM archorder WHERE orderStatus = 'Delivered' AND MONTH(cancelDate) = $month AND YEAR(cancelDate) = '$year';");
          $sql->execute();
          $result = $sql->get_result();
          while($row = $result->fetch_assoc()){
            $timestamp = strtotime($row['cancelDate']);
            $pcode = $row['prodCode'];
            $sale = $row['amountPaid'];
            $prodAr = explode(',', $pcode);
            $length = count($prodAr);
            $i = 0;
            while($length > $i){
              $prodAr[$i];
              $prodName = explode('-', $prodAr[$i]);
              $trimName = trim($prodName[0]);
              $stmt = $conn->prepare("SELECT origPrice FROM prodcuct WHERE productCode = '$trimName';");
              $stmt->execute();
              $res = $stmt->get_result();
              while($rw = $res->fetch_assoc()){
                $expense = $rw['origPrice'];
                $profit = $sale - $expense;
              }
              $i++;
            }
          ?>
          ["<?= $date = date('D M j', $timestamp);?>", <?= $sale?>],
          <?php
          }
          mysqli_close($conn);
          ?>
        ]);

        var options = {
          title: 'Monthly Sales (<?= date('F');?>)',
        };

        var chart = new google.visualization.AreaChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
    </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Admin | Michella's Pick N' Shop</title>
  </head>
  <body>
    <!-- wrapper start -->
    <div class="wrapper">
      <!--header menu start-->
      <div class="header">
        <div class="header-menu">
          <div class="title"><span>Admin</span></div>
          <div class="sidebar-btn">
            <i class="fas fa-bars"></i>
          </div>
          <?php
          include 'includes/dbhStore.inc.php';
          $sql = "SELECT count(id) AS total FROM orders WHERE orderStatus = 'Pending';";
          $result = mysqli_query($conn,$sql);
          $values = mysqli_fetch_assoc($result);
          $num_rows = $values['total'];
          
          $sql2 = "SELECT count(id) AS total FROM refundorder;";
          $result2 = mysqli_query($conn,$sql2);
          $values2 = mysqli_fetch_assoc($result2);
          $num_rows2 = $values2['total'];
          
          $sql4 = "SELECT count(id) AS total FROM prodcuct WHERE productStock < 6;";
          $result4 = mysqli_query($conn,$sql4);
          $values4 = mysqli_fetch_assoc($result4);
          $num_rows4 = $values4['total'];
          mysqli_close($conn);
          
          include 'includes/dbh.inc.php';
          $sql3 = "SELECT count(userId) AS total FROM idvalid;";
          $result3 = mysqli_query($conn,$sql3);
          $values3 = mysqli_fetch_assoc($result3);
          $num_rows3 = $values3['total'];
          
          $notif = $num_rows + $num_rows2 + $num_rows3 + $num_rows4;
          ?>
          <ul>
            <li style="display: flex;">
              <p style="color: #c42828; font-weight: bold;"><?php 
              if($notif>0){echo $notif;}
              else{echo'';}?></p>
              <a href="adminHome.php?notif" style="margin-left: 0;"><i class="fas fa-bell"></i></a>
            </li>
            <li>
              <a href="adminUserLogin.php"><i class="fas fa-power-off"></i></a>
            </li>
          </ul>
        </div>
      </div>
      <!--header menu end-->
      <!--sidebar start-->
      <div class="sidebar">
        <div class="sidebar-menu">
          <center class="profile">
            <img src="img/logo3.png" />
          </center>
          <li class="item">
            <a href="adminHome.php" class="menu-btn">
              <i class="fas fa-desktop"><span>Dashboard</span></i>
            </a>
          </li>
          <li class="item" id="profile">
            <a href="#profile" class="menu-btn">
              <i class="fas fa-user-circle"></i
              ><span
                >Accounts <i class="fas fa-chevron-down drop-down"></i
              ></span>
            </a>
            <div class="sub-menu">
              <a href="adminHome.php?users=customers"><i class="fas fa-users"></i><span>Customers</span></a>
              <a href="adminHome.php?users=admin"><i class="fas fa-address-card"></i><span>Admin</span></a>            
              <a href="adminHome.php?users=porters"><i class="fas fa-truck-loading"></i></i><span>Porters</span></a>            
            </div>
          </li>
          <li class="item" id="messages">
            <a href="#messages" class="menu-btn">
              <i class="fas fa-cash-register"></i><span
                >Store <i class="fas fa-chevron-down drop-down"></i
              ></span>
            </a>
            <div class="sub-menu">
              <a href="adminHome.php?store=product"><i class="fas fa-store"></i><span>Products</span></a>
              <a href="adminHome.php?store=order"><i class="fas fa-file-invoice-dollar"></i></i><span>Orders</span></a>
              <a href="adminHome.php?store=stat"><i class="fas fa-chart-line"></i><span>Statistics</span></a>
            </div>
          </li>
          <li class="item" id="settings">
            <a href="#settings" class="menu-btn">
              <i class="fas fa-cog"></i
              ><span
                >More <i class="fas fa-chevron-down drop-down"></i
              ></span>
            </a>
            <div class="sub-menu">
              <a href="adminHome.php?more=refund"><i class="fas fa-hand-holding-usd"></i><span>Refund</span></a>
              <a href="adminHome.php?more=message"><i class="fas fa-envelope-open-text"></i><span>Message</span></a>
              <a href="adminHome.php?more=reviews"><i class="far fa-comments"></i></i><span>Reviews</span></a>
              <a href="adminHome.php?more=archive"><i class="fas fa-archive"></i><span>Archive</span></a>
            </div>
          </li>
          <li class="item">
            <a href="developer.php" class="menu-btn" target="_blank">
              <i class="fas fa-info-circle"><span> Developers</span></i>
            </a>
          </li>
        </div>
      </div>
      <!--sidebar end-->
      <!-- main container start -->
      <div class="main-container">
        <?php
        if (isset($_GET['users'])) {
          if (($_GET['users'] == 'customers')) {
      ?>
      <!--customer start-->
      <div class="container-user">
        <!--top customer start-->
        <div class="top-customer">
          <h4 class="title">Customer Accounts</h4>
          <form action="" method="POST" class="search-form">
            <input type="text" name="search" class="search-customer" placeholder="Search">
            <button type="submit" name="submit-search" class="btn-search"><i class="fas fa-search"></i></button>
          </form>
        </div>
        <!--top customer end-->
        <!--bottom customer start-->
        <div class="bottom-customer">
          <!--add record start-->
          <div class="record-left">
            <form action="actionAdminHome.php" method="POST" class="edit-form">
              <h4 class="title">Add Account</h4>
              <input type="text" class="input-field" name="name" placeholder="Full Name" />
              <input type="text" class="input-field" name="uid" placeholder="Username" />
              <input type="email" class="input-field" name="email" placeholder="Email" />
              <input type="tel" class="input-field" name="phone" placeholder="Phone Number" />
              <input type="text" class="input-field" name="address" placeholder="Address" />
              <input type="password" class="input-field" name="pwd" placeholder="Password" />
              <button type="submit" name="submit-acc" class="submit-btn">Submit</button>
            </form>
          </div>
          <!--add record end-->
          <!--record CRUD start-->
          <div class="record-right">
            <?php
            include 'includes/dbh.inc.php';
            if (isset($_POST['submit-search'])) {
              $space = '/\s/';
              $search = mysqli_real_escape_string($conn, $_POST['search']);
              $sql="SELECT * FROM users WHERE userName LIKE '%$search%' OR userUid LIKE '%$search%' OR userId LIKE '%$search%' OR userId LIKE '%$space%' OR userName LIKE '%$space%' OR userUid LIKE '%$space%';";
              $result = mysqli_query($conn, $sql);
              $queryResult = mysqli_num_rows($result);

              if ($queryResult > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Verified</th>
                    <td colspan ="3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><?= $row['userId']; ?></td>
                    <td><?= $row['userName']; ?></td>
                    <td><?= $row['userUid']; ?></td>
                    <?php
                    if ($row['verified'] == 1) {
                      echo '<td>True</td>';
                    }else {
                      echo '<td>False</td>';
                    }
                    ?>
                    <td><a href="adminHome.php?usershow=<?= $row['userId']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
                    <td><a href="adminHome.php?useredit=<?= $row['userId']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
                    <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?delete=<?= $row['userId']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
                  </tr>
                </tbody>
            </table>
            <?php
                }
              }else{
            ?>
            <h4 style="color: red; text-align: center;">No Results Found</h4>
            <?php
              }
            }else{
            ?>
            <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Verified</th>
                    <td colspan ="3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  include 'includes/dbh.inc.php';
                  $sql = $conn->prepare("SELECT * FROM `users` ORDER BY `users`.`verified` ASC, `users`.`userId` DESC");
                  $sql->execute();
                  $result = $sql->get_result();
                  while ($row = $result->fetch_assoc()) {
                      $name = $row['userName'];
                  ?>
                  <tr>
                    <td><?= $row['userId']; ?></td>
                    <td><?= $row['userName']; ?></td>
                    <td><?= $row['userUid']; ?></td>
                    <?php
                    if ($row['verified'] == 1) {
                      echo '<td>True</td>';
                    }else {
                      echo '<td>False</td>';
                    }
                    ?>
                    <td><a href="adminHome.php?usershow=<?= $row['userId']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
                    <td><a href="adminHome.php?useredit=<?= $row['userId']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
                    <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?delete=<?= $row['userId']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
                  </tr>
                  <?php
                  }
                  ?>
                </tbody>
            </table>
            <?php
            }
            ?>
          </div>
          <!--record CRUD end-->
        </div>
        <!--bottom customer end-->
      </div>
      <!--customer end-->
      <?php
          mysqli_close($conn);
          }
          if (($_GET['users'] == 'admin')) {
      ?>
      <!--admin account start-->
      <div class="container-user">
        <!--top admin account start-->
        <div class="top-customer">
          <h4 class="title">Admin Accounts</h4>
          <form action="" method="POST" class="search-form">
            <input type="text" name="search" class="search-customer" placeholder="Search">
            <button type="submit" name="submit-searchAdmin" class="btn-search"><i class="fas fa-search"></i></button>
          </form>
        </div>
        <!--top admin account end-->
        <!--bottom admin account start-->
        <div class="bottom-customer">
          <!--add record start-->
          <div class="record-left">
            <form action="actionAdminHome.php" method="POST" class="edit-form">
              <h4 class="title">Add Account</h4>
              <input type="text" class="input-field" name="name" placeholder="Full Name" />
              <input type="text" class="input-field" name="uid" placeholder="Username" />
              <input type="email" class="input-field" name="email" placeholder="Email" />
              <input type="tel" class="input-field" name="phone" placeholder="Phone Number" />
              <input type="password" class="input-field" name="pwd" placeholder="Password" />
              <select name="type" class="form-control">
                <option value="" selected disabled>Select Account Type</option>
                <option value="Admin">Admin</option>
                <option value="Deliver">Delivery</option>
              </select>
              <button type="submit" name="submit-Adminacc" class="submit-btn">Submit</button>
            </form>
          </div>
          <!--add record end-->
          <!--record CRUD start-->
          <div class="record-right">
            <?php
            include 'includes/dbh.inc.php';
            if (isset($_POST['submit-searchAdmin'])) {
              $space = '/\s/';
              $search = mysqli_real_escape_string($conn, $_POST['search']);
              $sql="SELECT * FROM useradmin WHERE userName LIKE '%$search%' AND userType = 'Admin' OR userUid LIKE '%$search%' AND userType = 'Admin' OR id LIKE '%$search%' AND userType = 'Admin' OR userType LIKE '%$search%' AND userType = 'Admin' OR userType LIKE '%$space%' AND userType = 'Admin' OR id LIKE '%$space%' AND userType = 'Admin' OR userName LIKE '%$space%' AND userType = 'Admin' OR userUid LIKE '%$space%' AND userType = 'Admin';";
              $result = mysqli_query($conn, $sql);
              $queryResult = mysqli_num_rows($result);

              if ($queryResult > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Type</th>
                    <td colspan ="3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['userName']; ?></td>
                    <td><?= $row['userUid']; ?></td>
                    <td><?= $row['userType']; ?></td>
                    <td><a href="adminHome.php?adminshow=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
                    <td><a href="adminHome.php?adminedit=<?= $row['id']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
                    <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?admindelete=<?= $row['id']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
                  </tr>
                </tbody>
            </table>
            <?php
                }
              }
              else{
            ?>
            <h4 style="color: red; text-align: center;">No Results Found</h4>
            <?php
              }
            }else{
            ?>
            <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Type</th>
                    <td colspan ="3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  include 'includes/dbh.inc.php';
                  $sql = $conn->prepare("SELECT * FROM `useradmin` WHERE userType = 'Admin' ORDER BY `useradmin`.`id` DESC");
                  $sql->execute();
                  $result = $sql->get_result();
                  while ($row = $result->fetch_assoc()) {
                  ?>
                  <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['userName']; ?></td>
                    <td><?= $row['userUid']; ?></td>
                    <td><?= $row['userType']; ?></td>
                    <td><a href="adminHome.php?adminshow=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
                    <td><a href="adminHome.php?adminedit=<?= $row['id']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
                    <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?admindelete=<?= $row['id']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
                  </tr>
                  <?php
                  }
                  ?>
                </tbody>
            </table>
            <?php
            }
            ?>
          </div>
          <!--record CRUD end-->
        </div>
        <!--bottom admin account end-->
      </div>
      <!--admin account end-->
      <?php
          }
          if (($_GET['users'] == 'porters')) {
      ?>
      <!--porter account start-->
      <div class="container-user">
        <!--top porter account start-->
        <div class="top-customer">
          <h4 class="title">Porter Accounts</h4>
          <form action="" method="POST" class="search-form">
            <input type="text" name="search" class="search-customer" placeholder="Search">
            <button type="submit" name="submit-searchPorter" class="btn-search"><i class="fas fa-search"></i></button>
          </form>
        </div>
        <!--top porter account end-->
        <!--bottom porter account start-->
        <div class="bottom-customer">
          <!--add record start-->
          <div class="record-left">
            <form action="actionAdminHome.php" method="POST" class="edit-form">
              <h4 class="title">Add Account</h4>
              <input type="hidden" name="type" value="Deliver" />
              <input type="text" class="input-field" name="name" placeholder="Full Name" />
              <input type="text" class="input-field" name="uid" placeholder="Username" />
              <input type="email" class="input-field" name="email" placeholder="Email" />
              <input type="tel" class="input-field" name="phone" placeholder="Phone Number" />
              <input type="password" class="input-field" name="pwd" placeholder="Password" />
              <button type="submit" name="submit-Deliveracc" class="submit-btn">Submit</button>
            </form>
          </div>
          <!--add record end-->
          <!--record CRUD start-->
          <div class="record-right">
            <?php
            include 'includes/dbh.inc.php';
            if (isset($_POST['submit-searchPorter'])) {
              $space = '/\s/';
              $search = mysqli_real_escape_string($conn, $_POST['search']);
              $sql="SELECT * FROM useradmin WHERE userName LIKE '%$search%' AND userType = 'Deliver' OR userUid LIKE '%$search%' AND userType = 'Deliver' OR id LIKE '%$search%' AND userType = 'Deliver' OR userType LIKE '%$search%' AND userType = 'Deliver' OR userType LIKE '%$space%' AND userType = 'Deliver' OR id LIKE '%$space%' AND userType = 'Deliver' OR userName LIKE '%$space%' AND userType = 'Deliver' OR userUid LIKE '%$space%' AND userType = 'Deliver';";
              $result = mysqli_query($conn, $sql);
              $queryResult = mysqli_num_rows($result);

              if ($queryResult > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <h4>Available Porters</h4>
            <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Type</th>
                    <td colspan ="3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['userName']; ?></td>
                    <td><?= $row['userUid']; ?></td>
                    <td><?= $row['userType']; ?></td>
                    <td><a href="adminHome.php?adminshow=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
                    <td><a href="adminHome.php?adminedit=<?= $row['id']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
                    <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?admindelete=<?= $row['id']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
                  </tr>
                </tbody>
            </table>
            <?php
                }
              }
              else{
            ?>
            <h4 style="color: red; text-align: center;">No Results Found</h4>
            <?php
              }
            }else{
            ?>
            <h4>Pending Porter</h4>
            <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <td colspan ="3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  include 'includes/dbh.inc.php';
                  $stmt = $conn->prepare("SELECT * FROM idvalid");
                  $stmt->execute();
                  $res = $stmt->get_result();
                  while($rw = $res->fetch_assoc()){
                    $img = $rw['nameFile'];
                    $sql = $conn->prepare("SELECT * FROM `useradmin` WHERE userType = 'Pending' ORDER BY `useradmin`.`id` DESC");
                    $sql->execute();
                    $result = $sql->get_result();
                    while ($row = $result->fetch_assoc()) {
                  ?>
                  <tr>
                    <td><img src="resellerID/<?= $rw['nameFile']; ?>" width="80"></td>
                    <td><?= $row['userName']; ?></td>
                    <td><?= $row['userPhone']; ?></td>
                    <td><?= $row['userEmail']; ?></td>
                    <td><a href="adminHome.php?porterimg=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
                    <td><a href="adminHome.php?portercheck=<?= $row['id']; ?>" class="btn-show" style="background:#3CA42F;"><i class="fas fa-check"></i></a></td>
                    <td><a onclick = "return confirm('Are you sure you want to decline this applicant?')" href="adminHome.php?porterdecline=<?= $row['id']; ?>"style="color:#C41A1A; font-size: 2rem"><i class="fas fa-times-circle"></i></a></td>
                  </tr>
                  <?php
                    }
                  }
                  ?>
                </tbody>
            </table>
            <h4 style="margin-top: 2rem;">Available Porters</h4>
            <table>
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Type</th>
                    <td colspan ="3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  include 'includes/dbh.inc.php';
                  $sql = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Deliver' ORDER BY `useradmin`.`id` DESC");
                  $sql->execute();
                  $result = $sql->get_result();
                  while ($row = $result->fetch_assoc()) {
                  ?>
                  <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['userName']; ?></td>
                    <td><?= $row['userUid']; ?></td>
                    <td><a href="adminHome.php?portershow=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
                    <td><a href="adminHome.php?porteredit=<?= $row['id']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
                    <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?porterdelete=<?= $row['id']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
                  </tr>
                  <?php
                  }
                  ?>
                </tbody>
            </table>
            <?php
            }
            ?>
          </div>
          <!--record CRUD end-->
        </div>
        <!--bottom porter account end-->
      </div>
      <!--porter account end-->
      <!--Product section start-->
      <?php
            mysqli_close($conn);
          }
        }
        //store tab start
        elseif(isset($_GET['store'])){
            if($_GET['store'] == "product"){
                include 'adminProduct.php';
            }
            elseif($_GET['store'] == "order"){
                include 'adminOrder.php';
            }
            elseif($_GET['store'] == "stat"){
                include 'adminStat.php';
            }
        }
        //store tab end
        //more tab start
        elseif(isset($_GET['more'])){
            if($_GET['more'] == "refund"){
                include 'adminRefund.php';
            }
            elseif($_GET['more'] == "message"){
                include 'adminMsg.php';
            }
            elseif($_GET['more'] == "reviews"){
                include 'adminReviews.php';
            }
            elseif($_GET['more'] == "archive"){
                include 'adminArchive.php';
            }
        }
        //more tab end
        //notification start
        elseif(isset($_GET['notif'])){
            include 'adminNotif.php';
        }
        //notification end
        //Nwes start
        elseif(isset($_GET['newshow'])){
          $id = $_GET['newshow'];
          include 'includes/dbh.inc.php';
          $sql = $conn->prepare("SELECT * FROM news WHERE id = '$id';");
          $sql->execute();
          $result = $sql->get_result();
          while($row = $result->fetch_assoc()){
        ?>
        <div class="view">
          <div class="box">
            <h3>News No. <?= $row['id']; ?></h3>
            <hr>
            <h5>Date Posted: <?= $row['newsDate']; ?></h5>
            <img src="<?= $row['newsImg']; ?>" style="height= 100%; width: 100%; max-width: 350px; max-height: 400px;" id="image" class="zoom" data-magnify-src="<?= $row['newsImg']; ?>">
            <h5>Title: <?= $row['subj']; ?></h5>
            <p><center><?= $row['body']; ?></center></p>
            <a href="adminHome.php?newedit=<?= $row['id']; ?>" class="view-btn">Edit</a>
            <a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?newdelete=<?= $row['id'];?>" class="view-btn">Delete</a>
            <a href="adminHome.php?more=message" class="view-btn">Cancel</a>
          </div>
        </div>
        <?php
          }
          mysqli_close($conn);
        }
        //news edit
        elseif(isset($_GET['newedit'])){
          $id = $_GET['newedit'];
          include 'includes/dbh.inc.php';
          $sql = $conn->prepare("SELECT * FROM news WHERE id = '$id';");
          $sql->execute();
          $result = $sql->get_result();
          while($row = $result->fetch_assoc()){
        ?>
        <div class="view">
          <div class="box2">
            <div class="title">
              <h3>News and Announcements No. <?= $row['id']; ?></h3>
              <hr>
            </div>
            <div class="form-edit" style="display: grid; grid-template-columns: 1fr;">
              <form action="adminActionMsg.php" method="POST" enctype="multipart/form-data" class="prodImage edit-form">
                <input type="hidden" name="id" value="<?= $row['id']; ?>">
                <input type="file" name="file" style="background: inherit; color: #fff;">
                <input type="text" name="subj" class="input-field" style="margin: 0.5rem 0; padding: 0.5rem;" value="<?= $row['subj']; ?>" placeholder="Enter Title/Subject">
                <textarea name="body" col="10" row="10" style="margin: 0.5rem 0; padding: 0.5rem; height: 120px;" placeholder="Enter News or Announcement"><?= $row['body']; ?></textarea>
                <button type="submit" name="submitNews" class="btn">Update</button>
                <a href="adminHome.php?more=message" class="view-btn" style="width: 120px; height: 40px;">Cancel</a>
              </form>
            </div>
          </div>
        </div>
        <?php
          }
        }
        //news end
        //refund start
        elseif(isset($_GET['viewRefund'])){
            $id = $_GET['viewRefund'];
            include 'includes/dbhStore.inc.php';
            $sql = $conn->prepare("SELECT * FROM refundorder WHERE id = '$id';");
            $sql->execute();
            $result = $sql->get_result();
            while($row = $result->fetch_assoc()){
                $img = $row['prodimg'];
                $orderCode = $row['orderCode'];
                $prodDesc = $row['prodDesc'];
                $stmt = $conn->prepare("SELECT * FROM archorder WHERE orderCode = '$orderCode';");
                $stmt->execute();
                $res = $stmt->get_result();
                while($rw = $res->fetch_assoc()){
                    $userName = $rw['userName'];
                    $userEmail = $rw['userEmail'];
                    $userPhone = $rw['userPhone'];
                    $userAdd = $rw['userAdd'];
                    $pmode = $rw['pmode'];
                    $products = $rw['products'];
                    $amountPaid = $rw['amountPaid'];
                }
            }
        ?>
        <div class="view">
          <div class="box3" style="height: 120%; margin-top: 15rem;">
              <h3>Refund Request Detail: <?= $orderCode; ?></h3>
              <hr>
              <img src="<?= $img; ?>" id="image" class="zoom" data-magnify-src="<?= $img; ?>">
              <h5>Desription of Request: <?= $prodDesc;?></h5>
              <h5>Full Name: <?= $userName;?></h5>
              <h5>Email Address: <?= $userEmail;?></h5>
              <h5>Phone Number: <?= $userPhone;?></h5>
              <h5>Address: <?= $userAdd;?></h5>
              <h5 style="text-align: center;">Products: <?= $products;?></h5>
              <?php
              if($pmode == 'cod'){
                  echo '<h5>Payment Mode: Cash On Delivery</h5>';
              }
              elseif($pmode == 'pop'){
                  echo '<h5>Payment Mode:Payment On Pickup</h5>';
              }
              elseif($pmode == 'credit'){
                  echo '<h5>Payment Mode: Credit Card</h5>';
              }
              ?>
              <h5>Amount Paid: php <?= number_format($amountPaid, 2); ?></h5>
              <a href="adminHome.php?refundapprove=<?= $id ?>" class="view-btn">Approve</a>
              <a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?refunddecline=<?= $id;?>" class="view-btn">Decline</a>
              <a href="adminHome.php?more=refund" class="view-btn">Cancel</a>
          </div>
        </div>
        <?php
        }
        elseif(isset($_GET['prodshow'])){
            $id = $_GET['prodshow'];
      ?>
      <!--product item view start-->
        <div class="view">
          <div class="box4">
            <?php
              error_reporting(-1);
              ini_set('display_errors', true);
              include 'includes/dbhStore.inc.php';
              $sql = $conn->prepare("SELECT * FROM prodcuct WHERE id = '$id';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <h3>Product Detail No. <?= $row['id']; ?></h3>
              <hr>
              <img src="<?= $row['productImage']; ?>" id="image" class="zoom" data-magnify-src="<?= $row['productImage']; ?>">
              <h5>Product Code: <?= $row['productCode'];?></h5>
              <h5>Product Name: <?= $row['productName'];?></h5>
              <h5 style="margin:0 1rem;"><center>Description: <?= $row['productDesc'];?></center></h5>
              <h5>Brand: <?= $row['brand'];?></h5>
              <h5>Type: <?= $row['typeProd'];?></h5>
              <h5>Stock: <?= $row['productStock'];?></h5>
              <h5>Sale Price: <?= $row['productPrice'];?></h5>
              <h5>Original Price: <?= $row['origPrice'];?></h5>
              <?php
              if($row['feature'] == 0){
                  echo'<h5>Featured: False</h5>';
              }else{
                  echo'<h5>Featured: True</h5>';
              }
              ?>
              <a href="adminHome.php?prodedit=<?= $row['id']; ?>" class="view-btn">Edit</a>
              <a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?proddelete=<?= $row['id'];?>" class="view-btn">Delete</a>
              <a href="adminHome.php?store=product" class="view-btn">Cancel</a>
          </div>
        </div>
      <!--product item view end-->
      <!--Product Section end -->
      <?php
            mysqli_close($conn);
          }
        }
        elseif(isset($_GET['prodedit'])){
            $id = $_GET['prodedit'];
      ?>
      <!--Product Edit Info Start-->
        <div class="view" style="background: #444;">
          <div class="box2" style="height: 800px; margin-top: 12rem;">
            <?php
              include 'includes/dbhStore.inc.php';
              $sql = $conn->prepare("SELECT * FROM prodcuct WHERE id = '$id';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <div class=title>
                <h3>Product Detail No. <?= $row['id']; ?></h3>
                <hr>
              </div>
              <div class="form-edit" style="display: grid; grid-template-columns: 1fr;">
                  <form action="actionAdminHome.php" method="POST" enctype="multipart/form-data" class="prodImage">
                    <h5>Product Image</h5>
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="file" name="file">
                    <button type="submit" name="submitImage" class="btn">Upload</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="text" class="input-field" name="pname" value="<?= $row['productName']; ?>" placeholder="Product Name"/>
                    <button type="submit" name="productSubmit-editName" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="text" class="input-field" name="pcode" value="<?= $row['productCode']; ?>" placeholder="Product Code"/>
                    <button type="submit" name="productSubmit-editCode" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="text" class="input-field" name="pdesc" value="<?= $row['productDesc']; ?>" placeholder="Product Description" />
                    <input type="text" class="input-field" name="brand" value="<?= $row['brand']; ?>" placeholder="Brand" />
                    <input type="text" class="input-field" name="type" value="<?= $row['typeProd']; ?>" placeholder="Type" />
                    <input type="number" min = "1" class="input-field" name="stock" value="<?= $row['productStock']; ?>" placeholder="Stock" />
                    <input type="number" min = "1" step="0.01" class="input-field" name="pprice" value="<?= $row['productPrice']; ?>" placeholder="Sale Price" />
                    <input type="number" min = "1" step="0.01" class="input-field" name="oprice" value="<?= $row['origPrice']; ?>" placeholder="Original Price" />
                    <select name="feature" class="form-control">
                      <option value="" selected disabled>Product Feature</option>
                      <option value="True">True</option>
                      <option value="False">False</option>
                    </select>
                    <button type="submit" name="productSubmit-editProd" class="submit-btn" style="width: 120px; height: 40px;">Submit</button>
                    <a href="adminHome.php?store=product" class="view-btn" style="width: 120px; height: 40px;">Cancel</a>
                  </form>
              </div>
          </div>
        </div>
        <!--Product Edit Info End-->
      <?php
          }
          mysqli_close($conn);
        }
        elseif (isset($_GET['portershow'])) {
          $id = $_GET['portershow'];
      ?>
      <!--Porter Account View Info Start-->
        <div class="view">
          <div class="box">
            <?php
              include_once 'includes/dbh.inc.php';
              $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <h3>Porter Detail No. <?= $row['id']; ?></h3>
              <hr>
              <h5>Full Name: <?= $row['userName'];?></h5>
              <h5>Username: <?= $row['userUid'];?></h5>
              <h5>Email Address: <?= $row['userEmail'];?></h5>
              <h5>Phone Number: <?= $row['userPhone'];?></h5>
              <a href="adminHome.php?porteredit=<?= $row['id']; ?>" class="view-btn">Edit</a>
              <a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?porterdelete=<?= $row['id'];?>" class="view-btn">Delete</a>
              <a href="adminHome.php?users=porters" class="view-btn">Cancel</a>
          </div>
        </div>
        <!--Porter Account View Info End-->
      <?php
            mysqli_close($conn);
          }
        }
        elseif (isset($_GET['porterimg'])) {
          $id = $_GET['porterimg'];
        ?>
        <!--Porter Validate ID View Start-->
        <div class="view">
          <div class="box3">
            <?php
              include_once 'includes/dbh.inc.php';
              $stmt = $conn->prepare("SELECT * FROM idvalid WHERE userId = '$id';");
              $stmt->execute();
              $res = $stmt->get_result();
              while($rw = $res->fetch_assoc()){
                  $img = $rw['nameFile'];
              }
              $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <h3>Porter Detail No. <?= $row['id']; ?></h3>
              <hr>
              <img src="resellerID/<?= $img; ?>" id="image" class="zoom" data-magnify-src="resellerID/<?= $img; ?>">
              <h5>Full Name: <?= $row['userName'];?></h5>
              <h5>Username: <?= $row['userUid'];?></h5>
              <h5>Email Address: <?= $row['userEmail'];?></h5>
              <h5>Phone Number: <?= $row['userPhone'];?></h5>
              <a href="adminHome.php?portercheck=<?= $row['id']; ?>" class="view-btn">Approve</a>
              <a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?porterdecline=<?= $row['id'];?>" class="view-btn">Decline</a>
              <a href="adminHome.php?users=porters" class="view-btn">Cancel</a>
          </div>
        </div>
        <!--Porter Validate ID View End-->
        <?php
            mysqli_close($conn);
          }
        }
        elseif (isset($_GET['adminshow'])) {
          $id = $_GET['adminshow'];
        ?>
        <!--Admin Account View Info Start-->
        <div class="view">
          <div class="box">
            <?php
              include_once 'includes/dbh.inc.php';
              $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <h3>Admin Detail No. <?= $row['id']; ?></h3>
              <hr>
              <h5>Full Name: <?= $row['userName'];?></h5>
              <h5>Username: <?= $row['userUid'];?></h5>
              <h5>Email Address: <?= $row['userEmail'];?></h5>
              <h5>Phone Number: <?= $row['userPhone'];?></h5>
              <a href="adminHome.php?adminedit=<?= $row['id']; ?>" class="view-btn">Edit</a>
              <a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?admindelete=<?= $row['id'];?>" class="view-btn">Delete</a>
              <a href="adminHome.php?users=admin" class="view-btn">Cancel</a>
          </div>
        </div>
        <!--Admin Account View Info End-->
        <?php
            mysqli_close($conn);
          }
        }
        elseif (isset($_GET['usershow'])) {
          $userid = $_GET['usershow'];
        ?>
        <!--customer view info start-->
        <div class="view">
          <div class="box">
            <?php
              include 'includes/dbh.inc.php';
              $sql = $conn->prepare("SELECT * FROM users WHERE userId = '$userid';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <h3>Customer Detail No. <?= $row['userId']; ?></h3>
              <hr>
              <h5>Full Name: <?= $row['userName'];?></h5>
              <h5>Username: <?= $row['userUid'];?></h5>
              <h5>Email Address: <?= $row['userEmail'];?></h5>
              <h5>Phone Number: <?= $row['userPhone'];?></h5>
              <h5>Address: <?= $row['userAdd'];?></h5>
              <?php
              if($row['verified'] == 1){
              ?>  
              <h5>Verified: True</h5>
              <?php
              }else{
              ?>
              <h5>Verified: False</h5>
              <?php
              }
              ?>
              <h5>Date Created: <?= $row['userDate'];?></h5>
              <h5>Loyalty Points: <?= $row['loyalpts'];?></h5>
              <a href="adminHome.php?useredit=<?= $row['userId']; ?>" class="view-btn">Edit</a>
              <a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?delete=<?= $row['userId'];?>" class="view-btn">Delete</a>
              <a href="adminHome.php?users=customers" class="view-btn">Cancel</a>
          </div>
        </div>
        <!--customer view info end-->
        <?php
          }
          mysqli_close($conn);
        }
        elseif(isset($_GET['adminedit'])){
            $id = $_GET['adminedit'];
        ?>
        <!--Admin User Edit Info Start-->
        <div class="view" style="background: #444;">
          <div class="box2">
            <?php
              include_once 'includes/dbh.inc.php';
              $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <div class=title>
                <h3>Admin Detail No. <?= $row['id']; ?></h3>
                <hr>
              </div>
              <div class="form-edit">
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="text" class="input-field" name="uid" value="<?= $row['userUid']; ?>" placeholder="Username"/>
                    <button type="submit" name="adminSubmit-editaccUid" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="email" class="input-field" name="email" value="<?= $row['userEmail']; ?>" placeholder="Email"/>
                    <button type="submit" name="adminSubmit-editaccEmail" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="tel" class="input-field" name="phone" value="<?= $row['userPhone']; ?>" placeholder="Phone Number"/>
                    <button type="submit" name="adminSubmit-editaccPhone" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="text" class="input-field" name="name" value="<?= $row['userName']; ?>" placeholder="Full Name"/>
                    <select name="type" class="form-control">
                      <option value="" selected disabled>Select Account Type</option>
                      <option value="Admin">Admin</option>
                      <option value="Deliver">Delivery</option>
                    </select>
                    <button type="submit" name="adminSubmit-editacc" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="password" class="input-field" name="pwd" placeholder="New Password" />
                    <button type="submit" name="adminSubmit-editaccPwd" class="submit-btn" style="width: 120px; height: 40px;">Submit</button>
                    <a href="adminHome.php?users=admin" class="view-btn" style="width: 120px; height: 40px;">Cancel</a>
                  </form>
              </div>
          </div>
        </div>
        <!--Admin User Edit Info End-->
        <?php
          }
          mysqli_close($conn);
        }
        elseif(isset($_GET['porteredit'])){
            $id = $_GET['porteredit'];
        ?>
        <!--Porter User Edit Info Start-->
        <div class="view" style="background: #444;">
          <div class="box2" style="height: 800px; margin-top: 12rem;">
            <?php
              include_once 'includes/dbh.inc.php';
              $sql = $conn->prepare("SELECT * FROM useradmin WHERE id = '$id';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <div class=title>
                <h3>Porter Detail No. <?= $row['id']; ?></h3>
                <hr>
              </div>
              <div class="form-edit" style="display: grid; grid-template-columns: 1fr;">
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="text" class="input-field" name="uid" value="<?= $row['userUid']; ?>" placeholder="Username"/>
                    <button type="submit" name="porterSubmit-editaccUid" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="email" class="input-field" name="email" value="<?= $row['userEmail']; ?>" placeholder="Email"/>
                    <button type="submit" name="porterSubmit-editaccEmail" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="tel" class="input-field" name="phone" value="<?= $row['userPhone']; ?>" placeholder="Phone Number"/>
                    <button type="submit" name="porterSubmit-editaccPhone" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="hidden" name="type" value="Deliver">
                    <input type="text" class="input-field" name="name" value="<?= $row['userName']; ?>" placeholder="Full Name"/>
                    <button type="submit" name="porterSubmit-editacc" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <input type="password" class="input-field" name="pwd" placeholder="New Password" />
                    <button type="submit" name="porterSubmit-editaccPwd" class="submit-btn" style="width: 120px; height: 40px;">Submit</button>
                    <a href="adminHome.php?users=porters" class="view-btn" style="width: 120px; height: 40px;">Cancel</a>
                  </form>
              </div>
          </div>
        </div>
        <!--Porter User Edit Info End-->
        <?php
            mysqli_close($conn);
          }
        }
        elseif(isset($_GET['useredit'])){
            $userid = $_GET['useredit'];
        ?>
        <!--Customer Edit Info Start-->
        <div class="view" style="background: #444;">
          <div class="box2">
            <?php
              include 'includes/dbh.inc.php';
              $sql = $conn->prepare("SELECT * FROM users WHERE userId = '$userid';");
              $sql->execute();
              $result = $sql->get_result();
              while ($row = $result->fetch_assoc()) {
              ?>
              <div class=title>
                <h3>Customer Detail No. <?= $row['userId']; ?></h3>
                <hr>
              </div>
              <div class="form-edit">
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['userId']; ?>">
                    <input type="text" class="input-field" name="uid" value="<?= $row['userUid']; ?>" placeholder="Username"/>
                    <button type="submit" name="submit-editaccUid" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['userId']; ?>">
                    <input type="email" class="input-field" name="email" value="<?= $row['userEmail']; ?>" placeholder="Email"/>
                    <button type="submit" name="submit-editaccEmail" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['userId']; ?>">
                    <input type="tel" class="input-field" name="phone" value="<?= $row['userPhone']; ?>" placeholder="Phone Number"/>
                    <button type="submit" name="submit-editaccPhone" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['userId']; ?>">
                    <input type="text" class="input-field" name="name" value="<?= $row['userName']; ?>" placeholder="Full Name"/>
                    <input type="text" class="input-field" name="address" value="<?= $row['userAdd']; ?>" placeholder="Address"/>
                    <div class="radio-button">
                      <h4>Verified</h4>
                      <input type="radio" id="true" name="verified" value="1">
                      <label for="true">True</label><br>
                      <input type="radio" id="false" name="verified" value="0">
                      <label for="false">False</label><br>
                    </div>
                    <button type="submit" name="submit-editacc" class="submit-btn">Submit</button>
                  </form>
                  <form action="actionAdminHome.php" method="POST" class="edit-form">
                    <input type="hidden" name="id" value="<?= $row['userId']; ?>">
                    <input type="password" class="input-field" name="pwd" placeholder="New Password" />
                    <button type="submit" name="submit-editaccPwd" class="submit-btn" style="width: 120px; height: 40px;">Submit</button>
                    <a href="adminHome.php?users=customers" class="view-btn" style="width: 120px; height: 40px;">Cancel</a>
                  </form>
              </div>
          </div>
        </div>
        <!--Customer Edit Info End-->
        <?php
          }
          mysqli_close($conn);
        }
        else {
      ?>
        <!--dashboard start-->
        <!--top start-->
        <div class="dashboard-top">
          
          <a href="adminHome.php?users=customers">
          <div class="info-box" style="background: #84C9EA;">
            <i class="fas fa-user-circle"></i>
            <p>
              <?php
              include 'includes/dbh.inc.php';
              $sql = "SELECT count(userId) AS total FROM users";
              $result = mysqli_query($conn,$sql);
              $values = mysqli_fetch_assoc($result);
              $num_rows = $values['total'];
              if ($num_rows > 0) {
                echo $num_rows;
              }else {
                echo "0";
              }
              mysqli_close($conn);
              ?>
            </p>
            <p>User Accounts</p>
          </div>
          </a>
          <a href="adminHome.php?store=order">
          <div class="info-box" style="background: #A7EA84;">
            <i class="fas fa-shopping-cart"></i>
            <p>
              <?php
              include 'includes/dbhStore.inc.php';
              $sql = "SELECT count(id) AS total FROM orders WHERE orderStatus = 'Pending';";
              $result = mysqli_query($conn,$sql);
              $values = mysqli_fetch_assoc($result);
              $num_rows = $values['total'];
              if ($num_rows > 0) {
                echo '<p style="color: #DA0202;">'.$num_rows.'</p>';
              }else {
                echo "0";
              }
              mysqli_close($conn);
              ?>
            </p>
            <p>Pending Orders</p>
          </div>
          </a>
          <a href="adminHome.php?more=refund">
          <div class="info-box" style="background: #EA9E84;">
            <i class="fas fa-file-invoice-dollar"></i>
            <p>
              <?php
              include 'includes/dbhStore.inc.php';
              $sql = "SELECT count(id) AS total FROM refundorder;";
              $result = mysqli_query($conn,$sql);
              $values = mysqli_fetch_assoc($result);
              $num_rows = $values['total'];
              if ($num_rows > 0) {
                echo '<p style="color: #DA0202;">'.$num_rows.'</p>';
              }else {
                echo "0";
              }
              mysqli_close($conn);
              ?>
            </p>
            <p>Refund Orders</p>
          </div>
          </a>
          <a href="adminHome.php?users=porters">
          <div class="info-box" style="background:#C184EA;">
            <i class="fas fa-truck"></i>
            <p>
              <?php
              include 'includes/dbh.inc.php';
              $sql = "SELECT count(userId) AS total FROM idvalid;";
              $result = mysqli_query($conn,$sql);
              $values = mysqli_fetch_assoc($result);
              $num_rows = $values['total'];
              if ($num_rows > 0) {
                echo '<p style="color: #DA0202;">'.$num_rows.'</p>';
              }else {
                echo "0";
              }
              mysqli_close($conn);
              ?>
            </p>
            <p>Pending Porters</p>
          </div>
          </a>
        </div>
        <!--top end-->
        <!--bottom start-->
        <div class="dashboard-bottom">
          <div id="curve_chart"></div>
          <div class="data">
            <h5 class="title">Order History (last 10)</h5>
            <hr>
            <ul>
              <li><p>Order Code</p><p>Amount Paid (php)</p></li>
            <?php
            $mysqli = new mysqli('localhost','u391276243_user','v5mY:@bPZJ:','u391276243_mydb') or die(mysqli_error($mysqli));
            $result = $mysqli->query("SELECT * FROM archorder WHERE orderStatus = 'Delivered' ORDER BY 'id' DESC LIMIT 10;") or die($mysqli->error);
            while($row = $result->fetch_assoc()){
            ?>
              <li><p class="summary"><?= $row['orderCode']; ?> </p> <p> <?= number_format($row['amountPaid'], 2); ?></p></li>
            <?php
            }
            mysqli_close($mysqli);
            ?>
            </ul>
          </div>
        </div>
        <!--bottom end-->
        <!--dashboard end-->
        <?php
          }
        ?>
      </div>
      <!-- main container end -->
    </div>
    <!-- wrapper end -->
    <script src="js/jquery.magnify.js" charset="UTF-8"></script>
    <script>
    $(document).ready(function() {
      $('.zoom').magnify();
    });
    </script>
    <script type="text/javascript">
      $(document).ready(function () {
        $(".sidebar-btn").click(function () {
          $(".wrapper").toggleClass("collapse");
        });
      });
    </script>
  </body>
</html>

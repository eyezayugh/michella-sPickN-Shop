<!-- Programmed by: Isaiah John Ching Fernando -->
<?php
include 'headerDeliver.php';
if ($_SESSION["userUid"] == null) {
    header("location: index.php");
    exit();
}
$userId = $_SESSION["userId"];
$userUid = $_SESSION["userUid"];
$userEmail = $_SESSION["userEmail"];
$userPhone = $_SESSION["userPhone"];
$userType = $_SESSION["userType"];

if($userType == "Pending"){
    header("location: adminUserLogin.php?error=notallowed");
    session_unset();
    session_destroy();
    exit();
}

if (isset($_POST['deliver'])) {
  $id = $_POST['deliverId'];
  error_reporting(-1);
  ini_set('display_errors', true);
  include 'includes/dbhStore.inc.php';
  $sql = $conn->prepare("UPDATE orders SET orderStatus = 'In Transit' WHERE id = '$id';");
  $sql->execute();
  $stmt = $conn->prepare("SELECT * FROM orders WHERE id = '$id';");
  $stmt->execute();
  $result = $stmt->get_result();
  while($row = $result->fetch_assoc()){
    $userName = $row['userName'];
    $userEmail = $row['userEmail'];
    $userAdd = $row['userAdd'];
    $orderCode = $row['orderCode'];
  }
    // info to send email
    $to = $userEmail;
    $subject = "Order Delivery | Michella's Pick N' Shop";

    //html message
    $message = '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <title> Order Delivery | Michella\'s Pick N\' Shop</title>
</head>
<body style="color: #000; font-size: 16px; text-decoration: none; font-family: Helvetica, arial, sans-serif;">
    <div style="max-width: 600px; margin: auto; padding: 20px;">
        <div>
            <center><i style="font-size: 10px; font-family: Helvetica, arial, sans-serif; letter-spacing: 2px; text-transform: uppercase;">Michella\'s</i></center>
            <center><h1 style="margin: 0px;"><a href="https://michellapicknshop.com/index.php" style ="text-decoration: none;"><i class="fab fa-opencart" style="height: 50px; color: #49b7ca;"> Pick N\' Shop</i></a></h1></center>
        </div>

        <div style="font-size: 1rem; padding: 25px; background-color: #f4f4f4;
            moz-border-radius: 10px; -webkit-border-radius: 10px; border-radius: 10px; -khtml-border-radius: 10px;
            border-color: #49b7ca; border-width: 4px 1px; border-style: solid;">

            <h1 style="font-size: 22px;"><center>Your Order is On it\'s way!</center></h1>

            <i style="font-size: 12px;"><center>This is an email sent to inform you that your order is currently on its way. Do not reply to this message.</center></i>
            <p><center>Hey '.$userName.', at this time, '.date("Y-m-d H:i:s").'</center></p>
            <p><center>your order '.$orderCode.' is currently on its way to your address.</center></p>
            <p><center>'.$userAdd.'</center></p>
            <p><center>For More Information Login To Your Account and view in your Profile (Orders section)</center></p>
            <p style="display: flex; justify-content: center; margin-top: 10px;"><center>
                <a href="https://michellapicknshop.com/signin.php" style="border: 1px solid #056183; background-color: #49b7ca;
                color: #fff; text-decoration: none; font-size: 16px; padding: 10px 20px;">Sign In</a>
            </center></p>
            <p style="padding: 1rem; margin: 0.2rem 1rem;">If you didn\'t purchase this order, contact us at michella122770@gmail.com or 09610913468 or at our <a href="https://www.facebook.com/washdaywithus">FB Page</a></p>
            
        </div>
        </div>
</body>
</html>
    ';

    // email headers
    $headers = "From: Michella's Pick N' Shop <kaikelaloni28@gmail.com> \r\n";
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    mail($to, $subject, $message, $headers);
    mysqli_close($conn);
    header("location: deliveryHome.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/824d2c43ce.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="css/styleDeliver.css?v=<?php echo time(); ?>">
    <title>Document</title>
  </head>
  <body>
    <div class="instruction">
      <div class="title-instruc">
        <h4>Instructions</h4>
      </div>
      <ol>
        <li><h5>Press "Deliver Now" button to start delivery</h5></li>
        <li><h5>The Order Status will become "In Transit", now deliver order to customer</h5></li>
        <li><h5>When all Products are delivered to the customer press "Scan" button</h5></li>
        <li><h5>Scan QR Code of customer order to complete the order</h5></li>
      </ol>
    </div>
    <div class="container">
      <div class="title">
        <h4>Pending Deliveries</h4>
      </div>
      <?php
      if($userType == "Deliver"){
      include 'includes/dbhStore.inc.php';
      $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Pending' AND pmode != 'pop' AND porter = '$userUid';");
      $sql->execute();
      $result = $sql->get_result();
      while ($row = $result->fetch_assoc()) {     
      ?>
      <div class="box">
        <div class="content">
          <h5>Order Code: <?= $row['orderCode']; ?></h5>
          <h5>Customer Name: <?= $row['userName'] ?></h5>
          <h5>Customer Phone: <?= $row['userPhone']; ?></h5>
          <h5>Delivery Address: <?= $row['userAdd']; ?></h5>
          <h5>Products: <?= $row['products']; ?></h5>
          <?php
          $pmode = $row['pmode'];
          if ($pmode == 'cod') {
            echo '<h5>Payment Type: Cash On Delivery</h5>';
          }
          elseif ($pmode == 'credit') {
            echo '<h5>Payment Type: Credit Card</h5>';
          }
          elseif($pmode == 'gcash') {
            echo '<h5>Payment Type: Gcash</h5>';
          }
          ?>
          <h5>Total: Php <?= number_format($row['amountPaid'], 2); ?></h5>
          <h5>Date Ordered: <?= $row['orderDate']; ?></h5>
          <form action="" method="POST">
            <input type="hidden" name="deliverId" value="<?= $row['id']; ?>">
            <input type="submit" name="deliver" value="Deliver Now" class="btn-deliver">
          </form>
        </div>
      </div>
      <?php
      }?>
      <div class="title">
        <h4>In Transit</h4>
      </div>
      <?php
      include_once 'includes/dbhStore.inc.php';
      $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'In Transit' AND porter = '$userUid';");
      $sql->execute();
      $result = $sql->get_result();
      while ($row = $result->fetch_assoc()) {
      ?>
      <div class="box">
        <div class="content">
          <h5>Order Code: <?= $row['orderCode']; ?></h5>
          <h5>Customer Name: <?= $row['userName'] ?></h5>
          <h5>Delivery Address: <?= $row['userAdd']; ?></h5>
          <h5>Products: <?= $row['products']; ?></h5>
          <?php
          $pmode = $row['pmode'];
          if ($pmode == 'cod') {
            echo '<h5>Payment Type: Cash On Delivery</h5>';
          }
          elseif ($pmode == 'credit') {
            echo '<h5>Payment Type: Credit Card</h5>';
          }
          elseif($pmode == 'gcash') {
            echo '<h5>Payment Type: Gcash</h5>';
          }
          ?>
          <h5>Total: Php <?= number_format($row['amountPaid'], 2); ?></h5>
          <h5>Date Ordered: <?= $row['orderDate']; ?></h5>
          <form action="deliveryAction.php" method="POST">
            <input type="hidden" name="orderId" value="<?= $row['id']; ?>">
            <input type="submit" name="order" value="Deliver" class="btn-complete">Scan</input>
          </form>
        </div>
      </div>
      <?php
        }
      }
      else{
      include 'includes/dbhStore.inc.php';
      $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Pending' AND pmode != 'pop';");
      $sql->execute();
      $result = $sql->get_result();
      while ($row = $result->fetch_assoc()) {     
      ?>
      <div class="box">
        <div class="content">
          <h5>Order Code: <?= $row['orderCode']; ?></h5>
          <h5>Customer Name: <?= $row['userName'] ?></h5>
          <h5>Customer Phone: <?= $row['userPhone']; ?></h5>
          <h5>Delivery Address: <?= $row['userAdd']; ?></h5>
          <h5>Products: <?= $row['products']; ?></h5>
          <?php
          $pmode = $row['pmode'];
          if ($pmode == 'cod') {
            echo '<h5>Payment Type: Cash On Delivery</h5>';
          }
          elseif ($pmode == 'credit') {
            echo '<h5>Payment Type: Credit Card</h5>';
          }
          elseif($pmode == 'gcash') {
            echo '<h5>Payment Type: Gcash</h5>';
          }
          ?>
          <h5>Total: Php <?= number_format($row['amountPaid'], 2); ?></h5>
          <h5>Date Ordered: <?= $row['orderDate']; ?></h5>
          <form action="" method="POST">
            <input type="hidden" name="deliverId" value="<?= $row['id']; ?>">
            <input type="submit" name="deliver" value="Deliver Now" class="btn-deliver">
          </form>
        </div>
      </div>
      <?php
      }?>
      <div class="title">
        <h4>In Transit</h4>
      </div>
      <?php
      include_once 'includes/dbhStore.inc.php';
      $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'In Transit';");
      $sql->execute();
      $result = $sql->get_result();
      while ($row = $result->fetch_assoc()) {
      ?>
      <div class="box">
        <div class="content">
          <h5>Order Code: <?= $row['orderCode']; ?></h5>
          <h5>Customer Name: <?= $row['userName'] ?></h5>
          <h5>Delivery Address: <?= $row['userAdd']; ?></h5>
          <h5>Products: <?= $row['products']; ?></h5>
          <?php
          $pmode = $row['pmode'];
          if ($pmode == 'cod') {
            echo '<h5>Payment Type: Cash On Delivery</h5>';
          }
          elseif ($pmode == 'credit') {
            echo '<h5>Payment Type: Credit Card</h5>';
          }
          elseif($pmode == 'gcash') {
            echo '<h5>Payment Type: Gcash</h5>';
          }
          ?>
          <h5>Total: Php <?= number_format($row['amountPaid'], 2); ?></h5>
          <h5>Date Ordered: <?= $row['orderDate']; ?></h5>
          <form action="deliveryAction.php" method="POST">
            <input type="hidden" name="orderId" value="<?= $row['id']; ?>">
            <input type="submit" name="order" value="Scan" class="btn-complete"></input>
          </form>
        </div>
      </div>
      <?php
        }
      }
      ?>
    </div>
  </body>
</html>

<!--Programmed by: Isaiah John Ching Fernando-->
<!--Product item start-->
<div class="container-user">
<!--top product start-->
<div class="top-customer">
  <h4 class="title">Product Items</h4>
  <form action="" method="POST" class="search-form">
    <input type="text" name="search" class="search-customer" placeholder="Search">
    <button type="submit" name="submit-searchAdmin" class="btn-search"><i class="fas fa-search"></i></button>
  </form>
</div>
<!--top product item end-->
<!--bottom product item start-->
<div class="bottom-customer">
  <!--add product start-->
  <div class="record-left2">
    <form action="actionAdminHome.php" method="POST" class="edit-form">
      <h4 class="title">Add Product</h4>
      <p style="font-size: 0.8rem;">Add/Update Product Image with edit Action</p>
      <input type="text" class="input-field" name="name" placeholder="Product Name" />
      <input type="text" class="input-field" name="pcode" placeholder="Product Code" />
      <input type="text" class="input-field" name="desc" placeholder="Product Description" />
      <input type="text" class="input-field" name="brand" placeholder="Brand" />
      <input type="text" class="input-field" name="type" placeholder="Type" />
      <input type="number" min="1" class="input-field" name="stock" placeholder="Stock" />
      <input type="number" min="1" step="0.01" class="input-field" name="pprice" placeholder="Product Price" />
      <input type="number" min="1" step="0.01" class="input-field" name="origprice" placeholder="Original Price" />
      <select name="featured" class="form-control">
        <option value="" selected disabled>Select if product is Featured</option>
        <option value="True">True</option>
        <option value="False">False</option>
      </select>
      <button type="submit" name="submit-product" class="submit-btn">Submit</button>
    </form>
  </div>
  <!--add product end-->
  <!--record CRUD start-->
  <div class="record-right">
    <?php
    include 'includes/dbhStore.inc.php';
    if (isset($_POST['submit-searchAdmin'])) {
      $space = '/\s/';
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $sql="SELECT * FROM prodcuct WHERE productName LIKE '%$search%' OR productPrice LIKE '%$search%' OR id LIKE '%$search%' OR productCode LIKE '%$search%' OR brand LIKE '%$search%' OR typeProd LIKE '%$search%' OR productName LIKE '%$space%' OR productPrice LIKE '%$space%' OR id LIKE '%$space%' OR productCode LIKE '%$space%' OR brand LIKE '%$space%' OR typeProd LIKE '%$space%' OR feature LIKE '%$search%';";
      $result = mysqli_query($conn, $sql);
      $queryResult = mysqli_num_rows($result);
      ?>
      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Brand</th>
            <th>Type</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Featured</th>
            <td colspan ="3">Action</th>
          </tr>
        </thead>
     <?php

      if ($queryResult > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
    ?>
        <tbody>
          <tr>
            <td style="width-space:pre;"><?= $row['productName']; ?></td>
            <td><?= $row['brand']; ?></td>
            <td><?= $row['typeProd']; ?></td>
            <td><?= $row['productPrice']; ?></td>
            <td><?= $row['productStock']; ?></td>
          <?php
          if($row['feature'] == 0){
            echo '<td>False</td>';
          }else{
            echo '<td>True</td>';
          }
          ?>
            <td><a href="adminHome.php?prodshow=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
            <td><a href="adminHome.php?prodedit=<?= $row['id']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
            <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?proddelete=<?= $row['id']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
          </tr>
        </tbody>
    
    <?php
        }
    ?>
    </table>
    <?php
      }
      else{
    ?>
    <h4 style="color: red; text-align: center;">No Results Found</h4>
    <?php
      }
    }else{
    ?>
    <a href="adminPrintProduct.php?printallprod" target="_blank" class="btnPrint">Print</a>
    <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Brand</th>
            <th>Type</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Featured</th>
            <td colspan ="3">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
          include 'includes/dbhStore.inc.php';
          $sql = $conn->prepare("SELECT * FROM `prodcuct` ORDER BY `prodcuct`.`feature` DESC");
          $sql->execute();
          $result = $sql->get_result();
          while ($row = $result->fetch_assoc()) {
          ?>
          <tr>
            <td style="width-space:pre;"><?= $row['productName']; ?></td>
            <td><?= $row['brand']; ?></td>
            <td><?= $row['typeProd']; ?></td>
            <td><?= $row['productPrice']; ?></td>
            <td><?= $row['productStock']; ?></td>
          <?php
          if($row['feature'] == 0){
            echo '<td>False</td>';
          }else{
            echo '<td>True</td>';
          }
          ?>
            <td><a href="adminHome.php?prodshow=<?= $row['id']; ?>" class="btn-show"><i class="far fa-eye"></i></a></td>
            <td><a href="adminHome.php?prodedit=<?= $row['id']; ?>" class="btn-show" style="background: #D5C80E;"><i class="fas fa-user-edit"></i></a></td>
            <td><a onclick = "return confirm('Are you sure you want to delete this accountt?')" href="adminHome.php?proddelete=<?= $row['id']; ?>" class="btn-show" style="background: #E01919;"><i class="fas fa-trash-alt"></i></a></td>
          </tr>
          <?php
          }
          ?>
        </tbody>
    </table>
    <?php
    }
    mysqli_close($conn);
    ?>
  </div>
  <!--record CRUD end-->
</div>
<!--bottom product item end-->
</div>
<!--product item end-->
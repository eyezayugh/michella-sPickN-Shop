<!--Programmed by: Isaiah John Ching Fernando-->
<!--Notification start-->
<div class="container-notif">
  <div style="margin: 1rem; text-align:center;">
    <h4>Notifications</h4>
  </div>
  <div class="box-notif">
    <?php
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Pending' AND porter = '';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
    ?>
    <a href="adminHome.php?store=order">
    <div class="info-notif">
      <p>Unassigned Pending Orders</p>
      <p>Order Code: <?= $row['orderCode'];?></p>
      <p>Order Date: <?= $row['orderDate']; ?></p>
    </div>
    </a>
    <?php
    }
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM orders WHERE orderStatus = 'Pending' AND porter != '';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
    ?>
    <a href="adminHome.php?store=order" style="color: #C46528;">
    <div class="info-notif">
      <p>Pending Orders for Delivery</p>
      <p>Order Code: <?= $row['orderCode'];?></p>
      <p>Order Date: <?= $row['orderDate']; ?></p>
    </div>
    </a>
    <?php
    }
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM refundorder;");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
        $orderCode = $row['orderCode'];
        $select = $conn->prepare("SELECT * FROM archorder WHERE orderCode ='$orderCode';");
        $select->execute();
        $res = $select->get_result();
        while($rw = $res->fetch_assoc()){
            $orderDate = $rw['cancelDate'];
        }
    ?>
    <a href="adminHome.php?more=refund" style="color: #C4B128;">
    <div class="info-notif">
      <p>Refund Order Request</p>
      <p>Order Code: <?= $orderCode;?></p>
      <p>Order Date: <?= $orderDate; ?></p>
    </div>
    </a>
    <?php
    }
    mysqli_close($conn);
    include 'includes/dbh.inc.php';
    $sql = $conn->prepare("SELECT * FROM useradmin WHERE userType = 'Pending';");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
    ?>
    <a href="adminHome.php?users=porters" style="color: #9F28C4;">
    <div class="info-notif">
      <p>Pending Porter Application</p>
      <p>Full Name: <?= $row['userName'];?></p>
      <p>Phone Number: <?= $row['userPhone']; ?></p>
    </div>
    </a>
    <?php
    }
    include 'includes/dbhStore.inc.php';
    $sql = $conn->prepare("SELECT * FROM prodcuct WHERE productStock < 6;");
    $sql->execute();
    $result = $sql->get_result();
    while($row = $result->fetch_assoc()){
    ?>
    <a href="adminHome.php?prodshow=<?= $row['id']; ?>" style="color: #046E6C;">
    <div class="info-notif">
      <p>Low Product Stock</p>
      <p>Product Name: <?= $row['productName'];?></p>
      <p>product Stock: <?= $row['productStock']; ?></p>
    </div>
    </a>
    <?php
    }
    mysqli_close($conn);
    ?>
  </div>
</div>
<!--Notification end-->